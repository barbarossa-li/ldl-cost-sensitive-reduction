#include <cmath>
#include <algorithm>
#include <omp.h>
extern "C" void distances(const double* z,const double* weights,const int* subset,int n,int m,int count,double* d,int threads){
#pragma omp parallel for num_threads(threads) schedule(static)
 for(int i=0;i<n;i++){
  double* row=d+((long)i)*n;
  std::fill(row,row+n,0.0);
  for(int k=0;k<count;k++){
   int a=subset[k];double zi=z[((long)a)*n+i];double wi=weights[((long)a)*n+i];const double* za=z+((long)a)*n;
#pragma omp simd
   for(int j=0;j<n;j++){
    double raw=std::abs(zi-za[j]);double information=(wi*raw)/m;double geometry=raw/m;
    row[j]+=(1.-.1)*information+.1*geometry;
   }
  }
 }
#pragma omp parallel for num_threads(threads) schedule(static)
 for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){double v=std::max(d[((long)i)*n+j],d[((long)j)*n+i]);d[((long)i)*n+j]=v;d[((long)j)*n+i]=v;}
}
