from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/ai_e06_mpl')
import json,csv,statistics as st
from docx import Document
from docx.shared import Pt,Inches
from docx.oxml.ns import qn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;d=json.loads((R/'RESULTS.json').read_text());S=d['summary'];families=sorted(set(r['family'] for r in S));lookup={(r['family'],r['mask'],r['geometry'],r['budget_percent'],r['method'],r['vote'],r['alpha']):r['brier'] for r in S};records=[json.loads(p.read_text()) for p in (R/'cases').rglob('record_PRIVATE.json')];curves=[];contrasts=[];capacity=[]
for mask in ['Full','cost40']:
 for g in ['U','G']:
  for pct in [25,50,75,100]:
   for vote in ['uniform','mass']:
    for alpha in [0.,.5]:
     get=lambda f,m:lookup[(f,mask,g,pct,m,vote,alpha)]
     for method in ['supervised','geometric','lloyd','random']:curves.append({'mask':mask,'geometry':g,'budget_percent':pct,'vote':vote,'alpha':alpha,'method':method,'equal_family_brier':st.mean(get(f,method) for f in families)})
     for control in ['geometric','lloyd','random','raw','plain_mean']:
      base=lambda f:get(f,control) if control in ['geometric','lloyd','random'] else lookup[(f,mask,g,100,'raw0' if alpha==0 else 'rawhalf','NA',alpha)] if control=='raw' else lookup[(f,'NA','NA',0,'plain_mean','NA',1.)]
      delta=[get(f,'supervised')-base(f) for f in families];contrasts.append({'mask':mask,'geometry':g,'budget_percent':pct,'vote':vote,'alpha':alpha,'control':control,'equal_family_brier_difference':st.mean(delta),'families_better':sum(x<0 for x in delta),'families_worse':sum(x>0 for x in delta),'families_tied':sum(x==0 for x in delta)})
   a=[r for c in records for r in c['statistics'] if r['mask']==mask and r['geometry']==g and r['budget_percent']==pct and r['method']=='supervised'];capacity.append({'mask':mask,'geometry':g,'budget_percent':pct,'actual_slot_fraction_mean':st.mean(r['K']/r['n'] for r in a),'numeric_array_byte_fraction_mean':st.mean(r['array_byte_fraction'] for r in a),'numeric_array_byte_fraction_total_weighted':sum(r['array_bytes'] for r in a)/sum(r['raw_array_bytes'] for r in a)})
for name,rows in [('curves.csv',curves),('contrasts.csv',contrasts),('capacity.csv',capacity),('family_results.csv',S)]:
 with open(R/name,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'stage':'E0.6 budget-first prototype development','families':16,'cases':48,'metric_rows':len(d['rows']),'summary_rows':len(S),'new_outer_test_scored':False,'contrasts':contrasts,'capacity':capacity,'decision':'Exact prototype budgets and full endpoint verified. Strong compression with mixed risk costs; some low-budget comparisons versus Lloyd/random favor hierarchical prototypes. Label-priority advantage versus geometry-only remains inconsistent. All settings retained; not independent confirmation or established novelty.'};(R/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
for alpha in [0.,.5]:
 fig,axes=plt.subplots(2,2,figsize=(11,7.8))
 for ax,(g,mask) in zip(axes.ravel(),[(g,m) for g in ['U','G'] for m in ['Full','cost40']]):
  for method,color in [('supervised','#176c69'),('geometric','#d28432'),('lloyd','#5364a1'),('random','#888888')]:
   values=[next(r['equal_family_brier'] for r in curves if (r['mask'],r['geometry'],r['budget_percent'],r['vote'],r['alpha'],r['method'])==(mask,g,pct,'uniform',alpha,method)) for pct in [25,50,75,100]];ax.plot([25,50,75,100],values,'o-',label=method,color=color,markersize=3)
  mean=st.mean(lookup[(f,'NA','NA',0,'plain_mean','NA',1.)] for f in families);ax.axhline(mean,color='#a84c59',ls=':',label='training mean');ax.set_title(g+' geometry / '+mask);ax.set_xlabel('Nominal prototype budget (% of fit objects)');ax.set_ylabel('Equal-family Brier');ax.grid(alpha=.2);ax.set_xticks([25,50,75,100])
 axes[0,0].legend(fontsize=8);fig.suptitle(f'Training-internal risk / capacity curves: uniform votes, prior mix={alpha}\n16 consulted families; no new outer-test scoring',fontsize=11);fig.tight_layout();stem='risk_capacity_prior_half' if alpha else 'risk_capacity_unmixed';fig.savefig(R/(stem+'.png'),dpi=160);fig.savefig(R/(stem+'.pdf'));plt.close(fig)
get=lambda mask,pct,ctrl:next(r for r in contrasts if (r['mask'],r['geometry'],r['budget_percent'],r['vote'],r['alpha'],r['control'])==(mask,'G',pct,'uniform',.5,ctrl))
lines=['# E0.6：原型预算优先的粒球构造与风险—容量曲线','2026年11月13日。16个已咨询特征族×3训练内折，共48折，与E0.4/E0.5相同训练池及划分；全部预测冻结后统一评分。没有重新评分外层测试集，也没有修改78页论文。','## 新构造与固定对照','每个训练折直接构造K=floor(n×25%、50%、75%、100%)个非空原型，覆盖全部训练对象。候选使用几何二分层次：选择几何方差和标签方差各占一半的标准化优先级最高叶，按特征最远对二分；标签只决定先分哪个叶，不用于叶内样本分配。','对照包括相同二分规则但只用几何优先级、同特征几何下的确定性最远点初始化Lloyd参考实现，以及5个匹配候选组大小直方图的随机划分。所有方法具有完全相同的原型个数和数值数组字节数；随机分组不是聚类性能的唯一对照。Lloyd为明示实现的普通原型基线，不冒充任何论文作者的官方算法。','纯几何和Lloyd对照是在拟合特征几何固定后，不再额外使用标签决定分组；G权重本身仍由训练标签拟合，不能称整个G分组流程完全不使用标签。','U均匀与G全局信息加权几何、Full/cost40两档特征掩码、均匀/组大小投票、先验混合alpha=0/.5都事前固定并全部报告。分组使用加权平方欧氏距离，查询使用原先固定的加权L1中心距离，两者目标不同，未声称求解全局风险最优。','## 数值数组容量','float64/int64预测器数组字节数精确为8×[K(d+q+1)+4d+q]。d为已选特征数，q为标签维数。包括中心、标签、组大小、列索引、缩放、权重与训练均值；不包括Python容器/标量元数据、训练工作内存、缓存或序列化开销，也不是最小可能编码。','| 特征掩码 | G原型预算 | 实际槽数/源数均值 | 数值数组字节/单点模型均值 |','|---|---:|---:|---:|']
for r in capacity:
 if r['geometry']=='G':lines.append(f"| {r['mask']} | {r['budget_percent']}% | {r['actual_slot_fraction_mean']:.3f} | {r['numeric_array_byte_fraction_mean']:.3f} |")
lines+=['25%档显著强于上一版约92%的数组占比；这是同一预测器布局下的表示压缩，查询特征预算仍为相同P，不代表特征获取成本相应下降。压缩后是否值得保留，仍取决于对应风险。','## 全部预设预算下的比较','下表固定展示G几何、均匀投票、alpha=.5；未据结果选最优预算。差值为候选减对照，负数表示候选Brier更低，括号为候选更低的族数。其他几何、投票和alpha的全部结果均在CSV和RESULTS.json。','| 特征掩码 | 原型预算 | 对纯几何二分 | 对Lloyd | 对同大小随机 | 对完整单点+同先验 |','|---|---|---:|---:|---:|---:|']
for mask in ['Full','cost40']:
 for pct in [25,50,75,100]:
  cells=[]
  for control in ['geometric','lloyd','random','raw']:
   r=get(mask,pct,control);cells.append(f"{r['equal_family_brier_difference']:+.7f} ({r['families_better']}/16)")
  lines.append('| '+mask+' | '+str(pct)+'% | '+' | '.join(cells)+' |')
lines+=['预设25%档下，候选相对Lloyd在Full/cost40分别有13/16、12/16族更低；相对随机分组分别有13/16、11/16族更低。说明同容量下存在值得继续核验的层次原型信号，不能只以压缩后相对完整模型有误差代价就否定容量比较。','但标签优先候选相对纯几何二分分别仅6/16、8/16族更低；更高预算也没有一致的标签优先增益。当前证据不能把额外标签优先规则写成稳定独立贡献。更大预算不是所有族上单调降低误差，标签噪声与先验收缩都会影响曲线。','相对完整单点模型加同样的均值先验，25%档在Full/cost40的等族平均Brier分别增加约0.00245/0.00150；因此应表述为精度—容量权衡，而非同时压缩且全面提高精度。纯训练均值的无特征基线也在完整结果和图中保留。','## 完整性与证据边界','全部12720个Brier按独立求和式复算，最大差约1.1e-16；6144个满预算投票/先验/随机种子端点与原始单点预测精确一致。输入与预测哈希、概率和、预算精确性、完全覆盖、训练与外层测试隔离均核验。','这是一套新的预算构造，覆盖全部对象并允许高标签方差叶，与旧严格准入/O1重构算法不同；不继承其对象级约束或旧性能记录。所有族、预算、投票及阴性结果保留，折、种子和预算不作为独立数据集。已咨询训练折也不是独立确认。','## 下一阶段应冻结什么','先保留纯几何二分作为强消融，不预设额外标签优先一定有价值；在相同预算和相同先验下检验信息加权本身及层次表示的作用。接着冻结训练内预算选择规则与外层评价，比较验证风险—容量曲线，而不是挑本轮最优点当作新结果。','正式新稿还需原创性核查和更完整的原型/LDL方法比较。本轮支持的是明确的容量曲线与部分同容量比较信号，尚不足以直接宣称整套新方法优越或达到投稿条件。公开代码、协议、全部汇总及校验；实际行号、分组和逐样本预测只存私有缓存。']
md='\n\n'.join(lines).replace('|\n\n|','|\n|')+'\n';(R/'REPORT.md').write_text(md)
doc=Document();style=doc.styles['Normal'];style.font.name='Calibri';style.font.size=Pt(9);style.element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei');i=0
while i<len(lines):
 l=lines[i]
 if l.startswith('|'):
  rr=[]
  while i<len(lines) and lines[i].startswith('|'):
   row=[x.strip() for x in lines[i].strip('|').split('|')]
   if not all(set(x)<=set('-: ') for x in row):rr.append(row)
   i+=1
  t=doc.add_table(rows=0,cols=len(rr[0]));t.style='Light Shading Accent 1'
  for row in rr:
   for c,v in zip(t.add_row().cells,row):c.text=v
  continue
 if l.startswith('# '):doc.add_heading(l[2:],0)
 elif l.startswith('## '):doc.add_heading(l[3:],1)
 else:doc.add_paragraph(l)
 i+=1
for stem,title in [('risk_capacity_prior_half','均匀投票、半强度均值先验'),('risk_capacity_unmixed','均匀投票、不混合均值先验')]:doc.add_page_break();doc.add_heading(title,1);doc.add_picture(str(R/(stem+'.png')),width=Inches(6.2))
doc.save(R/'AI_LDL_E06_预算原型与风险容量报告_20261113.docx');print('Report generated')
