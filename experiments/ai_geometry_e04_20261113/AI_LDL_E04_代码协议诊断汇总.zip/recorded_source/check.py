from pathlib import Path
import json,numpy as np
from candidate import ShapeWeightedModel,normalize_rows

def checks():
 rng=np.random.default_rng(4);W=rng.uniform(0,1,(7,5));c=np.array([.1,1,3,10,100,.001,2.]);assert np.allclose(normalize_rows(W*c[:,None]),normalize_rows(W),atol=1e-14);assert np.allclose(normalize_rows(W).mean(1),1)
 assert np.array_equal(normalize_rows(np.zeros((3,4))),np.ones((3,4)))
 X=rng.normal(size=(12,5));L=rng.dirichlet(np.ones(3),12);m=ShapeWeightedModel(X,L,zeta=.5,k=3);full=tuple(range(5));part=(0,2);Q=rng.normal(size=(4,5));old=m.incoming_selected(Q,full,'L');base=super(ShapeWeightedModel,m).incoming_selected(Q,full,'L');assert np.array_equal(old,base)
 assert np.all(m.training_distances(part,'N')<=m.training_distances(full,'N')+1e-14)
 a=m.incoming_selected(Q[:,part],part,'N');assert np.allclose(a,np.concatenate([m.incoming_selected(q[None,part],part,'N') for q in Q]),atol=1e-14)
 # Independently form directed query distance from fixed training scales.
 scales=m.scales('N');Z=(Q[:,part]-m.lo[list(part)])/m.span[list(part)];I=np.zeros((4,12));G=I.copy()
 for j,p in enumerate(part):
  raw=np.abs(Z[:,j,None]-m.Z[None,:,p]);I+=raw*m.N[None,:,p]/m.m;G+=raw/m.m
 expected=((1-m.zeta)*I/scales['information_full_mean']+m.zeta*G/scales['raw_full_mean'])/scales['fixed_full_max'];assert np.allclose(a,expected,atol=1e-14)
 pi=rng.permutation(12);assert np.array_equal(m.weights('T',pi),m.N[pi]);assert np.allclose(np.sort(m.weights('T',pi),axis=0),np.sort(m.N,axis=0))
 # Pure source-amplitude fixture: identical feature shapes normalize to uniform weights.
 m.W=np.repeat(np.linspace(.01,1,12)[:,None],5,axis=1);m.N=normalize_rows(m.W);m.G=np.broadcast_to(m.W.mean(0),m.W.shape).copy();m.scale_cache={};assert np.allclose(m.incoming_selected(Q,full,'N'),m.incoming_selected(Q,full,'U'),atol=1e-14)
 out={'passed':True,'checks':['row-scale invariance','mean-one/zero-information fallback','old L exact route','fixed-scale subset monotonicity','selected-only source direction','batch invariance','full-row permutation marginal preservation','source-amplitude-only fixture becomes uniform']};Path(__file__).with_name('CHECKS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
if __name__=='__main__':checks()
