"""Portable text inference state: vocabulary+IDF+SVD components, no pickled code."""
import numpy as np,json,hashlib,io
from sklearn.feature_extraction.text import TfidfVectorizer,TfidfTransformer
from design import TextFeatures

def state(obj):return {'vocabulary':{k:int(v) for k,v in obj.vectorizer.vocabulary_.items()},'idf':np.asarray(obj.vectorizer.idf_,np.float64).copy(),'components':np.asarray(obj.svd.components_,np.float64).copy()}
def transform(st,texts):
 v=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_df=1.,max_features=20000,sublinear_tf=True,norm='l2',dtype=np.float64,vocabulary=st['vocabulary']);v.vocabulary_=dict(st['vocabulary']);v.fixed_vocabulary_=True;v._tfidf=TfidfTransformer(norm='l2',use_idf=True,smooth_idf=True,sublinear_tf=True);v._tfidf.idf_=st['idf'];v._tfidf.n_features_in_=len(st['idf']);return np.asarray(v.transform(texts)@st['components'].T,np.float64)
def fingerprint(st):
 return {'vocabulary_sha256':hashlib.sha256(json.dumps(st['vocabulary'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'idf_sha256':hashlib.sha256(st['idf'].tobytes()).hexdigest(),'components_sha256':hashlib.sha256(st['components'].tobytes()).hexdigest(),'vocabulary_size':len(st['vocabulary']),'dimension':st['components'].shape[0]}
def fit(train,query):
 obj=TextFeatures().fit(train);st=state(obj);A=obj.transform(train);Q=obj.transform(query);assert np.array_equal(transform(st,query),Q);return A,Q,st,fingerprint(st)
def dumps(st):
 meta=json.dumps({'vocabulary':st['vocabulary'],'schema':'tfidf-ngram1/2-sublinear-l2-svd128-v1'},sort_keys=True,ensure_ascii=False).encode();f=io.BytesIO();np.savez_compressed(f,idf=st['idf'],components=st['components']);return meta,f.getvalue()
