from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,time,subprocess,concurrent.futures,resource
import numpy as np
R=Path(__file__).resolve().parent;M=Path(os.environ.get('AI_LDL_MAIN','/workspace/work/ai_mechanism_v1_20261113'));D=Path(os.environ.get('AI_LDL_DATA','/workspace/work/asc_experiments/data'));PRIVATE=Path(os.environ.get('AI_LDL_MAIN_PRIVATE','/workspace/work/ai_mechanism_v1_private_20261113'));E05=Path(os.environ.get('AI_LDL_E05','/workspace/work/ai_e05_20261113'));sys.path.insert(0,str(E05));sys.path.insert(0,os.environ.get('AI_LDL_E02','/workspace/work/ai_e02_20261113'))
from calibrated import CalibratedPrototypeModel
from prototype import PrototypePredictor
from budget import bisection_path,lloyd,random_matched,geometry
PCTS=[25,50,75,100]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def verify():
 p=json.loads((R/'PROTOCOL.json').read_text())
 for name,h in p['source_hashes'].items():assert sha(name)==h
 return p
def prepare():
 families=json.loads((M/'PROTOCOL.json').read_text())['families'];sources=[R/n for n in ['budget.py','check.py','CHECKS.json','run.py']]+[E05/'prototype.py',M/'PROTOCOL.json']+[q for q in (M/'dependencies').rglob('*') if q.is_file() and q.suffix in ['.py','.json'] and '__pycache__' not in q.parts];inputs=[D/f"{f['family']}_{a}.npy" for f in families for a in ['X','L']]+[PRIVATE/f['family']/'repeat_1/split_PRIVATE.json' for f in families]
 for f in families:
  for a in ['X','L']:assert sha(D/f"{f['family']}_{a}.npy")==f[a+'_sha256']
 p={'version':'AI-E0.6-budget-first-prototype-development-v1','scope':'Post-v1 consulted training-internal development only; same16 family training pools capped first192 and3 folds as E0.4/E0.5. No new outer-test scoring.','families':families,'cases':48,'fold_seed':'202611134000+10000*family_index0based+1000','masks':['Full','v1-repeat1 bank0 cost40'],'geometries':['U uniform','G feature-global mean of training-fitted local KL weights'],'settings':{'zeta':.5,'retrieval_k':5,'budgets_percent_of_fit_objects':PCTS,'budget_integer':'max(1,floor(percent*nfit/100))','votes':['uniform','group_mass'],'prior_mix':[0.,.5]},'candidate':'Fully covering geometric-bisection hierarchy, no old eligibility or residual exclusion. Split the leaf with largest |B|/n * [.5*Vx(B)/Vx(all)+.5*Vy(B)/Vy(all)]. Zero global variance component contributes zero. Labels determine leaf priority only; farthest-pair feature seeds and nearest-feature-seed membership never use labels.','geometry_metric':'Training squared Euclidean distance of selected scaled features times sqrt(normalized coefficients from frozen U/G calibrated L1 retrieval). Feature/label variances from half the average pairwise squared distance. Query retrieval remains the frozen weighted L1 centroid distance; construction/query objectives are explicitly distinct.','controls':['same bisection with label priority0 (geometry-only)','deterministic farthest-first Lloyd k-means reference in the same weighted feature geometry, max20 iterations, deterministic empty-cluster repair; label-independent grouping','five full-training-row random partitions with same group-size histogram as supervised candidate; same K and numeric array bytes','singleton raw5NN, half global mean shrinkage, and plain training mean'],'leaf_splitting':'Farthest feature pair, assign closer seed, feature ties to first. All-zero feature spread => balanced original-index split. Priority ties: larger leaf, smaller original minimum ID. Canonical group order uses actual minimum original row position for every method.','random_seed':'202611136000+100000*family_index+10000*fold+1000*geometry_index+100*mask_index+10*budget_index+null_index; all indices0based. Random losses averaged across5seeds; no ensemble or best seed.','capacity':'All methods cover all source objects with exactly K nonempty groups. Random matches candidate group-size multiset, not artificial slot ordering. All methods sorted by actual minimum member ID; K=n must recover identical singleton/source predictions, including ties.','prediction':'Same E0.5 standalone centroid/label predictor, min(5,K) nearest prototypes; both uniform/group-mass votes and prior alpha0/.5 reported for every constructor, no best-point selection.','numeric_bytes':'8*[K*(d+q+1)+4*d+q] for float64 centroids/labels/scaling/weights/p and int64 masses/selected indices; excludes scalar/Python metadata, training memory and source caches. Same feature subset acquisition cost throughout.','freeze':'All48 prediction bundles frozen before internal validation labels are scored. All source arrays cache/hash verified. Outer test IDs excluded.','claim_boundary':'This new budgeted hierarchy has no old O1 eligibility or objectwise guarantee; no global-risk optimum, external-selector superiority or novelty claim. Capacity/risk curves and matched comparisons are development evidence.','source_hashes':{str(q):sha(q) for q in sources},'input_hashes':{str(q):sha(q) for q in inputs},'checks':json.loads((R/'CHECKS.json').read_text())}
 if (R/'PROTOCOL.json').exists():assert json.loads((R/'PROTOCOL.json').read_text())==p
 else:save(R/'PROTOCOL.json',p)
 print('FROZEN',sha(R/'PROTOCOL.json'),flush=True)
def worker(fi,fold):
 p=verify();name=p['families'][fi]['family'];out=R/'cases'/name/f'fold_{fold}';out.mkdir(parents=True,exist_ok=True);s=json.loads((PRIVATE/name/'repeat_1/split_PRIVATE.json').read_text());pool=np.array(s['train_indices'][:192]);folds=np.array_split(np.random.default_rng(202611134000+10000*fi+1000).permutation(len(pool)),3);iv=folds[fold];fit=pool[np.setdiff1d(np.arange(len(pool)),iv)];val=pool[iv];assert set(fit).isdisjoint(val) and not(set(fit)|set(val))&set(s['test_indices']);Xa=np.load(D/f'{name}_X.npy',mmap_mode='r');La=np.load(D/f'{name}_L.npy',mmap_mode='r');X=Xa[fit];L=La[fit];Q=Xa[val];start=time.perf_counter();m=CalibratedPrototypeModel(X,L,zeta=.5);masks={'Full':tuple(range(m.m)),'cost40':tuple(next(x['indices'] for x in s['masks'] if x['name']=='b0_c40'))};budgets=[max(1,pct*m.n//100) for pct in PCTS];pred={};stats=[]
 for mi,(mask,P) in enumerate(masks.items()):
  for gi,g in enumerate(['U','G']):
   raw=PrototypePredictor(m,P,g);base=raw.predict(Q[:,P]);assert np.array_equal(base,m.predict_selected(Q[:,P],P,g,readout='raw'));pred[f'{mask}__{g}__raw0']=base;pred[f'{mask}__{g}__rawhalf']=.5*base+.5*m.p;dist,Y=geometry(m,P,g);supervised=bisection_path(dist,L,budgets,.5);geometric=bisection_path(dist,L,budgets,0.)
   for bi,(pct,k) in enumerate(zip(PCTS,budgets)):
    partitions={'supervised':supervised[k],'geometric':geometric[k],'lloyd':lloyd(dist,k)};byte=None
    for method,groups in partitions.items():
     model=PrototypePredictor(m,P,g,groups);expected=8*(k*(len(P)+L.shape[1]+1)+4*len(P)+L.shape[1]);assert model.array_bytes()==expected
     if byte is None:byte=model.array_bytes()
     assert model.array_bytes()==byte
     for vote in ['uniform','mass']:
      value=model.predict(Q[:,P],vote=='mass')
      if k==m.n:assert np.array_equal(value,base)
      for alpha in [0.,.5]:pred[f'{mask}__{g}__K{pct}__{method}__{vote}__a{alpha}']=(1-alpha)*value+alpha*m.p
     stats.append({'mask':mask,'geometry':g,'budget_percent':pct,'method':method,'K':k,'n':m.n,'array_bytes':byte,'raw_array_bytes':raw.array_bytes(),'array_byte_fraction':byte/raw.array_bytes(),'groups':groups})
    values={(vote,alpha):[] for vote in ['uniform','mass'] for alpha in [0.,.5]}
    for j in range(5):
     groups=random_matched(supervised[k],m.n,202611136000+100000*fi+10000*fold+1000*gi+100*mi+10*bi+j);model=PrototypePredictor(m,P,g,groups);assert model.array_bytes()==byte;assert sorted(model.masses.tolist())==sorted(map(len,supervised[k]))
     for vote in ['uniform','mass']:
      value=model.predict(Q[:,P],vote=='mass')
      if k==m.n:assert np.array_equal(value,base)
      for alpha in [0.,.5]:values[(vote,alpha)].append((1-alpha)*value+alpha*m.p)
    for (vote,alpha),v in values.items():pred[f'{mask}__{g}__K{pct}__random__{vote}__a{alpha}']=np.stack(v)
 pred['plain_mean']=np.tile(m.p,(len(val),1));np.savez_compressed(out/'predictions_PRIVATE.npz',**pred);save(out/'record_PRIVATE.json',{'family':name,'fold':fold,'fit_indices':fit.tolist(),'validation_indices':val.tolist(),'n_fit':m.n,'n_validation':len(val),'protocol_sha256':sha(R/'PROTOCOL.json'),'predictions_sha256':sha(out/'predictions_PRIVATE.npz'),'statistics':stats,'wall_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024});print('FROZEN',name,fold,flush=True)
def run():
 p=verify()
 def one(case):
  fi,k=case;out=R/'cases'/p['families'][fi]['family']/f'fold_{k}';out.mkdir(parents=True,exist_ok=True)
  with open(out/'worker.log','w') as log:ret=subprocess.run([sys.executable,str(R/'run.py'),'worker',str(fi),str(k)],stdout=log,stderr=subprocess.STDOUT)
  assert ret.returncode==0,case;print('COMPLETE',p['families'][fi]['family'],k,flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(one,[(i,k) for i in range(16) for k in range(3)]))
 save(R/'ALL_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(R/'PROTOCOL.json'),'records':{str(q.relative_to(R)):sha(q) for q in sorted((R/'cases').rglob('record_PRIVATE.json'))}});print('ALL48 FROZEN',flush=True)
def score():
 verify();frozen=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(frozen['records'])==48;rows=[]
 for name,h in frozen['records'].items():
  path=R/name;assert sha(path)==h;c=json.loads(path.read_text());assert sha(path.parent/'predictions_PRIVATE.npz')==c['predictions_sha256'];a=np.load(path.parent/'predictions_PRIVATE.npz');y=np.load(D/f"{c['family']}_L.npy",mmap_mode='r')[c['validation_indices']]
  for key in a.files:
   values=list(a[key]) if a[key].ndim==3 else [a[key]];loss=[float(np.square(v-y).sum(1).mean()) for v in values]
   parts=key.split('__')
   if len(parts)==6:mask,g,k,method,vote,alpha=parts;pct=int(k[1:]);alpha=float(alpha[1:])
   elif len(parts)==3:mask,g,method=parts;pct=100;vote='NA';alpha=0. if method=='raw0' else .5
   else:mask,g,method,pct,vote,alpha='NA','NA','plain_mean',0,'NA',1.
   rows.append({'family':c['family'],'fold':c['fold'],'mask':mask,'geometry':g,'budget_percent':pct,'method':method,'vote':vote,'alpha':alpha,'n_validation':len(y),'brier':float(np.mean(loss)),'seed_briers':loss})
 summary=[]
 for key in sorted(set((r['family'],r['mask'],r['geometry'],r['budget_percent'],r['method'],r['vote'],r['alpha']) for r in rows)):
  rr=[r for r in rows if (r['family'],r['mask'],r['geometry'],r['budget_percent'],r['method'],r['vote'],r['alpha'])==key];summary.append(dict(zip(['family','mask','geometry','budget_percent','method','vote','alpha'],key),brier=sum(r['brier']*r['n_validation'] for r in rr)/sum(r['n_validation'] for r in rr)))
 save(R/'RESULTS.json',{'scope':'Consulted training-internal development only','protocol_sha256':sha(R/'PROTOCOL.json'),'rows':rows,'summary':summary,'new_outer_test_scored':False});print('SCORED',len(rows),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='worker':worker(int(sys.argv[2]),int(sys.argv[3]))
 else:globals()[sys.argv[1]]()
