"""Schema/group feasibility only. Never fit predictors or evaluate predictive outcomes."""
from pathlib import Path
import urllib.request,json,hashlib,csv,unicodedata,re,collections,os
ROOT=Path(__file__).resolve().parent.parent;PRIVATE=ROOT/'private';RAW=PRIVATE/'raw';RAW.mkdir(parents=True,exist_ok=True)
CHAOS='2a999dc4a672df4ef87b9c7134247201352dee81';DICES='b5596d9edd585361967991a591abc7b11fb1f7a3';HF='eb7cc18dbfa0f161d93a2b22c7856ca0faafcf2b'
FILES=[('chaos_README.txt',f'https://huggingface.co/datasets/earino/chaosnli/resolve/{HF}/raw/README.txt','b02af8460b221a1a1a629da0d528a87e820a7d76f2772599360608e51de50f1b'),('chaosNLI_snli.jsonl',f'https://huggingface.co/datasets/earino/chaosnli/resolve/{HF}/raw/chaosNLI_snli.jsonl','99f9015ddda7d85f66a087452bc30d53974314fe27e7d589e2f41ad44bd509c1'),('chaosNLI_mnli_m.jsonl',f'https://huggingface.co/datasets/earino/chaosnli/resolve/{HF}/raw/chaosNLI_mnli_m.jsonl','8eb49b589488e7b1a9ec95fb8a864bd50f0509b4f808eed0aed3f8167617664d'),('DICES990.csv',f'https://raw.githubusercontent.com/google-research-datasets/dices-dataset/{DICES}/990/diverse_safety_adversarial_dialog_990.csv',None),('DICES990_README.md',f'https://raw.githubusercontent.com/google-research-datasets/dices-dataset/{DICES}/990/README.md',None)]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def canon(x):return ' '.join(unicodedata.normalize('NFKC',x).casefold().split())
def fetch(name,url,expected):
 p=RAW/name;note='verified existing cache' if p.exists() else 'new source not in prior project cache'
 if not p.exists():
  temp=p.with_suffix('.download');total=0
  with urllib.request.urlopen(url,timeout=60) as response,temp.open('wb') as out:
   while data:=response.read(1024**2):
    total+=len(data)
    if total>100*1024**2:raise ValueError('Declared100MiB per-source cap exceeded')
    out.write(data)
  temp.replace(p)
 h=sha(p)
 if expected is not None:assert h==expected,name
 return {'name':name,'source_url':url,'sha256':h,'bytes':p.stat().st_size,'resolution':note}

def main():
 manifests=[]
 for name,url,expected in FILES:
  manifests.append(fetch(name,url,expected));print('CACHED',name,manifests[-1]['bytes'],flush=True)
 report={'scope':'Only source/validity/grouping feasibility; no predictor fit, tuning, predictions, risk or model ranking. No demographic/risk-based data selection.','source_commits':{'ChaosNLI':CHAOS,'DICES':DICES,'ChaosNLI_HF_mirror':HF},'sources':manifests,'tasks':{}}
 for name in ['chaosNLI_snli.jsonl','chaosNLI_mnli_m.jsonl']:
  seen=set();prem=set();groups=set();imageids=0;n=0
  for line in (RAW/name).open():
   x=json.loads(line);uid=x['uid'];assert uid not in seen;seen.add(uid);assert len(x['label_count'])==len(x['label_dist'])==3 and sum(x['label_count'])==100;assert all(abs(a/100-b)<1e-12 for a,b in zip(x['label_count'],x['label_dist']));assert set(x['example'])>={'premise','hypothesis'};c=canon(x['example']['premise']);assert c and canon(x['example']['hypothesis']);prem.add(c)
   if name.endswith('snli.jsonl'):
    assert '.jpg#' in uid;g=uid.split('.jpg#')[0]+'.jpg';imageids+=1
   else:g=c
   groups.add(g);n+=1
  report['tasks'][name]={'objects':n,'label_count':3,'ratings_per_object':100,'unique_normalized_premises':len(prem),'base_group_count':len(groups),'snli_image_id_parseable_rows':imageids,'group_rule':'Union matching original SNLI image ID and normalized premise; MNLI normalized premise only. Not author/document or image-person identity.'}
 item={};variants=collections.defaultdict(set);raters=set();ratings=0;values=collections.Counter();item_raters=collections.defaultdict(set);dup=0;fields=None
 with (RAW/'DICES990.csv').open(newline='') as f:
  reader=csv.DictReader(f);fields=reader.fieldnames;assert set(fields)>={'item_id','context','response','rater_id','Q_overall'}
  for row in reader:
   key=row['item_id'];text=(row['context'],row['response']);variants[key].add((canon(text[0]),canon(text[1])));item[key]=text;assert row['rater_id'];raters.add(row['rater_id']);rating=row['Q_overall'];values[rating]+=1;assert rating in ['Yes','No','Unsure'],repr(rating);dup+=row['rater_id'] in item_raters[key];item_raters[key].add(row['rater_id']);ratings+=1
 assert dup==0,'Duplicate item/rater rows require a pre-frozen resolution rule'
 excluded=sorted(k for k,v in variants.items() if len(v)>1);eligible={k:v for k,v in item.items() if k not in excluded};(PRIVATE/'DICES_METADATA_EXCLUSIONS_PRIVATE.json').write_text(json.dumps({'rule':'Exclude entire item_id if it maps to multiple normalized context-response pairs, without looking at labels','excluded_item_ids':excluded},indent=2)+'\n');contexts={canon(c) for c,r in eligible.values()};counts=[len(item_raters[k]) for k in eligible]
 report['tasks']['DICES990']={'annotation_rows':ratings,'released_objects':len(item),'eligible_objects':len(eligible),'ambiguous_text_item_exclusions':len(excluded),'raters':len(raters),'rating_categories':sorted(values),'min_ratings_per_item':min(counts),'max_ratings_per_item':max(counts),'unique_normalized_contexts':len(contexts),'empty_context_items':sum(not canon(c) for c,r in eligible.values()),'duplicate_item_rater_pairs':dup,'available_id_roles':'item_id=conversation, rater_id=annotator; neither is original image-subject identity','group_rule':'Union item_id, exact normalized nonempty context and identical normalized context-response pair; do not union all empty contexts.'}
 (PRIVATE/'SOURCE_MANIFEST_PRIVATE.json').write_text(json.dumps(report,indent=2)+'\n');public={k:v for k,v in report.items()};public['sources']=[{k:v for k,v in x.items() if k!='resolution'} for x in manifests];(ROOT/'source/PREFLIGHT_PUBLIC.json').write_text(json.dumps(public,indent=2)+'\n');print(json.dumps(report['tasks'],indent=2))
if __name__=='__main__':main()
