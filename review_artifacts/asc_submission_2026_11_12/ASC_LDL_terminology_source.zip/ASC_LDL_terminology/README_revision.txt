Entry: main_short_flowcharts.tex
Compile: latexmk -pdf main_short_flowcharts.tex
Review-aligned revision: 2026-11-13
See REVISION_NOTES.md for addressed issues, validation and remaining evidence limits.
Frozen experiment code, all pre-existing numeric table rows and plotted result data are unchanged.
