"""Post-pilot shrinkage/neighbor diagnostics, explicitly exploratory."""
from pathlib import Path
import json,statistics as st,numpy as np
from run_pilot import R,DATA,CORE
import sys
sys.path.insert(0,str(CORE))
from baseline_revision.prediction_evaluation import metrics
rows=[]
for record in sorted((R/'cases').glob('*/*/*/record.json')):
 c=json.loads(record.read_text());pred=np.load(record.parent/'predictions.npz');rr=np.load(record.parent/'training_readouts.npz');truth=np.load(DATA/(c['dataset']+'_L.npy'),mmap_mode='r')[c['validation_indices']];global_prediction=np.tile(rr['r__Full__U__raw'].mean(0),(len(truth),1));mean_brier=metrics(truth,global_prediction)['brier']
 for mask in ['Full','cost40']:
  u=pred[f'neighbors__{mask}__U'];l=pred[f'neighbors__{mask}__L'];same=np.all(np.sort(u,axis=1)==np.sort(l,axis=1),axis=1)
  rows.append({'dataset':c['dataset'],'repeat':c['repeat'],'fold':c['fold'],'mask':mask,'global_mean_brier':mean_brier,'L_legacy_brier':metrics(truth,pred[f'pred__{mask}__L__ball_global_legacy'])['brier'],'L_raw_brier':metrics(truth,pred[f'pred__{mask}__L__raw'])['brier'],'L_residual_brier':metrics(truth,pred[f'pred__{mask}__L__ball_residual'])['brier'],'U_L_same_neighbor_set_fraction':float(same.mean()),'U_L_same_residual_training_representation':bool(np.array_equal(rr[f'r__{mask}__U__ball_residual'],rr[f'r__{mask}__L__ball_residual'])),'mean_W':c['mean_local_weight']})
summary=[]
for d in ['Yeast_cold','SCUT_FBP','Human_Gene']:
 for mask in ['Full','cost40']:
  block=[x for x in rows if (x['dataset'],x['mask'])==(d,mask)];summary.append({'dataset':d,'mask':mask,**{k:st.mean(x[k] for x in block) for k in ['global_mean_brier','L_legacy_brier','L_raw_brier','L_residual_brier','U_L_same_neighbor_set_fraction','U_L_same_residual_training_representation','mean_W']}})
result={'status':'Post-pilot exploratory diagnostic, not a predeclared primary comparison','reason':'Legacy global readout performed better than residual/raw; inspect shrinkage and neighbor changes before attributing benefits to granules','summary':summary,'source':'Only already-frozen predictions/readouts and the same internal validation labels; no outer-test scoring'};(R/'GLOBAL_MEAN_DIAGNOSTIC.json').write_text(json.dumps(result,indent=2));print('Post-pilot exploratory shrinkage diagnostic saved.')
