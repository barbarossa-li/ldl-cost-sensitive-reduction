"""Score already-frozen training-internal predictions; no outer-test scoring."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,csv,hashlib,statistics as st
import numpy as np
from model import CORE
from run_pilot import sha,save,verify,DATA,R
sys.path.insert(0,str(CORE))
from baseline_revision.prediction_evaluation import metrics

def run():
 verify();frozen=json.loads((R/'ALL_E0_PREDICTIONS_FROZEN.json').read_text());assert frozen['protocol_sha256']==sha(R/'E0_PROTOCOL.json');rows=[];cases=[]
 for name,digest in frozen['records'].items():
  p=R/name;assert sha(p)==digest;case=json.loads(p.read_text());parent=json.loads((CORE/'expansion25/splits'/case['dataset']/f"repeat_{case['repeat']}.json").read_text());fit=set(case['fit_indices']);val=set(case['validation_indices']);assert fit.isdisjoint(val) and fit|val<=set(parent['train_indices']) and not (fit|val)&set(parent['test_indices'])
  target=np.asarray(np.load(DATA/f"{case['dataset']}_L.npy",mmap_mode='r')[case['validation_indices']],float)
  pp=p.parent/'predictions.npz';assert sha(pp)==case['prediction_file_sha256'];a=np.load(pp);mapping={(x['mask'],x['weight'],x['readout']):x for x in case['rows']}
  for key in a.files:
   if not key.startswith('pred__'):continue
   _,mask,weight,readout=key.split('__');pred=a[key];score=metrics(target,pred);base=mapping[mask,weight,readout].copy();base.update(score)
   base['validation_label_scope']='prior_outer_training_internal_fold';base['mean_local_weight_shared']=case['mean_local_weight'];base['worker_peak_rss_shared_bytes']=case['worker_peak_rss_bytes']
   if weight!='E':
    ids=a[f'neighbors__{mask}__{weight}'];covered=a[f'covered__{mask}__{weight}'];counts=np.bincount(ids.ravel(),minlength=case['fit_n']);frequency=counts/counts.sum();base['neighbor_unique_sources']=int(np.count_nonzero(counts));base['neighbor_max_source_share']=float(frequency.max());base['neighbor_top5_source_share']=float(np.sort(frequency)[-5:].sum());base['neighbor_hhi']=float(np.sum(frequency**2));base['neighbor_covered_fraction']=float(covered[ids].mean())
   rows.append(base)
  cases.append({k:case[k] for k in ['dataset','repeat','fold','fit_n','validation_n','parent_training_only','old_outer_test_indices_not_used','mean_local_weight','maximum_local_weight','worker_peak_rss_bytes']})
 assert len(cases)==27 and len(rows)==540
 fields=list(dict.fromkeys(k for row in rows for k in row))
 with (R/'pilot_metrics.csv').open('w',newline='') as out:w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows(rows)
 summary=[]
 for dataset in ['Yeast_cold','SCUT_FBP','Human_Gene']:
  for mask in ['Full','cost40']:
   for weight in ['U','G','L','E']:
    for readout in (['raw','ball_residual','ball_global_legacy'] if weight!='E' else ['raw']):
     block=[r for r in rows if (r['dataset'],r['mask'],r['weight'],r['readout'])==(dataset,mask,weight,readout)];assert len(block)==9
     summary.append({'dataset':dataset,'mask':mask,'weight':weight,'readout':readout,'fold_cases':9,'brier_mean':st.mean(r['brier'] for r in block),'brier_sd_descriptive':st.stdev(r['brier'] for r in block),'tv_mean':st.mean(r['tv'] for r in block),'kl_mean':st.mean(r['kl'] for r in block),'js_mean':st.mean(r['js'] for r in block),'coverage_mean':None if weight=='E' else st.mean(r['coverage'] for r in block),'neighbor_covered_fraction_mean':None if weight=='E' else st.mean(r['neighbor_covered_fraction'] for r in block),'prototype_slots_mean':None if weight=='E' else st.mean(r['prototype_slots_residual'] for r in block),'mean_local_weight':st.mean(r['mean_local_weight_shared'] for r in block)})
 with (R/'pilot_summary.csv').open('w',newline='') as out:w=csv.DictWriter(out,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 save(R/'PILOT_RESULTS.json',{'protocol_sha256':sha(R/'E0_PROTOCOL.json'),'prediction_freeze_sha256':sha(R/'ALL_E0_PREDICTIONS_FROZEN.json'),'summary':summary,'cases':cases,'metric_rows':len(rows),'all_27_fit_validation_disjoint':True,'all_validation_cases_inside_old_training':True,'outer_test_scored':False,'scope':'Descriptive development folds only, overlapping repeats, no significance or cross-family performance claim. Raw vs residual and legacy remain distinct.','metric_csv_sha256':sha(R/'pilot_metrics.csv'),'summary_csv_sha256':sha(R/'pilot_summary.csv')})
 print('SCORED 540 INTERNAL-VALIDATION ROWS; OUTER-TEST SCORED: FALSE',flush=True)
if __name__=='__main__':run()
