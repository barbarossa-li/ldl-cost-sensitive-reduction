from pathlib import Path
import argparse,json
import numpy as np
from audit import sha,recompute

def audit(parent,e13,e14,known,novel,protocol):
 result={}
 for label,run,expected in [('e13',e13,1272),('e14',e14,530)]:
  fr=json.loads((run/'ALL_PREDICTIONS_FROZEN.json').read_text());res=json.loads((run/'RESULTS_PUBLIC.json').read_text());assert len(fr['records'])==53;lookup={(r['stage'],r['family'],r['fold'],r['key']):r for r in res['rows']};assert len(lookup)==expected;maxerr={k:0. for k in ['brier','chebyshev','clark','canberra','kl','cosine','intersection']};count=anchors=perms=derived=0
  for name,h in fr['records'].items():
   file=run/name;assert sha(file)==h;rec=json.loads(file.read_text());stage=rec['stage'];oldfile=parent/name;oldfr=json.loads((parent/stage/'ALL_PREDICTIONS_FROZEN.json').read_text());assert sha(oldfile)==oldfr['records'][str(Path(name).relative_to(stage))];old=json.loads(oldfile.read_text())
   for field in ['fit_indices','validation_indices','excluded_original_test_indices']:assert rec[field]==old[field]
   pf=file.parent/'predictions_PRIVATE.npz';opf=oldfile.parent/'predictions_PRIVATE.npz';assert sha(pf)==rec['predictions_sha256'] and sha(opf)==old['predictions_sha256'];f=next(f for f in protocol['stages']['e11']['families'] if f['family']==rec['family']) if stage=='e11' else protocol['stages']['e12']['family'];folder=known if stage=='e11' else novel;yp=folder/(f['family']+'_L.npy');assert sha(yp)==f['L_sha256'];y=np.load(yp,mmap_mode='r')[rec['validation_indices']]
   if label=='e13':
    fi=next(i for i,f in enumerate(protocol['stages']['e11']['families']) if f['family']==rec['family']) if stage=='e11' else 16
    for j in range(5):
     v=rec['permutations'][str(j)];seed=202611150100+1000*fi+100*rec['fold']+j;assert v['seed']==seed;assert np.array_equal(v['label_permutation'],np.random.default_rng(seed).permutation(len(rec['fit_indices'])));assert np.array_equal(v['axis_permutation'],np.random.default_rng(seed+500000).permutation(f['m']));perms+=2
    for mask in ['Full','cost40']:assert len({(s['K'],s['array_bytes']) for k,s in rec['statistics'].items() if k.startswith(mask+'__')})==1
   with np.load(pf) as arr,np.load(opf) as raw:
    for key in arr.files:
     v=arr[key];assert v.shape==y.shape and np.isfinite(v).all() and (v>=0).all() and abs(v.sum(1)-1).max()<=1e-5;row=lookup[stage,rec['family'],rec['fold'],key]
     for metric,value in recompute(y,v).items():
      error=abs(value-row[metric]);assert error<1e-11;maxerr[metric]=max(error,maxerr[metric])
     count+=1
     if label=='e13' and key.split('__')[1] in ['GG50','UU50']:assert np.array_equal(v,raw[key]);anchors+=1
     if label=='e14':
      oldkey=key.removesuffix('__half_prior');assert np.array_equal(v,.5*raw[oldkey]+.5*raw['plain_mean']);derived+=1
  assert count==expected;result[label]={'passed':True,'cases':53,'aggregate_rows':count,'metric_values_checked':count*7,'max_absolute_metric_error':maxerr,'exact_parent_reference_arrays':anchors,'verified_predeclared_permutations':perms,'exact_half_prior_derivations':derived,'independent_new_datasets':0}
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--parent',type=Path,required=True);p.add_argument('--e13',type=Path,required=True);p.add_argument('--e14',type=Path,required=True);p.add_argument('--known-data',type=Path,required=True);p.add_argument('--novel-data',type=Path,required=True);p.add_argument('--protocol',type=Path,required=True);a=p.parse_args();print(json.dumps(audit(a.parent,a.e13,a.e14,a.known_data,a.novel_data,json.loads(a.protocol.read_text())),indent=2))
