from pathlib import Path
import json,subprocess,sys,concurrent.futures,hashlib,time,os
R=Path(__file__).resolve().parent;M=Path('/workspace/work/ai_mechanism_v1_20261113');P=Path('/workspace/work/ai_mechanism_v1_private_20261113');D=Path('/workspace/work/asc_experiments/data');protocol=json.loads((M/'PROTOCOL.json').read_text());ph=hashlib.sha256((M/'PROTOCOL.json').read_bytes()).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def one(case):
 d,r=case;out=P/d/f'repeat_{r}';record=out/'record_PRIVATE.json';start=time.monotonic()
 if record.exists():
  c=json.loads(record.read_text());assert c['protocol_sha256']==ph and sha(out/'predictions_PRIVATE.npz')==c['prediction_sha256'] and sha(out/'split_PRIVATE.json')==c['split_sha256'];print('REUSE',d,r,flush=True);return {'family':d,'repeat':r,'status':'reused','elapsed':0}
 env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
 with open(out/'worker.log','w') as log:p=subprocess.run([sys.executable,str(M/'runner.py'),'worker','--data',str(D),'--output',str(P),'--family',d,'--repeat',str(r)],stdout=log,stderr=subprocess.STDOUT,env=env)
 result={'family':d,'repeat':r,'status':'complete' if p.returncode==0 else 'failed','returncode':p.returncode,'elapsed':time.monotonic()-start};print(json.dumps(result),flush=True);return result
cases=[(f['family'],r) for f in protocol['families'] for r in range(1,6)]
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for row in pool.map(one,cases):rows.append(row)
(R/'EXECUTION.json').write_text(json.dumps({'protocol_sha256':ph,'workers':2,'rows':rows},indent=2));assert all(r['status']!='failed' for r in rows),'Some cases failed; retained logs, no scoring'
subprocess.run([sys.executable,str(M/'runner.py'),'freeze','--data',str(D),'--output',str(P)],check=True)
print('ALL80 FROZEN - SCORING NOT YET RUN',flush=True)
