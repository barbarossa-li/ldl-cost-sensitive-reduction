"""Check existing cached bytes before any download; raw data stays private."""
from pathlib import Path
import argparse,json,hashlib,urllib.request
import numpy as np
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def one(folder,f):
 folder.mkdir(parents=True,exist_ok=True)
 if all((folder/f"{f['family']}_{a}.npy").exists() and sha(folder/f"{f['family']}_{a}.npy")==f[a+'_sha256'] for a in ['X','L']):return f['family']+' cached and verified'
 file=folder/(f['family']+'.mat')
 if not file.exists() or sha(file)!=f['mat_sha256']:
  tmp=file.with_suffix('.download');urllib.request.urlretrieve(f['url'],tmp)
  if sha(tmp)!=f['mat_sha256']:raise ValueError('MAT source hash mismatch')
  tmp.replace(file)
 data=loadmat(file);X=np.asarray(data['features'],dtype=float);L=np.asarray(data['labels'],dtype=float)
 if not np.isfinite(X).all() or not np.isfinite(L).all() or np.any(L<0) or np.any(L.sum(1)<=0):raise ValueError('Invalid source matrix')
 L=L/L.sum(1,keepdims=True)
 for a,array in [('X',X),('L',L)]:
  file=folder/f"{f['family']}_{a}.npy";np.save(file,array)
  if sha(file)!=f[a+'_sha256']:raise ValueError('NPY hash mismatch')
 return f['family']+' converted and verified'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--known-data',type=Path,required=True);p.add_argument('--novel-data',type=Path,required=True);a=p.parse_args();protocol=json.loads((ROOT/'PROTOCOL.json').read_text())
 for f in protocol['stages']['e11']['families']:print(one(a.known_data,f),flush=True)
 print(one(a.novel_data,protocol['stages']['e12']['family']),flush=True)
