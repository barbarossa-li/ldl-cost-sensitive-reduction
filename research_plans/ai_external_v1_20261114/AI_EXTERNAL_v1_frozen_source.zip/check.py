"""Synthetic implementation checks only; real-data outcomes not consulted."""
from pathlib import Path
import json,tempfile,time
import numpy as np
from runner import external,own,novel_design,known_design,blocks,valid,metrics

def main():
 rng=np.random.default_rng(23);X=rng.uniform(size=(48,7));L=rng.dirichlet(np.ones(4),48);Q=rng.uniform(size=(9,7));masks={'Full':tuple(range(7)),'cost40':(0,2)};checks=[]
 a,diag,fail=external(X,L,Q,masks,0,0,epochs=2);assert not fail and len(a)==10
 b,_,fail2=external(X,L,Q,masks,0,0,epochs=2);assert not fail2
 for key in a:assert np.array_equal(a[key],b[key])
 checks.append('All external variants are valid and deterministic for a repeated synthetic fit, including native and training-gamma RKNN')
 p,st=own(X,L,Q,masks);assert len(p)==17
 for mask in masks:
  assert st[f'{mask}__UU50']['K']==st[f'{mask}__GG50']['K'] and st[f'{mask}__UU50']['array_bytes']==st[f'{mask}__GG50']['array_bytes']
 checks.append('Exact-budget own references and matching numeric array capacities')
 # A heldout label is never an argument to either external() or own().
 fullx=rng.uniform(size=(5200,4));fullx[5100:]=fullx[:100];fully=rng.dirichlet(np.ones(3),5200);cases,m=novel_design(fullx);fit,held=cases[0];changed=fully.copy();changed[held]=[1.,0.,0.]
 pa,_=own(fullx[fit],fully[fit],fullx[held],m);pb,_=own(fullx[fit],changed[fit],fullx[held],m)
 for key in pa:assert np.array_equal(pa[key],pb[key])
 assert np.array_equal(fully[fit],changed[fit])
 checks.append('Five prospective allocations are exact-feature-group disjoint; heldout-label replacement cannot affect fitting inputs or own predictions')
 # Query-batch-invariant fixed-gamma prediction is tested algebraically using the same train-only gamma.
 from sklearn.metrics.pairwise import rbf_kernel
 from pyldl.algorithms.utils import pairwise_euclidean
 gamma=1/(2*np.mean(pairwise_euclidean(X,X))**2)
 assert np.array_equal(rbf_kernel(Q,X,gamma=gamma),np.vstack([rbf_kernel(Q[:4],X,gamma=gamma),rbf_kernel(Q[4:],X,gamma=gamma)]))
 checks.append('Training-only gamma fixes kernel bandwidth independently of query-batch composition')
 d=metrics(np.array([[1.,0.],[0.,1.]]),np.array([[.75,.25],[.5,.5]]));assert d['brier']==.3125 and np.isfinite(list(d.values())).all()
 checks.append('Metric zero-label conventions and hand-computed Brier example')
 print(json.dumps({'passed':True,'checks':checks,'scope':'Synthetic checks only, not benchmark evidence'},indent=2))
if __name__=='__main__':main()
