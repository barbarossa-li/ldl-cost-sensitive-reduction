from pathlib import Path
import argparse,shutil,subprocess,sys,json,hashlib
B=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--run',action='store_true');p.add_argument('--images',type=Path);a=p.parse_args();out=a.output.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Use a new empty output directory; recorded runs are immutable.')
out.mkdir(parents=True,exist_ok=True)
for file in (B/'recorded_source').glob('*.py'):
 text=file.read_text().replace('/workspace/work/asc_review/code_bundle',str(B/'frozen_core')).replace('/workspace/work/asc_review/light/LDL_25_results',str(B/'reference')).replace('/workspace/work/asc_review/repro/ASC_REVIEW_REPRODUCIBILITY_v2/supplementary/m1_effects',str(B/'reference')).replace('/workspace/work/asc_review/repro/ASC_REVIEW_REPRODUCIBILITY_v2/supplementary/tolerance_envelope/results',str(B/'reference/tolerance'))
 (out/file.name).write_text(text)
(out/'data').mkdir(exist_ok=True)
if not a.run:
 print('Prepared',out,'; use a new output with --run to execute.');raise SystemExit(0)
def run(*args):subprocess.run([sys.executable,*map(str,args)],cwd=out,check=True)
run(out/'download_inputs.py');run(out/'experiment.py','prepare');run(out/'experiment.py','run');run(out/'audit_records.py');run(out/'evaluate.py')
checks=[]
for expected in json.loads((B/'reference/expected_original_replays.json').read_text()):
 d,r=expected['dataset'],expected['repeat'];actual=json.loads((out/'results'/d/f'repeat_{r}'/'full_max/selection.json').read_text())
 checks.append(dict(dataset=d,repeat=r,reference_hash_matches=actual['reference_errors_sha256']==expected['reference_errors_sha256'],final_hash_matches=actual['final_errors_sha256']==expected['final_errors_sha256'],subset_matches=actual['result']['selected']==expected['selected']))
(out/'expected_hash_comparison.json').write_text(json.dumps(checks,indent=2));print(checks)
if a.images:
 shutil.copy2(a.images.resolve(),out/'data/SCUT-FBP5500_v2.1.zip');run(out/'image_replay.py','prepare');run(out/'image_replay.py','run')
