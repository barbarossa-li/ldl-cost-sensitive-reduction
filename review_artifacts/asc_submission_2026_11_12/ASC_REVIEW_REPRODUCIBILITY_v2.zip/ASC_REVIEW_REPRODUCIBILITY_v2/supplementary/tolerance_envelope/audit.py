"""Validate the recorded-pool envelope and its endpoint summary."""
from pathlib import Path
import json
import math

root = Path(__file__).resolve().parent
candidates = json.loads((root/"results/candidate_summaries.json").read_text())
plan = json.loads((root/"results/frontier_plan.json").read_text())
assessment = json.loads((root/"results/endpoint_assessment.json").read_text())
summary = json.loads((root/"results/SUMMARY.json").read_text())
assert len(candidates) == len({tuple(p["selected"]) for p in candidates}) == 2043
assert sum(p["origin"]=="original" for p in candidates) == 1531
assert sum(p["origin"]=="independent" for p in candidates) == 512
for point in candidates:
    assert point["selected"] == sorted(set(point["selected"]))
    assert point["attributes"] == len(point["selected"])
    assert all(isinstance(i,int) and 0<=i<512 for i in point["selected"])
    assert math.isfinite(point["maximum_increase"]) and point["maximum_increase"]>=0
assert assessment["complete"] and len(assessment["rows"]) == len(plan["frontier"]) == 6
for point, row, small in zip(plan["frontier"],assessment["rows"],summary["frontier_endpoints"]):
    optimum=min(
        (p for p in candidates if p["maximum_increase"]<=point["maximum_increase"]),
        key=lambda p:(p["attributes"],p["selected"]),
    )
    assert point == optimum
    numeric_optimum=min(
        (p for p in candidates if p["maximum_increase"]<=point["maximum_increase"]+1e-12),
        key=lambda p:(p["attributes"],p["selected"]),
    )
    assert point["selected"] == numeric_optimum["selected"]
    assert row["attributes"] == small["attributes"] == point["attributes"]
    assert row["maximum_increase"] == small["tolerance_knot"] == point["maximum_increase"]
    assert row["digest_reproduced"] is True
    assert row["stored_training_bytes"] == 3300*4*point["attributes"]
    assert small["storage_MB"] == row["stored_training_bytes"]/1e6
    assert small["test_Brier"] == row["test"]["brier"]
    assert row["reference_correct_lost"]<=row["reference_correct_unique"]
    assert row["top2_reference_correct_lost"]<=row["top2_reference_correct"]
    assert row["pairwise_rank_worse"]<=row["pairwise_rank_eligible_objects"]
assert assessment["rows"][0]["attributes"]==512 and assessment["rows"][-1]["attributes"]==0
print("Recorded-pool envelope, six endpoint summaries and decision denominators verified.")
