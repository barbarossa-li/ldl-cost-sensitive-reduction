"""Text/ID/count feasibility only: no target proportions or model predictions."""
from pathlib import Path
import json,csv,collections
from design import *
ROOT=Path(__file__).resolve().parent.parent;P=ROOT/'private';RAW=P/'raw'
def main():
 result={};allrecords={}
 for ti,(task,filename) in enumerate([('ChaosSNLI','chaosNLI_snli.jsonl'),('ChaosMNLI','chaosNLI_mnli_m.jsonl'),('DICES990','DICES990.csv')]):
  if ti<2:
   rows=[json.loads(s) for s in (RAW/filename).open()];keys=[]
   for row in rows:
    kk=['premise:'+canon(row['example']['premise'])]
    if ti==0:kk.append('image:'+row['uid'].split('.jpg#')[0]+'.jpg')
    keys.append(kk)
   identifiers=[r['uid'] for r in rows];ratercounts=None
  else:
   excluded=set(json.loads((P/'DICES_METADATA_EXCLUSIONS_PRIVATE.json').read_text())['excluded_item_ids']);items={};raters=collections.defaultdict(set)
   for row in csv.DictReader((RAW/filename).open(newline='')):
    if row['item_id'] in excluded:continue
    items[row['item_id']]=(row['context'],row['response']);raters[row['item_id']].add(row['rater_id'])
   identifiers=sorted(items);keys=[]
   for k in identifiers:
    context,response=items[k];kk=['item:'+k,'pair:'+canon(context)+'\0'+canon(response)]
    if canon(context):kk.append('context:'+canon(context))
    keys.append(kk)
   trainraters,queryraters=rater_cohorts([x for rr in raters.values() for x in rr]);ratercounts={'train_cohort':len(trainraters),'query_cohort':len(queryraters),'minimum_fit_target_ratings':min(len(v&trainraters) for v in raters.values()),'minimum_query_target_ratings':min(len(v&queryraters) for v in raters.values())}
   assert ratercounts['minimum_fit_target_ratings']>=10 and ratercounts['minimum_query_target_ratings']>=10
  groups=connected_groups(keys);parts=folds(groups,202611180001+100*ti);case=[];private=[]
  for outer,held in enumerate(parts):
   fit=capped_fit(groups,held,202611180100+100*ti+outer);fitset=set(fit.tolist());localgroups=[np.array([i for i,g in enumerate(fit) if g in set(group.tolist())],int) for group in groups if set(group.tolist())<=fitset];inner=folds(localgroups,202611180200+100*ti+outer,3);assert min(len(fit)-len(x) for x in inner)>=64;case.append({'outer_fold':outer,'fit_objects':len(fit),'query_objects':len(held),'inner_query_sizes':[len(x) for x in inner]});private.append({'outer_fold':outer,'fit_ids':[identifiers[x] for x in fit],'query_ids':[identifiers[x] for x in held],'inner_query_fit_positions':[x.tolist() for x in inner]})
  result[task]={'objects':len(identifiers),'connected_groups':len(groups),'outer_cases':case,'rater_disjoint_feasibility':ratercounts};allrecords[task]=private
 (P/'PLANNED_PARTITIONS_PRIVATE.json').write_text(json.dumps(allrecords,indent=2)+'\n');(ROOT/'source/ELIGIBILITY_PUBLIC.json').write_text(json.dumps({'status':'Metadata-only feasibility; partitions are private; no predictive outcomes viewed','tasks':result},indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
