"""Label-independent grouping, partitions and train-only text features for planned E18."""
import unicodedata,hashlib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD

def canon(x):return ' '.join(unicodedata.normalize('NFKC',x).casefold().split())
def connected_groups(keys):
 parent=list(range(len(keys)));owner={}
 def find(x):
  while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
  return x
 for i,kk in enumerate(keys):
  for key in kk:
   if not key:continue
   if key in owner:
    a,b=find(i),find(owner[key]);parent[max(a,b)]=min(a,b)
   else:owner[key]=i
 groups={}
 for i in range(len(keys)):groups.setdefault(find(i),[]).append(i)
 return [np.array(v,int) for _,v in sorted(groups.items())]
def folds(groups,seed,k=5):
 if len(groups)<k:raise ValueError('Too few connected groups')
 out=[[] for _ in range(k)]
 for gi in np.random.default_rng(seed).permutation(len(groups)):
  j=min(range(k),key=lambda i:(len(out[i]),i));out[j].extend(groups[int(gi)].tolist())
 return [np.array(sorted(x),int) for x in out]
def capped_fit(groups,held,seed,cap=512):
 held=set(map(int,held));pool=[]
 for g in groups:
  overlap=held.intersection(map(int,g))
  if overlap and len(overlap)!=len(g):raise ValueError('A group crosses query and fitting pool')
  if not overlap:pool.append(g)
 result=[]
 for i in np.random.default_rng(seed).permutation(len(pool)):
  g=pool[int(i)]
  if len(result)+len(g)<=cap:result.extend(g.tolist())
 if len(result)<128:raise ValueError('Fewer than128 complete-group fitting objects')
 return np.array(sorted(result),int)
def rater_cohorts(raters,seed=202611180700):
 ids=sorted(set(raters));order=np.random.default_rng(seed).permutation(len(ids));n=7*len(ids)//10;return {ids[i] for i in order[:n]},{ids[i] for i in order[n:]}
class TextFeatures:
 def __init__(self):self.vectorizer=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_df=1.,max_features=20000,sublinear_tf=True,norm='l2',dtype=np.float64);self.svd=None
 def fit(self,texts):
  A=self.vectorizer.fit_transform(texts);rank=min(128,len(texts)-1,A.shape[1]-1)
  if rank<32:raise ValueError('Predeclared SVD feasibility minimum32 not met')
  self.svd=TruncatedSVD(n_components=rank,algorithm='randomized',n_iter=7,random_state=202611180099%(2**32));self.svd.fit(A);return self
 def transform(self,texts):return np.asarray(self.svd.transform(self.vectorizer.transform(texts)),np.float64)
