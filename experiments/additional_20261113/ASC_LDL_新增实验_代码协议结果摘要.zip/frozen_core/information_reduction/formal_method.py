"""GBIP-O1: objectwise-preserving complete-sweep deletion FROM FULL attributes.

The error oracle must be deterministic, training-only and use one fixed geometry
and repaired construction. No historical pool, warm start, exchange or test loss.
"""
import math
import numpy as np
from information_reduction.local_preservation import assess
from information_reduction.sweep_search import delete
VERSION='GBIP-O1'


def reduce_from_full(costs,error_oracle,global_variation,atol=1e-12):
    costs=tuple(float(c) for c in costs)
    if not costs or any(not math.isfinite(c) or c<=0 for c in costs):raise ValueError('Finite positive costs required')
    full=tuple(range(len(costs)));reference=np.asarray(error_oracle(full),float).copy()
    assess(reference,reference,global_variation,atol)
    if global_variation==0:
        empty=np.asarray(error_oracle(()),float)
        if np.any(reference>atol) or np.any(empty>atol):raise ValueError('Invalid constant-distribution oracle')
        return dict(version=VERSION,status='constant_distributions',selected=[],cost=0.,
                    nontrivial_reference=False,global_optimal=True,
                    certificate=assess(empty,reference,global_variation,atol))
    gamma=1-float(reference.mean())/global_variation
    if gamma==0:
        return dict(version=VERSION,status='degenerate_reference',selected=None,cost=None,
                    nontrivial_reference=False,global_optimal=None,reference_gamma=gamma)
    if not 0<gamma<=1+1e-12:raise ValueError('Invalid nonconstant reference score')
    verdicts={full:True}
    def feasible(P):
        if P not in verdicts:
            verdicts[P]=assess(error_oracle(P),reference,global_variation,atol)['objectwise_preserved']
        return verdicts[P]
    bound=len(costs)*(len(costs)+1)//2
    result=delete(costs,feasible,full,bound,'sweep')
    final=np.asarray(error_oracle(tuple(result['selected'])),float)
    certificate=assess(final,reference,global_variation,atol)
    assert certificate['objectwise_preserved'] and result['single_deletion_irreducible']
    return dict(**result,version=VERSION,status='ok',reference_gamma=gamma,
                nontrivial_reference=True,certificate=certificate,
                theoretical_request_bound=bound)
