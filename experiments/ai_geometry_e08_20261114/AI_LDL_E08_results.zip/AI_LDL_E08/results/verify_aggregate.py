"""Recompute public result arithmetic, not original-data prediction."""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parent
for n,h in json.loads((R/'MANIFEST.json').read_text()).items():
 if hashlib.sha256((R/n).read_bytes()).hexdigest()!=h:raise ValueError('Artifact changed '+n)
p=json.loads((R/'RESULTS_PUBLIC.json').read_text());s=json.loads((R/'SUMMARY.json').read_text());families=sorted({r['family'] for r in p['rows']});assert len(p['rows'])==7920 and len(families)==16
look={}
for f,key in {(r['family'],r['key']) for r in p['rows']}:
 rr=[r for r in p['rows'] if r['family']==f and r['key']==key];assert len(rr)==3;n=sum(r['n_validation'] for r in rr);look[f,key]={}
 for field in ['brier','array_fraction','selected_percent','native_array_bytes']:
  if field in rr[0]:look[f,key][field]=sum(r[field]*r['n_validation'] for r in rr)/n
for r in p['family_summary']:
 for field,value in look[r['family'],r['key']].items():assert abs(value-r[field])<=1e-12
for r in s['fixed_budget_contrasts']:
 suffix=f"__{r['budget_percent']}__a{r['alpha']}";prefix=f"{r['mask']}__{r['geometry']}__";ds=[look[f,prefix+r['left']+suffix]['brier']-look[f,prefix+r['right']+suffix]['brier'] for f in families]
 assert abs(np.mean(ds)-r['equal_family_brier_difference'])<=1e-12
 assert (sum(d<-1e-12 for d in ds),sum(abs(d)<=1e-12 for d in ds),sum(d>1e-12 for d in ds))==(r['left_better'],r['tied'],r['left_worse'])
for r in s['selected_policies']:
 prefix=f"{r['mask']}__{r['geometry']}__{r['method']}__";suffix=f"__a{r['alpha']}";ss=[look[f,prefix+'cap100'+suffix] for f in families];base=[look[f,prefix+'100'+suffix] for f in families]
 for key,value in [('equal_family_brier',np.mean([x['brier'] for x in ss])),('brier_difference_from_singleton',np.mean([x['brier']-y['brier'] for x,y in zip(ss,base)])),('mean_array_fraction',np.mean([x['array_fraction'] for x in ss])),('mean_selected_percent',np.mean([x['selected_percent'] for x in ss]))]:assert abs(value-r[key])<=1e-12
for r in s['native_LDLKM']:
 rr=[look[f,f"{r['mask']}__{r['method']}"] for f in families];base=[look[f,f"{r['mask']}__G__geometric__100__a{r['alpha']}"] for f in families];ds=[x['brier']-y['brier'] for x,y in zip(rr,base)]
 assert abs(np.mean([x['brier'] for x in rr])-r['equal_family_brier'])<=1e-12
 assert abs(np.mean([x['native_array_bytes'] for x in rr])-r['mean_native_array_bytes'])<=1e-12
 assert abs(np.mean(ds)-r['difference_from_G_singleton_same_prior'])<=1e-12
 assert (sum(d<-1e-12 for d in ds),sum(abs(d)<=1e-12 for d in ds),sum(d>1e-12 for d in ds))==(r['native_better'],r['tied'],r['native_worse'])
print('PASS: hashes,7920 metric rows,2640 family rows,160 fixed contrasts,32 selected policies,4 LDLKM entries; aggregate replay only')
