# E0 source-geometry / prototype-readout pilot

Read REPORT.md and records/DECISION.json first: technical checks passed, but current default performance does not justify freezing the full cross-family study. This is 27 training-internal fold cases / 540 metric rows on known benchmarks; no new outer-test scoring. The global-mean diagnostic was added after viewing the pilot and is explicitly exploratory.

## Definitions

U/G/L mean uniform, feature-global and instance-local weights. The numerical uniform control uses L1 geometry; E is a separate Euclidean5NN baseline. At fixed geometry/mask all readouts share the same source neighbors. Raw uses L_i, residual replaces covered labels by ball means and retains uncovered L_i, legacy uses global mean on uncovered objects. The last is the old O1 oracle readout; old strict-O1 evidence is not silently assigned to the new residual interface.

## Reproduce

Install requirements. Obtain and hash-check the authorized private three-family input cache first; it contains data/{dataset}_{X,L}.npy, plus original MATs and a cache manifest. Its expected array hashes are in records/E0_PROTOCOL.json. No original arrays or per-object outputs are in this public packet.

`python reproduce.py --data /path/to/extracted/cache/data --output /new/empty/run --run`

The adapter preserves recorded source, rebinds local data/core paths, runs interface checks, freezes a new pilot protocol, saves every prediction before scoring, then compares aggregate metrics with the reference at 1e-12. Timings can differ. This checks reproducibility, not independent data evidence. To resume an interrupted prepared run, keep the same paths and set AI_LDL_CORE to the absolute public-packet frozen_core directory when executing its run_pilot.py run, then score_pilot.py. Recompile/rewriting sources changes protocol identity and should use a new run.

## Resources and provenance

Synthetic probes have their own records and do not measure data performance. Shared model fitting and worker-wide RSS are not per-variant optimized costs. The original frozen core modules and split files are included; external IWNRS/GBFRS vendor code is not copied. Public records are aggregate metrics, source/protocol identities and checks. Full predictions, training readouts, row indices and source arrays are retained privately.
