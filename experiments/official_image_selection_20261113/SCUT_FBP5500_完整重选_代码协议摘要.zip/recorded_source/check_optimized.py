from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,time,json,numpy as np
from optimized import distances,granulate,original_safe,top_pairs
sys.path.insert(0,'/workspace/work/asc_review/code_bundle')
from granulation_reference import TrainingGeometry
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/asc_experiments')
s=np.load(BASE/'data/official_labels_split.npz');ix=s['train'];X=np.asarray(np.load(BASE/'data/official_resnet18_features.npy')[ix],float);L=s['labels'][ix];f=np.load(ROOT/'fitted.npz')
rows=[]
for n,m in [(32,16),(64,32)]:
 model=TrainingGeometry(X[:n,:m],L[:n],kinds=['numerical']*m);z=np.zeros((n,m))
 for a in range(m):
  v=X[:n,a];z[:,a]=(v-v.min())/(v.max()-v.min()) if v.max()>v.min() else 0
 for P in [list(range(m)),list(range(1,m)),list(range(0,m,2)),[]]:
  D=distances(z,np.array(model.weights).T,P);old,keys=model.subset(P);assert np.array_equal(D,old),(n,m,P,np.max(np.abs(D-old)))
  a=granulate(D,L[:n],keys);b=original_safe(old,L[:n],keys)
  assert a[0]==b[0] and a[1]==b[1] and a[2]==b[2] and a[4]==b[4]
  rows.append({'n':n,'m':m,'cardinality':len(P),'distances_exact':True,'leaves_errors_audit_exact':True})
# Tie-heavy pair arrays exercise boundary ties and lexicographic ordering.
rng=np.random.default_rng(20261113)
for n in [4,32,128]:
 rr=np.sort(rng.choice(500,n,replace=False));ia,ja=np.triu_indices(n,1)
 for vv in [np.ones(len(ia)),rng.integers(0,8,len(ia)).astype(float)]:
  for budget in [1,3,256]:
   expected=sorted(np.flatnonzero(vv>0),key=lambda k:(-float(vv[k]),int(rr[ia[k]]),int(rr[ja[k]])))[:budget]
   assert list(top_pairs(vv,rr,ia,ja,budget))==expected
print('SMALL EXACT CHECKS PASS',flush=True)
t=time.perf_counter();D=distances(f['Z'],f['W'],range(512));seconds=time.perf_counter()-t
assert np.array_equal(D,np.load(ROOT/'full_D.npy'))
print('FULL3300 DISTANCE EXACT',seconds,flush=True)
t=time.perf_counter();a=granulate(D,L,[tuple(row) for row in X]);gran_seconds=time.perf_counter()-t
rec=np.tile(L.mean(0),(len(L),1))
for B in a[1]:rec[B]=L[B].mean(0)
e=np.sum((L-rec)**2,axis=1);assert np.array_equal(e,np.load(ROOT/'reference.npy'))
result={'small_checks':rows,'tie_order_tests':18,'full3300_distance_exact':True,'full3300_error_vector_exact':True,'distance_seconds':seconds,'granulation_seconds':gran_seconds}
(ROOT/'optimization_validation.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
