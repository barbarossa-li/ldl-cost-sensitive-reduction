from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures
import numpy as np
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parent;data=ROOT/'data'
manifest=json.loads(Path('/workspace/work/asc_review/light/LDL_25_results/dataset_manifest.json').read_text())
names=['Yeast_cold','SCUT_FBP','Human_Gene']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fetch(d):
 name=d['name'];dest=data/(name+'.mat')
 if not dest.exists():
  with urllib.request.urlopen(d['url'],timeout=120) as response:dest.write_bytes(response.read())
 assert digest(dest)==d['mat_sha256'],name
 arrays=loadmat(dest);X=np.asarray(arrays['features'],float);L=np.asarray(arrays['labels'],float)
 assert np.isfinite(X).all() and np.isfinite(L).all() and (L>=0).all() and (L.sum(1)>0).all()
 L=L/L.sum(1,keepdims=True)
 for suffix,a in [('X',X),('L',L)]:
  path=data/f'{name}_{suffix}.npy';np.save(path,a);assert digest(path)==d[suffix+'_sha256'],(name,suffix)
 return {'dataset':name,'shape_X':list(X.shape),'shape_L':list(L.shape),'original_mat_hash_matches':True,'frozen_array_hashes_match':True,'source':d['url']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,[d for d in manifest['datasets'] if d['name'] in names]))
(ROOT/'input_verification.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
