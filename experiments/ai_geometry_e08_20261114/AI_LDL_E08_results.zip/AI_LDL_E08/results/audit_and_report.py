from pathlib import Path
import argparse,json,csv,hashlib,sys
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--data',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--e07',type=Path,required=True);a=ap.parse_args();r=a.run;out=a.output;out.mkdir(parents=True,exist_ok=True)
p=json.loads((r/'RESULTS_PUBLIC.json').read_text());rows=p['family_summary'];families=sorted({x['family'] for x in rows});assert len(families)==16;look={(x['family'],x['key']):x for x in rows};comparisons=[]
pairs=[('kmeanspp','geometric'),('bisecting','geometric'),('lloyd','geometric'),('kmeanspp','lloyd'),('bisecting','lloyd')]
for mask in ['Full','cost40']:
 for g in ['U','G']:
  for alpha in [0.,.5]:
   for pct in [25,50,75,100]:
    for left,right in pairs:
     diff=[look[f,f'{mask}__{g}__{left}__{pct}__a{alpha}']['brier']-look[f,f'{mask}__{g}__{right}__{pct}__a{alpha}']['brier'] for f in families]
     comparisons.append({'mask':mask,'geometry':g,'alpha':alpha,'budget_percent':pct,'left':left,'right':right,'equal_family_brier_difference':float(np.mean(diff)),'left_better':sum(x < -1e-12 for x in diff),'tied':sum(abs(x)<=1e-12 for x in diff),'left_worse':sum(x>1e-12 for x in diff)})
policies=[]
for mask in ['Full','cost40']:
 for g in ['U','G']:
  for alpha in [0.,.5]:
   for method in ['geometric','lloyd','kmeanspp','bisecting']:
    ss=[look[f,f'{mask}__{g}__{method}__cap100__a{alpha}'] for f in families];base=[look[f,f'{mask}__{g}__{method}__100__a{alpha}'] for f in families];delta=[x['brier']-y['brier'] for x,y in zip(ss,base)]
    policies.append({'mask':mask,'geometry':g,'alpha':alpha,'method':method,'equal_family_brier':float(np.mean([x['brier'] for x in ss])),'brier_difference_from_singleton':float(np.mean(delta)),'mean_array_fraction':float(np.mean([x['array_fraction'] for x in ss])),'mean_selected_percent':float(np.mean([x['selected_percent'] for x in ss]))})
native=[]
for mask in ['Full','cost40']:
 for suffix,alpha in [('native_LDLKM',0.),('native_LDLKM_half',.5)]:
  rr=[look[f,f'{mask}__{suffix}'] for f in families];base=[look[f,f'{mask}__G__geometric__100__a{alpha}'] for f in families];ds=[x['brier']-y['brier'] for x,y in zip(rr,base)]
  native.append({'mask':mask,'method':suffix,'alpha':alpha,'equal_family_brier':float(np.mean([x['brier'] for x in rr])),'mean_native_array_bytes':float(np.mean([x['native_array_bytes'] for x in rr])),'difference_from_G_singleton_same_prior':float(np.mean(ds)),'native_better':sum(d<-1e-12 for d in ds),'tied':sum(abs(d)<=1e-12 for d in ds),'native_worse':sum(d>1e-12 for d in ds)})
# Compare common old-setting rows against E07 to avoid counting replay as independent evidence.
old=json.loads(a.e07.read_text());o={(x['family'],x['fold'],x['key']):x['brier'] for x in old['rows']};replay=[]
for x in p['rows']:
 parts=x['key'].split('__')
 if len(parts)==5 and parts[-1]=='a0.5' and parts[2] in ['geometric','lloyd']:
  k='__'.join(parts[:4]);replay.append(abs(x['brier']-o[x['family'],x['fold'],k]))
assert len(replay)==1920 and max(replay)<=1e-12
# Independent per-object inner-product metric calculation and declared policy-link audits.
diffs=[];selection_checks=0;records=list(r.rglob('record_PRIVATE.json'))
for file in records:
 rec=json.loads(file.read_text());y=np.load(a.data/f"{rec['family']}_L.npy",mmap_mode='r')[rec['validation_indices']];pub={x['key']:x['brier'] for x in p['rows'] if x['family']==rec['family'] and x['fold']==rec['fold']}
 with np.load(file.parent/'predictions_PRIVATE.npz') as z:
  for key in z.files:
   value=sum(float(np.dot(v-t,v-t)) for v,t in zip(z[key],y))/len(y);diffs.append(abs(value-pub[key]))
  for key,pct in rec['selected_percent'].items():
   risks={b:rec['inner_risks'][key.replace('cap100',str(b))] for b in [25,50,75,100]};best=min(risks.values());chosen=min(b for b in risks if risks[b]<=best+1e-12);assert chosen==pct and np.array_equal(z[key],z[key.replace('cap100',str(chosen))]);selection_checks+=1
assert len(diffs)==7920 and max(diffs)<1e-12
fixed=[x for x in p['rows'] if len(x['key'].split('__'))==5 and not x['key'].split('__')[3].startswith('cap') and x['key'].endswith('a0.0')]
repairs={'scope':'Outer-refit fixed-budget constructions, counted once across priors; inner-call warning counts were not retained','fixed_outer_constructions':len(fixed),'constructions_with_repair':sum(x['repair_count']>0 for x in fixed),'total_repaired_groups':sum(x['repair_count'] for x in fixed),'outer_warning_records':sum(x['warning_count'] for x in fixed)}
summary={'scope':p['scope'],'families':16,'cases':48,'metric_rows':len(p['rows']),'family_rows':len(rows),'independent_metric_max_difference':max(diffs),'policy_choice_and_prediction_checks':selection_checks,'E07_replayed_rows':len(replay),'E07_replay_max_difference':max(replay),'original_external_test_scored':False,'fixed_budget_contrasts':comparisons,'selected_policies':policies,'native_LDLKM':native,'repairs':repairs,'total_run_seconds':json.loads((r/'ALL_PREDICTIONS_FROZEN.json').read_text())['wall_seconds']}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'RESULTS_PUBLIC.json').write_text(json.dumps(p,indent=2)+'\n')
for name,data in [('family_results.csv',rows),('contrasts.csv',comparisons),('selected_policies.csv',policies),('native_LDLKM.csv',native)]:
 fields=list(dict.fromkeys(k for row in data for k in row))
 with (out/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
lines=['# E0.8 强基线开发验证','','16个已咨询族、48个训练池外层折、各3个内层折。没有新增原始外部测试评分，没有修改论文。协议与代码先私人持久冻结，再运行；未称公开预注册。','',f'7920行误差独立逐对象内积复算，最大差{max(diffs):.3g}；{selection_checks}项预算选择/对应预测核对通过。与E07重叠的{len(replay)}行是复跑，最大差{max(replay):.3g}，不算独立证据。','','## 固定预算：G几何、半强度均值收缩','','差值为左方法减纯几何二分；负数表示外部基线更好。所有U/G、两档先验及旧Lloyd对照的完整结果在contrasts.csv。','','| 掩码 | 预算% | 左方法 | Brier差 | 左胜/平/负 |','|---|---:|---|---:|---|']
for x in comparisons:
 if x['geometry']=='G' and x['alpha']==.5 and x['right']=='geometric' and x['left']!='lloyd':lines.append(f"| {x['mask']} | {x['budget_percent']} | {x['left']} | {x['equal_family_brier_difference']:+.7f} | {x['left_better']}/{x['tied']}/{x['left_worse']} |")
lines+=['','## 内层选预算：G几何、半强度均值收缩','','每个方法单独选预算，实际容量不同；这部分不作同容量优越性表述。','','| 掩码 | 方法 | 等族Brier均值 | 数组占比均值 | 选中比例均值% |','|---|---|---:|---:|---:|']
for x in policies:
 if x['geometry']=='G' and x['alpha']==.5:lines.append(f"| {x['mask']} | {x['method']} | {x['equal_family_brier']:.7f} | {x['mean_array_fraction']:.3f} | {x['mean_selected_percent']:.2f} |")
lines+=['','## LDLKM论文设置重建（不是作者代码）','','固定K5、最大20轮、Minkowski p5、全中心倒距离softmax。训练min-max、初始化及零距离规则是已披露实施约定；半收缩版本另标。固定K5与比例预算比较不称同容量。','','| 掩码 | 读出 | 等族Brier | 数值数组均值bytes | 对G单点同先验差 |','|---|---|---:|---:|---:|']
for x in native:lines.append(f"| {x['mask']} | {x['method']} | {x['equal_family_brier']:.7f} | {x['mean_native_array_bytes']:.1f} | {x['difference_from_G_singleton_same_prior']:+.7f} |")
lines+=['','## 范围与完整性','',f"外层固定预算构造（两档先验只计一次）{len(fixed)}项，其中{repairs['constructions_with_repair']}项进行了非空组修复，共补{repairs['total_repaired_groups']}组；警告记录{repairs['outer_warning_records']}项。内层库警告次数未逐项保留，不把外层计数称为全运行计数。",'', '同K机制比较统一了预测器与G/U几何；原生LDLKM另列，未强制改造成5原型均值读出。K=n统一单点端点、重复特征修复是已披露适配，不冒充库原生算法在所有退化输入上的输出。','', '部署数值数组不含Python对象、训练内存或序列化。本轮未完整比较方法级构造/查询硬件资源，不能用总运行时作某方法加速优势。','', '每族先按验证对象数合并3折，再等权平均16族。已有数据多次用于开发，新内层预算选择也不是未咨询数据确认；没有显著性或原创性已确立的主张。ProLSFEO-LDL和RkNN-LDL尚未纳入。所有设置与阴性结果保留。']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['fixed_budget_contrasts','selected_policies','native_LDLKM']},indent=2))
