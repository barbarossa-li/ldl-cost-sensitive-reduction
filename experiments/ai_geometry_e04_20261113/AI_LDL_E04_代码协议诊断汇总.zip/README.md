# E0.4 training-internal mechanism diagnosis

Post-v1 development on 16 already-consulted feature families, using only the first up-to192 objects of repeat1 training pools, in 3 internal folds. No new outer-test scoring. All 48 prediction cases were frozen before internal scoring; 2,064 Brier values were independently audited. See REPORT.md and records/SUMMARY.json.

Row-normalized local weights reduce source-amplitude attraction and often improve over old local geometry, but do not show stable advantages over uniform/global weights or normalized-row permutation nulls. They are a diagnostic candidate, not a validated replacement. The current ball residual readout is weak smoothing; a new query-to-prototype representation remains a future design, not a claimed result. The original 78-page manuscript and v1 results are unchanged.

Portable reproduction with the authorized verified32-array cache (no downloads):
`python reproduce.py --data /cache --output /new/empty/directory`
This regenerates private main split metadata from frozen public seeds, checks input hashes, reruns the 48 development folds, and compares aggregate summaries. Replays are artifact checks, not additional independent evidence. Python3.12/numpy2.3.5/scipy1.17.0; python-docx only needed for optional report generation. Private raw arrays, actual split metadata and per-query predictions are excluded.
