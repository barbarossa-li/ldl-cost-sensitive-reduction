from pathlib import Path
import ctypes,numpy as np,sys
ROOT=Path(__file__).resolve().parent
CODE=Path('/workspace/work/asc_review/code_bundle')
sys.path.insert(0,str(CODE))
from information_reduction.safe_extension import granulate as original_safe
from information_reduction import alternative_seeds,safe_extension
from stability.fast_granulate import granulate as original_base
lib=ctypes.CDLL(str(ROOT/'distance.so'))
arr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS');ints=np.ctypeslib.ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')
lib.distances.argtypes=[arr,arr,ints,ctypes.c_int,ctypes.c_int,ctypes.c_int,arr,ctypes.c_int]

def distances(Z,W,P,threads=3):
 n,m=Z.shape;z=np.ascontiguousarray(Z.T);w=np.ascontiguousarray(W.T);subset=np.array(sorted(P),dtype=np.int32);D=np.empty((n,n))
 lib.distances(z,w,subset,n,m,len(subset),D,threads)
 return D

def top_pairs(vv,rr,ia,ja,budget):
 # Identify exact largest-distance cutoff in linear time. Retain all ties at
 # cutoff, then apply the original (-distance, original-i, original-j) order.
 good=np.flatnonzero(vv>0)
 if len(good)>budget:
  val=vv[good];cut=np.partition(val,len(val)-budget)[len(val)-budget];good=good[val>=cut]
 order=np.lexsort((rr[ja[good]],rr[ia[good]],-vv[good]))
 return good[order][:budget]

text=(CODE/'information_reduction/alternative_seeds.py').read_text()
needle="order=sorted(np.flatnonzero(vv>0),key=lambda k:(-float(vv[k]),int(rr[ia[k]]),int(rr[ja[k]])))"
assert needle in text
# Keep the original budget_stopped audit meaning even though only top-budget
# pairs are sorted. Partition, gates and accepted leaves are unchanged.
text=text.replace(needle,'positive_count=int(np.count_nonzero(vv>0));order=top_pairs(vv,rr,ia,ja,pair_budget)')
text=text.replace('int(len(order)>pair_budget)','int(positive_count>pair_budget)')
ns={'np':np,'top_pairs':top_pairs};exec(compile(text,str(CODE/'information_reduction/alternative_seeds.py')+'[top-pair optimization]','exec'),ns)
fast_alternative=ns['granulate']
def granulate(D,L,keys,**kw):
 # Safe extension calls the same original anchor and optimized exact top pairs.
 old=safe_extension.alternative;safe_extension.alternative=fast_alternative
 try:return original_safe(D,L,keys,**kw)
 finally:safe_extension.alternative=old
