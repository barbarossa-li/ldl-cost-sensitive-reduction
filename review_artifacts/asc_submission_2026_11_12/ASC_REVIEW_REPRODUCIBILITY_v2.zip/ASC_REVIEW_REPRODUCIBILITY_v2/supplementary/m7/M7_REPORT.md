# M7 特征族配对比较

数据来源为主实验的冻结结果 supplementary/all_results.csv，预测器使用正文主表的训练折 min–max。以特征族为区组，先在任务内平均三个重复，再在族内对各方法共同完整的条件等权平均。Yeast 九个共同完整条件计一个区组。两方法比较排除 Yeast-alpha、Painting；五方法比较另排除 Movie。省略不完整条件，没有插补。剔除 Yeast 整族的敏感性结果见 summary.json。

主比较为 GBFRS-EQ 配额子集与 GBIP-O1 的标准化成本和 Brier 两项。差值统一为 GBFRS-EQ 减 GBIP-O1；成本为相对全集的百分比，差值单位为百分点。用双侧 Wilcoxon 符号秩，差值按 12 位小数取秩、绝对值不超过 1e-12 视为零，并用枚举符号获得 p 值。Holm 在两项主比较内校正。Friedman 在完整区组内对五种方法的 Brier 排秩，以固定随机种子做 49,999 次区组内置换，采用加一校正。整体检验未触发事后检验。

复核命令为 `python supplementary/m7/run_m7.py supplementary/all_results.csv supplementary/m7`。family 均值与差异统计均可在此目录复算。这是对现有基准的探索性推断，无法从共享特征矩阵之外验证不同特征族的独立性。
