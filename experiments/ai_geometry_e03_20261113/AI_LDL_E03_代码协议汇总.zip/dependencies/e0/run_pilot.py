"""E0 training-internal pilot; no old/new outer-test labels are dereferenced."""
from pathlib import Path
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import sys,json,time,hashlib,subprocess,resource,datetime,platform
import numpy as np
from model import NumericalPrototypeModel,CORE
sys.path.insert(0,str(CORE))
from baseline_revision.prediction_evaluation import predict_five_neighbors
R=Path(__file__).resolve().parent;DATA=Path('/workspace/work/asc_experiments/data');SPLITS=CORE/'expansion25/splits';DATASETS=['Yeast_cold','SCUT_FBP','Human_Gene']
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def save(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def prepare():
 check=json.loads((R/'INTERFACE_CHECKS.json').read_text());assert check['passed']
 sources=[R/name for name in ['model.py','check_interface.py','run_pilot.py','score_pilot.py','benchmark_resources.py']]+[CORE/name for name in ['granulation_reference.py','information_reduction/safe_extension.py','information_reduction/alternative_seeds.py','stability/fast_granulate.py','baseline_revision/prediction_evaluation.py','prediction_interface/directed_predictor.py']]
 inputs=[DATA/f'{d}_{a}.npy' for d in DATASETS for a in ['X','L']]+[SPLITS/d/f'repeat_{r}.json' for d in DATASETS for r in [1,2,3]]+[R/'INTERFACE_CHECKS.json']
 protocol={'version':'AI-E0-interface-pilot-v1','scope':'Development pilot only, known benchmark training-internal folds. No new outer-test performance or full-method claims.','families':DATASETS,'repeats':[1,2,3],'validation_folds':[0,1,2],'fit_n':128,'validation_n':64,'masks':['Full','40% cost prefix from one predetermined random ranking'],'mask_seed':'202611130000+1000*dataset_index+100*repeat+fold; dataset_index0..2','costs':'Reuse prior frozen positive coordinate prices, independently of validation labels','weight_modes':['U','G','L'],'readouts':['raw','ball_residual','ball_global_legacy'],'baseline':'Frozen training-minmax Euclidean5NN','planned_fold_cases':27,'planned_metric_rows':540,'schedule':'Complete and hash all 27 prediction bundles before validation-label scoring; no outcome-based code or parameter change.','resources':'Fresh sequential worker per fold. Shared geometry fit is charged once, per-mode/selected-mask representation/query times saved. Worker peak RSS includes all cached readouts and overhead, not per-variant optimized memory. Synthetic scaling probe separate.','defaults':{'beta':1,'zeta':.1,'smin':2,'kappa':.1,'alpha':1,'K':256,'epsilon_safe':1e-12,'k_neighbors':5},'source_hashes':{str(p):sha(p) for p in sources},'input_hashes':{str(p):sha(p) for p in inputs},'frozen_at':stamp(),'python':platform.python_version(),'numpy':np.__version__}
 target=R/'E0_PROTOCOL.json'
 if target.exists():
  old=json.loads(target.read_text());protocol['frozen_at']=old['frozen_at'];assert protocol==old
 else:save(target,protocol)
 print('E0 PROTOCOL FROZEN',sha(target),flush=True)
def verify():
 p=json.loads((R/'E0_PROTOCOL.json').read_text())
 for path,h in p['source_hashes'].items():assert sha(path)==h,('source changed',path)
 for path,h in p['input_hashes'].items():assert sha(path)==h,('input changed',path)
 return p
def worker(d,repeat,fold):
 verify();dest=R/'cases'/d/f'repeat_{repeat}'/f'fold_{fold}';dest.mkdir(parents=True,exist_ok=True)
 if (dest/'record.json').exists():assert json.loads((dest/'record.json').read_text())['protocol_sha256']==sha(R/'E0_PROTOCOL.json');return
 split=json.loads((SPLITS/d/f'repeat_{repeat}.json').read_text());parent=np.array(split['train_indices'],int);valpos=np.array(split['fold_validation_positions'][fold],int);fitpos=np.setdiff1d(np.arange(len(parent)),valpos);fitids=parent[fitpos];valids=parent[valpos]
 assert len(fitids)==128 and len(valids)==64 and set(fitids).isdisjoint(valids);assert set(fitids).union(valids)<=set(parent);assert set(parent).isdisjoint(split['test_indices'])
 Xfile=np.load(DATA/f'{d}_X.npy',mmap_mode='r');Lfile=np.load(DATA/f'{d}_L.npy',mmap_mode='r');X=np.asarray(Xfile[fitids],float);L=np.asarray(Lfile[fitids],float);Q=np.asarray(Xfile[valids],float)
 t=time.perf_counter();c=time.process_time();model=NumericalPrototypeModel(X,L);fitwall=time.perf_counter()-t;fitcpu=time.process_time()-c
 costs=np.asarray(split['costs'],float);seed=202611130000+1000*DATASETS.index(d)+100*repeat+fold;order=np.random.default_rng(seed).permutation(model.m);cum=np.cumsum(costs[order]);prefix=tuple(sorted(map(int,order[cum<=.4*costs.sum()])))
 masks={'Full':tuple(range(model.m)),'cost40':prefix};predictions={};training={};rows=[]
 for mask,P in masks.items():
  for mode in ['U','G','L']:
   t=time.perf_counter();c=time.process_time();part=model.representation(P,mode);constructwall=time.perf_counter()-t;constructcpu=time.process_time()-c
   t=time.perf_counter();c=time.process_time();out=model.evaluate_selected(Q[:,P],P,mode);querywall=time.perf_counter()-t;querycpu=time.process_time()-c
   predictions[f'neighbors__{mask}__{mode}']=out['neighbors']
   predictions[f'covered__{mask}__{mode}']=part['covered']
   for name,pred in out['predictions'].items():
    assert np.isfinite(pred).all() and np.all(pred>=0) and np.allclose(pred.sum(1),1,rtol=0,atol=1e-12)
    key=f'{mask}__{mode}__{name}';predictions['pred__'+key]=pred;training['r__'+key]=part[name]
    rows.append({'dataset':d,'repeat':repeat,'fold':fold,'mask':mask,'weight':mode,'readout':name,'attributes':len(P),'actual_cost_percent':100*float(costs[list(P)].sum())/costs.sum(),'fit_shared_wall_seconds':fitwall,'fit_shared_cpu_seconds':fitcpu,'representation_shared_wall_seconds':constructwall,'representation_shared_cpu_seconds':constructcpu,'query_shared_wall_seconds':querywall,'query_shared_cpu_seconds':querycpu,**part['statistics']})
  predictions[f'pred__{mask}__E__raw']=predict_five_neighbors(X,L,Q,P)
  rows.append({'dataset':d,'repeat':repeat,'fold':fold,'mask':mask,'weight':'E','readout':'raw','attributes':len(P),'actual_cost_percent':100*float(costs[list(P)].sum())/costs.sum()})
 # No validation-label values have been dereferenced by this worker.
 np.savez_compressed(dest/'predictions.npz',**predictions);np.savez_compressed(dest/'training_readouts.npz',**training)
 record={'protocol_sha256':sha(R/'E0_PROTOCOL.json'),'dataset':d,'repeat':repeat,'fold':fold,'fit_indices':fitids.tolist(),'validation_indices':valids.tolist(),'fit_n':len(fitids),'validation_n':len(valids),'parent_training_only':True,'old_outer_test_indices_not_used':True,'fit_arrays_sha256':hashlib.sha256(X.tobytes()+L.tobytes()).hexdigest(),'masks':{k:list(v) for k,v in masks.items()},'mask_seed':seed,'weights_sha256':hashlib.sha256(model.W.tobytes()).hexdigest(),'mean_local_weight':float(model.W.mean()),'maximum_local_weight':float(model.W.max()),'prediction_file_sha256':sha(dest/'predictions.npz'),'training_readouts_sha256':sha(dest/'training_readouts.npz'),'worker_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'rows':rows,'finished_at':stamp()}
 save(dest/'record.json',record);print('PREDICTIONS',d,repeat,fold,'fit_s',round(fitwall,4),'peak_MB',round(record['worker_peak_rss_bytes']/1e6,2),flush=True)
def run():
 verify()
 for d in DATASETS:
  for repeat in [1,2,3]:
   for fold in [0,1,2]:subprocess.run([sys.executable,str(Path(__file__).resolve()),'worker',d,str(repeat),str(fold)],check=True)
 files=[R/'cases'/d/f'repeat_{repeat}'/f'fold_{fold}'/'record.json' for d in DATASETS for repeat in [1,2,3] for fold in [0,1,2]]
 save(R/'ALL_E0_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(R/'E0_PROTOCOL.json'),'records':{str(p.relative_to(R)):sha(p) for p in files},'frozen_at':stamp()});print('ALL27 E0 PREDICTIONS FROZEN',flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='run':run()
 elif sys.argv[1]=='worker':worker(sys.argv[2],int(sys.argv[3]),int(sys.argv[4]))
