"""Pinned input loading. No downloads and no evaluation here."""
from pathlib import Path
import json,csv,collections,hashlib
import numpy as np
from design import canon,connected_groups,rater_cohorts
TASKS=['ChaosSNLI','ChaosMNLI','DICES990']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(base,task,cohort='all'):
 base=Path(base);raw=base/'private/raw';protocol=json.loads((base/'source/PROTOCOL.json').read_text());manifest={x['name']:x for x in protocol['sources']}
 for name in ['chaosNLI_snli.jsonl','chaosNLI_mnli_m.jsonl','DICES990.csv']:assert sha(raw/name)==manifest[name]['sha256']
 if task!='DICES990':
  assert cohort=='all';rows=[json.loads(x) for x in (raw/('chaosNLI_snli.jsonl' if task=='ChaosSNLI' else 'chaosNLI_mnli_m.jsonl')).open()];ids=[];texts=[];labels=[];keys=[]
  for r in rows:
   ids.append(r['uid']);e=r['example'];texts.append('premise: '+e['premise']+'\nhypothesis: '+e['hypothesis']);labels.append(np.array(r['label_count'],float)/100.);kk=['premise:'+canon(e['premise'])]
   if task=='ChaosSNLI':kk.append('image:'+r['uid'].split('.jpg#')[0]+'.jpg')
   keys.append(kk)
  return ids,texts,np.asarray(labels),keys,{'cohort':'all','annotations_per_item':100}
 excluded=set(json.loads((base/'private/DICES_METADATA_EXCLUSIONS_PRIVATE.json').read_text())['excluded_item_ids']);items={};raters=collections.defaultdict(list)
 with (raw/'DICES990.csv').open(newline='') as file:
  for r in csv.DictReader(file):
   if r['item_id'] in excluded:continue
   items[r['item_id']]=(r['context'],r['response']);raters[r['item_id']].append((r['rater_id'],r['Q_overall']))
 train,test=rater_cohorts([rr for rows in raters.values() for rr,_ in rows]);assert not train&test and len(train)==120 and len(test)==52
 permitted=train if cohort=='train' else test if cohort=='query' else train|test;ids=sorted(items);texts=[];labels=[];keys=[];counts=[]
 for item in ids:
  c,r=items[item];texts.append('context: '+c+'\nresponse: '+r);kk=['item:'+item,'pair:'+canon(c)+'\0'+canon(r)]
  if canon(c):kk.append('context:'+canon(c))
  keys.append(kk);count=collections.Counter(v for rid,v in raters[item] if rid in permitted);n=sum(count.values());assert n>=10;labels.append([count[k]/n for k in ['No','Unsure','Yes']]);counts.append(n)
 return ids,texts,np.asarray(labels),keys,{'cohort':cohort,'rater_ids':sorted(permitted),'annotation_counts':counts}
def case(base,task,fold,stage):
 base=Path(base);pp=json.loads((base/'private/PLANNED_PARTITIONS_PRIVATE.json').read_text());protocol=json.loads((base/'source/PROTOCOL.json').read_text());assert sha(base/'private/PLANNED_PARTITIONS_PRIVATE.json')==protocol['partitions']['allocation_commitment_sha256'];entry=pp[task][fold];assert entry['outer_fold']==fold
 ids,text,Y,keys,info=load(base,task,'train' if stage=='rater_disjoint' else 'all');mapping={x:i for i,x in enumerate(ids)};fit=np.array([mapping[x] for x in entry['fit_ids']]);query=np.array([mapping[x] for x in entry['query_ids']]);parts=[np.array(h,int) for h in entry['inner_query_fit_positions']];assert not set(fit)&set(query)
 groups=connected_groups(keys);gid={int(x):i for i,g in enumerate(groups) for x in g};assert not {gid[int(x)] for x in fit}&{gid[int(x)] for x in query}
 for i in range(3):
  for j in range(i):assert not {gid[int(fit[x])] for x in parts[i]}&{gid[int(fit[x])] for x in parts[j]}
 # Query labels intentionally not returned by the fitting loader.
 return [text[i] for i in fit],Y[fit],[text[i] for i in query],parts,{'task':task,'fold':fold,'stage':stage,'fit_ids':entry['fit_ids'],'query_ids':entry['query_ids'],'fit_group_ids':[gid[int(x)] for x in fit],'query_group_ids':[gid[int(x)] for x in query],'cohort':info}
