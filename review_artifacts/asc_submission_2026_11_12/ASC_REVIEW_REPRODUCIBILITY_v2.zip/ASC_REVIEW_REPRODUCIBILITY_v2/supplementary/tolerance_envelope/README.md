# SCUT-FBP5500 固定候选池的容差—存储分析

候选池含原始 1531 个查询子集（含 Full、Empty）以及冻结独立搜索的 512 个新子集。
按最大训练对象误差增量排序，在每个阈值选择已查子集中存储最少者，平局选属性索引
列表字典序较小者。后续预测与决策结果不参与端点选择。数值比较余量为 1e-12。

## 所需原始输入

- 原 FBP5500_Application_Run（代码、冻结特征、标签与划分）
- 原 FBP5500_RESULTS_RETURN.zip
- 原始 results/oracle.sqlite（1531 个查询，SHA-256 以脚本检查为准）
- JOINT_SEARCH_RESULTS.json 与对应冻结的 JOINT_SEARCH_PROTOCOL.json

在具备 Python 3.12、numpy 2.3.5、scipy 1.17.0 的环境运行：

```bash
python assess_frontier.py --original-run /path/FBP5500_Application_Run --original-return /path/FBP5500_RESULTS_RETURN.zip --original-cache /path/oracle.sqlite --joint-results /path/JOINT_SEARCH_RESULTS.json --joint-protocol /path/JOINT_SEARCH_PROTOCOL.json --output /path/work
python finish_analysis.py /path/work/results
```

绘图另需 matplotlib。重构只对曲线的六个端点进行。原查询的误差向量由原始缓存
校验，新增端点的误差向量核对独立搜索返回的 SHA-256。输出 NPZ 可供本地复用。
归档报告提供汇总统计和特征子集定义，原始图像与个体重构向量保留在运行环境中。

## 指标口径

- 主导标签集合变化比较候选与全特征参考的最大值集合，最大值容差 1e-12。
- 主导标签正确保持仅考察目标与参考均有唯一最大值、且参考正确的训练对象。
  候选最大值错误或形成并列均算“丢失正确唯一最大值”。
- Top-2 正确保持仅考察目标和参考在第二、第三名边界均无并列、且参考前两名集合
  正确的对象。候选前两名集合错误或边界并列均算丢失。
- 成对排序损失排除目标相等的标签对，对预测并列计半损失。只在存在至少一对
  可比较目标标签的对象上统计损失上升。
- 间隔证书计数用固定参考误差加本端点容差，与目标第一、第二名差的平方一半
  作严格比较。它是事先可核验的充分条件，满足条件的对象必须保持正确唯一最大值。
- 测试 Brier 使用原训练特征缩放与五近邻。测试结果仅用于描述。

容差表示平方分布误差的增量。曲线是已查询候选池的包络，未重新对每个容差搜索，
也没有给出应用方验收阈值或全局最优性结论。
