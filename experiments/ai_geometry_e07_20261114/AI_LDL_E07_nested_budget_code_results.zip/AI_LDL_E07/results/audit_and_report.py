from pathlib import Path
import json,csv,collections,hashlib,platform
import numpy as np
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--data',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
r=args.run;out=args.output;out.mkdir(parents=True,exist_ok=True)
p=json.loads((r/'RESULTS_PUBLIC.json').read_text());rows=p['family_summary'];families=sorted({x['family'] for x in rows});lookup={(x['family'],x['key']):x for x in rows};n=len(families)
assert n==16
contrasts=[]
for mask in ['Full','cost40']:
 for pct in [25,50,75,100]:
  for label,a,b in [('Information weighting','G__geometric','U__geometric'),('Hierarchy versus Lloyd','G__geometric','G__lloyd'),('Label priority secondary','G__supervised','G__geometric')]:
   ds=[lookup[f,f'{mask}__{a}__{pct}']['brier']-lookup[f,f'{mask}__{b}__{pct}']['brier'] for f in families]
   contrasts.append({'mask':mask,'budget_percent':pct,'contrast':label,'equal_family_brier_difference':float(np.mean(ds)),'better':sum(d < -1e-12 for d in ds),'tie':sum(abs(d)<=1e-12 for d in ds),'worse':sum(d>1e-12 for d in ds)})
policies=[]
for mask in ['Full','cost40']:
 for g in ['U','G']:
  for method in ['geometric','supervised','lloyd']:
   s=[lookup[f,f'{mask}__{g}__{method}__cap100'] for f in families];base=[lookup[f,f'{mask}__{g}__{method}__100'] for f in families];ds=[a['brier']-b['brier'] for a,b in zip(s,base)]
   policies.append({'mask':mask,'geometry':g,'method':method,'equal_family_brier':float(np.mean([a['brier'] for a in s])),'brier_difference_from_fixed100':float(np.mean(ds)),'mean_array_fraction':float(np.mean([a['array_fraction'] for a in s])),'mean_selected_percent':float(np.mean([a['selected_percent'] for a in s])),'better':sum(d < -1e-12 for d in ds),'tie':sum(abs(d)<=1e-12 for d in ds),'worse':sum(d>1e-12 for d in ds)})
# Independent metrics arithmetic from all frozen private prediction arrays.
errors=[];count=0
for recordpath in sorted(r.rglob('record_PRIVATE.json')):
 a=json.loads(recordpath.read_text());y=np.load(args.data/f"{a['family']}_L.npy",mmap_mode='r')[a['validation_indices']]
 original={x['key']:x['brier'] for x in p['rows'] if x['family']==a['family'] and x['fold']==a['fold']}
 with np.load(recordpath.parent/'predictions_PRIVATE.npz') as arr:
  for key in arr.files:
   pred=arr[key];direct=sum(float(np.dot(v-vy,v-vy)) for v,vy in zip(pred,y))/len(y);errors.append(abs(direct-original[key]));count+=1
assert count==4656 and max(errors)<1e-12
summary={'scope':p['scope'],'families':16,'nested_outer_cases':48,'aggregate_metric_rows':len(p['rows']),'family_rows':len(rows),'metric_audit_rows':count,'metric_audit_max_error':max(errors),'original_outer_test_scored':False,'fixed_budget_contrasts':contrasts,'selected_cap100_policies':policies,'runtime_seconds':json.loads((r/'ALL_PREDICTIONS_FROZEN.json').read_text())['wall_seconds']}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'RESULTS_PUBLIC.json').write_text(json.dumps(p,indent=2)+'\n')
for name,records in [('family_results.csv',rows),('fixed_budget_contrasts.csv',contrasts),('selected_policies.csv',policies)]:
 keys=list(dict.fromkeys(k for row in records for k in row))
 with (out/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(records)
lines=['# E0.7 嵌套预算选择：训练池内开发结果','','全部48份预测先冻结，再统一评分。16族均为已咨询数据，本轮不是独立确认；未新增原始外部测试集评分。','',f'完成48个外层case，每个3个内层折；{count}行指标以独立逐对象内积求和式复算，最大差 {max(errors):.3g}。','','## 固定预算的机制比较','','负数表示前者Brier更低；胜/平/负以1e-12作为并列阈值。先按每族验证对象数合并3折，再等权平均16族。','','| 掩码 | 预算% | 比较 | 等族平均差 | 胜/平/负 |','|---|---:|---|---:|---|']
for a in contrasts:lines.append(f"| {a['mask']} | {a['budget_percent']} | {a['contrast']} | {a['equal_family_brier_difference']:+.7f} | {a['better']}/{a['tie']}/{a['worse']} |")
lines+=['','## 内层选择预算，外层评价：上限100%','','各方法独立选择预算，容量可能不同；本表不是同容量优越性检验。','','| 掩码 | 几何 | 方法 | 对固定100%误差差 | 数组占比均值 | 选中比例均值% | 胜/平/负 |','|---|---|---|---:|---:|---:|---|']
for a in policies:lines.append(f"| {a['mask']} | {a['geometry']} | {a['method']} | {a['brier_difference_from_fixed100']:+.7f} | {a['mean_array_fraction']:.3f} | {a['mean_selected_percent']:.2f} | {a['better']}/{a['tie']}/{a['worse']} |")
lines+=['','## 解读边界','','预算选择只看内层验证风险，评分前全部外层预测与选中设置已经冻结。上表为对象数加权的折汇总，再按特征族等权；没有把折、预算或掩码当成独立数据集。','', '数组占比不包含训练内存、Python对象或序列化开销，cost40也不是完整训练采集成本。固定100%端点不自动是最优预测器；本轮没有对更多先验、读出方式或外部LDL算法作新比较。','', '本轮改变评价层级，沿用的族和训练池已被多次开发咨询，不能据本轮结果声称独立泛化、显著性或原创性已成立。无论方向如何，保留全部族、预算、方法和阴性结果，原论文保持不变。']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['fixed_budget_contrasts','selected_cap100_policies']},indent=2))
