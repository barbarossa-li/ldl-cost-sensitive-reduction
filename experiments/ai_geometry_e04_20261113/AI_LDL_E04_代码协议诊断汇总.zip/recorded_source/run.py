from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,time,resource,subprocess,concurrent.futures
import numpy as np
from scipy.stats import spearmanr
from candidate import ShapeWeightedModel
CORE=Path(os.environ.get('AI_LDL_CORE','/workspace/work/asc_review/code_bundle'));sys.path.insert(0,str(CORE))
R=Path(__file__).resolve().parent;M=Path(os.environ.get('AI_LDL_MAIN','/workspace/work/ai_mechanism_v1_20261113'));D=Path(os.environ.get('AI_LDL_DATA','/workspace/work/asc_experiments/data'));PRIVATE=Path(os.environ.get('AI_LDL_MAIN_PRIVATE','/workspace/work/ai_mechanism_v1_private_20261113'));sys.path.insert(0,os.environ.get('AI_LDL_E03','/workspace/work/ai_e03_20261113'))
from controls import targets

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def prepare():
 family=json.loads((M/'PROTOCOL.json').read_text())['families'];files=[R/'run.py',R/'candidate.py',R/'check.py',R/'CHECKS.json',M/'PROTOCOL.json']
 files += [p for p in (M/'dependencies').rglob('*') if p.is_file() and p.suffix in ['.py','.json'] and '__pycache__' not in p.parts]
 inputs=[D/f"{f['family']}_{a}.npy" for f in family for a in ['X','L']]+[PRIVATE/f['family']/'repeat_1/split_PRIVATE.json' for f in family]
 for f in family:
  for a in ['X','L']:assert sha(D/f"{f['family']}_{a}.npy")==f[a+'_sha256']
 p={'version':'AI-E0.4-source-amplitude-diagnostic-v1','scope':'Development after the v1 outer study; all16 known families, only repeat1 training pool used, capped first192 objects, 3 internal folds. These are consulted data, not independent confirmation. No v1 outer test labels/outcomes loaded.','families':family,'cases':48,'fit_validation':'Split the first min(192,ntrain) positions into3 seeded folds; fit on other2, validate on1. SJAFFE uses149 total, others192.','seed':'202611134000+10000*family_index0based; inner permutation split_seed+1000; normalized-weight nulls split_seed+100*fold+null_index0..4; same-covered group nulls split_seed+5000+100*fold+null_index','masks':['Full','same bank0 cost40 original-coordinate mask as v1 repeat1'],'settings':{'zeta':.5,'smoothing_alpha':.5,'k':5,'beta':1,'smin':2,'kappa':.1,'radius_alpha':1,'pair_budget':256},'geometry':['U uniform','L original local source weights','G feature-global weights, raw-only control','N W_ia / mean_a(W_ia) using trainingFull row mean; exactly zero row => allones, fixed across subsets and queries','T five full-row permutations of N, raw-only alignment null; report mean per-seed loss, not an ensemble'],'representations':'For U/L/N: raw, half ball-residual smoothing, half same-covered mean smoothing, half global-mean smoothing, half same-covered random-group smoothing(5seeds). All endpoints retained, no tuning.','diagnostics':['Full-W coefficient of variation of source row means','first singular value squared / Frobenius norm squared of W','Spearman correlation of raw source row mass with neighbor selection counts','selection-weighted mass / unweighted mass','neighbor-count Gini and effective source fraction','prediction shift energy and Brier exact decomposition relative to raw'],'claim_limits':'Candidate N is a new normalized geometry; old O1 results and all old stability/range conclusions cannot be silently reused. Fixed-training subset monotonicity checked; no theory for refitting after label perturbations is claimed. No new ball representation is proposed or selected in this diagnostic.','source_hashes':{str(p):sha(p) for p in files},'input_hashes':{str(p):sha(p) for p in inputs},'check_passed':json.loads((R/'CHECKS.json').read_text())['passed']}
 if (R/'PROTOCOL.json').exists():assert json.loads((R/'PROTOCOL.json').read_text())==p
 else:save(R/'PROTOCOL.json',p)
 print('FROZEN',sha(R/'PROTOCOL.json'),flush=True)
def verify():
 p=json.loads((R/'PROTOCOL.json').read_text())
 for name,h in p['source_hashes'].items():assert sha(name)==h
 return p

def diag(model,ids):
 count=np.bincount(ids.ravel(),minlength=model.n).astype(float);mass=model.W.mean(1);avg=float(mass.mean());s=np.sort(count);n=len(s);corr=None
 if np.std(count)>0 and np.std(mass)>0:corr=float(spearmanr(mass,count).statistic)
 return {'mass_frequency_spearman':corr,'selected_mass_ratio':float(np.dot(mass,count)/count.sum()/avg) if avg>0 else None,'neighbor_count_gini':float(2*np.dot(np.arange(1,n+1),s)/(n*s.sum())-(n+1)/n),'effective_source_fraction':float(count.sum()**2/(n*np.square(count).sum()))}

def worker(fi,fold):
 p=verify();f=p['families'][fi];name=f['family'];out=R/'cases'/name/f'fold_{fold}';out.mkdir(parents=True,exist_ok=True);s=json.loads((PRIVATE/name/'repeat_1/split_PRIVATE.json').read_text());parent=np.array(s['train_indices'][:192]);seed=202611134000+10000*fi;parts=np.array_split(np.random.default_rng(seed+1000).permutation(len(parent)),3);iv=parts[fold];it=np.setdiff1d(np.arange(len(parent)),iv);fit=parent[it];val=parent[iv];assert not(set(fit)|set(val))&set(s['test_indices'])
 # Map only training and internal validation rows. No outer-test labels are read.
 Xall=np.load(D/f'{name}_X.npy',mmap_mode='r');Lall=np.load(D/f'{name}_L.npy',mmap_mode='r');X=Xall[fit];L=Lall[fit];Q=Xall[val];start=time.perf_counter();model=ShapeWeightedModel(X,L,zeta=.5);masks={'Full':tuple(range(model.m)),'cost40':tuple(next(x['indices'] for x in s['masks'] if x['name']=='b0_c40'))};pred={};diagnostics=[];statistics=[]
 sv=np.linalg.svd(model.W,compute_uv=False);power=float(np.square(sv).sum());mass=model.W.mean(1);singular=float(sv[0]**2/power) if power>0 else None
 for mask,P in masks.items():
  for mode in ['U','L','N','G']:
   ids=model.neighbors(Q[:,P],P,mode);prefix=f'{mask}__{mode}';raw=model.L[ids].mean(1);pred[prefix+'__raw']=raw;diagnostics.append({'mask':mask,'mode':mode,**diag(model,ids)})
   if mode=='G':continue
   rep=model.representation(P,mode);t=targets(model,rep,[seed+5000+100*fold+i for i in range(5)])
   for target,value in t.items():
    read=np.stack([v[ids].mean(1) for v in value]) if target=='random' else value[ids].mean(1);pred[prefix+'__'+target]=.5*raw+.5*read
   statistics.append({'mask':mask,'mode':mode,**rep['statistics'],'training_ball_shift_energy':float(np.square(rep['ball_residual']-model.L).sum(1).mean())})
  for null in range(5):
   pi=np.random.default_rng(seed+100*fold+null).permutation(model.n);ids=model.neighbors(Q[:,P],P,'T',pi);pred[f'{mask}__T{null}__raw']=model.L[ids].mean(1);diagnostics.append({'mask':mask,'mode':f'T{null}',**diag(model,ids)})
 pred['plain_mean']=np.tile(model.p,(len(val),1));np.savez_compressed(out/'predictions_PRIVATE.npz',**pred)
 save(out/'record_PRIVATE.json',{'family':name,'fold':fold,'fit_indices':fit.tolist(),'validation_indices':val.tolist(),'n_fit':len(fit),'n_validation':len(val),'protocol_sha256':sha(R/'PROTOCOL.json'),'predictions_sha256':sha(out/'predictions_PRIVATE.npz'),'weight_row_mass_cv':float(mass.std()/mass.mean()) if mass.mean()>0 else None,'weight_rank1_energy_fraction':singular,'diagnostics':diagnostics,'statistics':statistics,'wall_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024});print('FROZEN',name,fold,flush=True)
def run():
 p=verify();cases=[(fi,k) for fi in range(16) for k in range(3)]
 def call(case):
  fi,k=case;out=R/'cases'/p['families'][fi]['family']/f'fold_{k}';out.mkdir(parents=True,exist_ok=True)
  with open(out/'worker.log','w') as log:ret=subprocess.run([sys.executable,str(R/'run.py'),'worker',str(fi),str(k)],stdout=log,stderr=subprocess.STDOUT)
  if ret.returncode:raise RuntimeError('worker failed '+str(case))
  print('COMPLETE',p['families'][fi]['family'],k,flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(call,cases))
 save(R/'ALL_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(R/'PROTOCOL.json'),'records':{str(q.relative_to(R)):sha(q) for q in sorted((R/'cases').rglob('record_PRIVATE.json'))}});print('ALL48 FROZEN',flush=True)
def score():
 verify();frozen=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(frozen['records'])==48;rows=[];decomposition=[];maxdelta=0
 for name,h in frozen['records'].items():
  path=R/name;assert sha(path)==h;c=json.loads(path.read_text());assert sha(path.parent/'predictions_PRIVATE.npz')==c['predictions_sha256'];a=np.load(path.parent/'predictions_PRIVATE.npz');y=np.load(D/f"{c['family']}_L.npy",mmap_mode='r')[c['validation_indices']]
  for key in a.files:
   v=a[key];vs=list(v) if v.ndim==3 else [v];brier=float(np.mean([np.square(p-y).sum(1).mean() for p in vs]));mask,mode,target=key.split('__') if key!='plain_mean' else ('NA','NA','plain_mean');rows.append({'family':c['family'],'fold':c['fold'],'mask':mask,'mode':mode,'target':target,'n_validation':len(y),'brier':brier})
   if target in ['ball','covered_mean','global_mean','random']:
    raw=a[f'{mask}__{mode}__raw'];deltas=[p-raw for p in vs];cross=float(np.mean([2*np.sum((raw-y)*delta,axis=1).mean() for delta in deltas]));energy=float(np.mean([np.square(delta).sum(1).mean() for delta in deltas]));difference=brier-float(np.square(raw-y).sum(1).mean());maxdelta=max(maxdelta,abs(difference-cross-energy));assert abs(difference-cross-energy)<1e-12;decomposition.append({'family':c['family'],'fold':c['fold'],'mask':mask,'mode':mode,'target':target,'prediction_shift_energy':energy,'residual_alignment_term':cross,'brier_change':difference})
 summary=[]
 for key in sorted(set((r['family'],r['mask'],r['mode'],r['target']) for r in rows)):
  group=[r for r in rows if (r['family'],r['mask'],r['mode'],r['target'])==key];summary.append(dict(zip(['family','mask','mode','target'],key),brier=float(sum(r['brier']*r['n_validation'] for r in group)/sum(r['n_validation'] for r in group))))
 save(R/'RESULTS.json',{'scope':'Training-internal post-v1 development only; no new outer scoring','protocol_sha256':sha(R/'PROTOCOL.json'),'rows':rows,'summary':summary,'decomposition':decomposition,'maximum_decomposition_error':maxdelta});print('SCORED',len(rows),maxdelta,flush=True)
if __name__=='__main__':
 if sys.argv[1]=='worker':worker(int(sys.argv[2]),int(sys.argv[3]))
 else:globals()[sys.argv[1]]()
