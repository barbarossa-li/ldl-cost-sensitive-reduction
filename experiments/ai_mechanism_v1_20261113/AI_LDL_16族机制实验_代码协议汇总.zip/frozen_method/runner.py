"""Fixed-setting cross-family mechanism study. Individual artifacts stay private."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import json,sys,hashlib,time,argparse,resource
import numpy as np
HERE=Path(__file__).resolve().parent
os.environ.setdefault('AI_LDL_E0',str(HERE/'dependencies/e0'));os.environ.setdefault('AI_LDL_CORE',str(HERE/'dependencies/frozen_core'))
E03=Path(os.environ.get('AI_LDL_E03',str(HERE/'dependencies/e03')));sys.path.insert(0,str(E03))
from controls import predict,check
E02=Path(os.environ.get('AI_LDL_E02',str(HERE/'dependencies/e02')));sys.path.insert(0,str(E02))
from calibrated import CalibratedPrototypeModel

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def design(f,fi,r):
 n=f['N'];nt=min(384,7*n//10);nv=min(512,n-nt);seed=2026111300+100*fi+r;order=np.random.default_rng(seed).permutation(n);test=order[:nv];train=order[nv:nv+nt];m=f['m'];cost=np.random.default_rng(202611130000+fi).integers(1,11,m);masks=[]
 for bank in range(3):
  order=np.random.default_rng(seed+100000+bank).permutation(m);cum=np.cumsum(cost[order])
  for pct in [20,40,60,80]:
   P=sorted(map(int,order[cum<=pct*int(cost.sum())//100]));masks.append({'name':f'b{bank}_c{pct}','bank':bank,'budget':pct,'indices':P,'cost':int(cost[P].sum())})
 masks.append({'name':'Full','bank':None,'budget':100,'indices':list(range(m)),'cost':int(cost.sum())})
 return {'family':f['family'],'family_index':fi,'repeat':r,'seed':seed,'train_indices':train.tolist(),'test_indices':test.tolist(),'costs':cost.tolist(),'masks':masks}
def specs():return json.loads((HERE/'PROTOCOL.json').read_text())
def verify():
 p=specs()
 for name,h in p['source_hashes'].items():assert sha(HERE/name)==h,('source changed',name)
 return p

def prepare(args):
 p=verify();status=[]
 for fi,f in enumerate(p['families'],1):
  present=True
  for a in ['X','L']:
   path=args.data/f"{f['family']}_{a}.npy";ok=path.exists() and sha(path)==f[a+'_sha256'];present &=ok
   status.append({'family':f['family'],'array':a,'present':path.exists(),'hash_ok':bool(ok)})
  for r in range(1,6):
   c=design(f,fi,r);assert not(set(c['train_indices'])&set(c['test_indices']));out=args.output/f['family']/f'repeat_{r}';save(out/'split_PRIVATE.json',c)
 save(args.output/'INPUT_INVENTORY.json',status);save(args.output/'SPLIT_MANIFEST_PRIVATE.json',{str(q.relative_to(args.output)):sha(q) for q in sorted(args.output.rglob('split_PRIVATE.json'))})
 print('Prepared 80 private cases;',sum(r['hash_ok'] for r in status),'of 32 arrays verified; no downloads performed.')
def worker(args):
 p=verify();f=next(f for f in p['families'] if f['family']==args.family);fi=p['families'].index(f)+1;c=design(f,fi,args.repeat);out=args.output/f['family']/f'repeat_{args.repeat}';assert json.loads((out/'split_PRIVATE.json').read_text())==c
 for a in ['X','L']:assert sha(args.data/f"{f['family']}_{a}.npy")==f[a+'_sha256']
 X=np.load(args.data/f"{f['family']}_X.npy",mmap_mode='r');L=np.load(args.data/f"{f['family']}_L.npy",mmap_mode='r');assert X.shape==(f['N'],f['m']) and L.shape==(f['N'],f['q'])
 tr=c['train_indices'];te=c['test_indices'];start=time.perf_counter();model=CalibratedPrototypeModel(X[tr],L[tr],zeta=.5);pred={};stats=[]
 for j,mask in enumerate(c['masks']):
  P=tuple(mask['indices'])
  for w in ['U','L']:
   if not P:raise ValueError('Empty mask requires explicit pre-score protocol amendment; do not silently substitute')
   seeds=[c['seed']+300000+1000*j+i for i in range(5)];b,s=predict(model,X[te][:,P],P,w,seeds)
   for t,value in b.items():pred[f"{mask['name']}__{w}__{t}"]=value
   stats.append({'mask':mask['name'],'weight':w,**s})
 pred['plain_mean']=np.tile(model.p,(len(te),1));np.savez_compressed(out/'predictions_PRIVATE.npz',**pred)
 save(out/'record_PRIVATE.json',{'family':args.family,'repeat':args.repeat,'protocol_sha256':sha(HERE/'PROTOCOL.json'),'split_sha256':sha(out/'split_PRIVATE.json'),'prediction_sha256':sha(out/'predictions_PRIVATE.npz'),'statistics':stats,'wall_seconds':time.perf_counter()-start,'worker_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024})
 print('Prediction frozen',args.family,args.repeat,flush=True)
def freeze(args):
 p=verify();records={}
 for f in p['families']:
  for r in range(1,6):
   path=args.output/f['family']/f'repeat_{r}'/'record_PRIVATE.json';c=json.loads(path.read_text());assert c['protocol_sha256']==sha(HERE/'PROTOCOL.json');assert sha(path.parent/'predictions_PRIVATE.npz')==c['prediction_sha256'];assert sha(path.parent/'split_PRIVATE.json')==c['split_sha256'];records[str(path.relative_to(args.output))]=sha(path)
 save(args.output/'ALL_80_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(HERE/'PROTOCOL.json'),'records':records});print('All 80 predictions frozen; scoring is now enabled.')
def score(args):
 p=verify();frozen=json.loads((args.output/'ALL_80_PREDICTIONS_FROZEN.json').read_text());assert len(frozen['records'])==80 and frozen['protocol_sha256']==sha(HERE/'PROTOCOL.json');rows=[]
 from baseline_revision.prediction_evaluation import metrics
 for name,h in frozen['records'].items():
  path=args.output/name;assert sha(path)==h;c=json.loads(path.read_text());f=next(f for f in p['families'] if f['family']==c['family']);assert sha(args.data/f"{c['family']}_L.npy")==f['L_sha256'];s=json.loads((path.parent/'split_PRIVATE.json').read_text());assert sha(path.parent/'predictions_PRIVATE.npz')==c['prediction_sha256'];a=np.load(path.parent/'predictions_PRIVATE.npz');y=np.load(args.data/f"{c['family']}_L.npy",mmap_mode='r')[s['test_indices']]
  for mask in s['masks']:
   for w in ['U','L']:
    raw=a[f"{mask['name']}__{w}__raw"]
    for target in ['raw','global_mean','covered_mean','ball','random','ball_endpoint']:
     alpha=0. if target=='raw' else (1. if target=='ball_endpoint' else .5);t='ball' if target=='ball_endpoint' else target;value=raw if target=='raw' else (1-alpha)*raw+alpha*a[f"{mask['name']}__{w}__{t}"];vs=list(value) if value.ndim==3 else [value];ms=[metrics(y,v) for v in vs]
     row={'family':c['family'],'repeat':c['repeat'],'mask':mask['name'],'budget':mask['budget'],'bank':mask['bank'],'weight':w,'target':target,'alpha':alpha,'attributes':len(mask['indices']),'cost_fraction':mask['cost']/sum(s['costs'])}
     for k in ms[0]:row[k]=float(np.mean([v[k] for v in ms]))
     rows.append(row)
  rows.append({'family':c['family'],'repeat':c['repeat'],'mask':'NA','budget':0,'bank':None,'weight':'NA','target':'plain_mean',**metrics(y,a['plain_mean'])})
 save(args.output/'AGGREGATE_RESULTS_PUBLIC.json',{'protocol_sha256':sha(HERE/'PROTOCOL.json'),'rows':rows,'scope':'Known object-level benchmarks; family-level summaries must aggregate repeats, banks and budgets before inference.'});print('Scored',len(rows),'aggregate rows')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('action',choices=['prepare','worker','freeze','score']);ap.add_argument('--data',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--family');ap.add_argument('--repeat',type=int,choices=range(1,6));args=ap.parse_args();globals()[args.action](args)
