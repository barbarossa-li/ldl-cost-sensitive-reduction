# E0.2 scale calibration / matched shrinkage development probe

Read REPORT.md first. Nine known training-internal folds only, 4,401 descriptive metric rows; no new outer-test scoring and no best-zeta/alpha performance claim. All base predictions were frozen before metrics. Old E0 and the 76-page manuscript stay unchanged.

The new model fixes information/raw-component scales and a maximum scale from training Full, then reuses them for every subset/query. Zero-information and constant-feature branches are explicit. Old original mode reproduces E0. Row-shuffled weight controls and matched mean/ball shrinkage expose alignment and prior-smoothing effects.

## Reproduce

Install requirements; first obtain/hash-check the private three-family raw/converted cache from E0. `python reproduce.py --data /cache/data --output /new/empty/run --run`. Optional `--e0-records /extracted/private/E0/cases` also repeats the direct comparison to all saved E0 predictions. Without private E0 predictions, original-replay availability is not evidence of mismatch; calibration fixtures and aggregate result comparison still run. The adapter rebinds paths and records a new protocol SHA. Existing source/protocol identities are preserved in records.

To resume, use the LOCAL_BINDINGS paths for AI_LDL_E0 and AI_LDL_CORE and execute the prepared run_e02.py run, then score. Do not rewrite frozen sources or reuse a different protocol in the same output directory.

Only code, hashes, aggregate metrics and synthetic checks are public. Predictions, actual sample indices and raw arrays stay private. E0.2 is development evidence and does not add independent benchmark families or replace formal cross-family evaluation.
