from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,time,subprocess,concurrent.futures,resource
import numpy as np
R=Path(__file__).resolve().parent;M=Path(os.environ.get('AI_LDL_MAIN','/workspace/work/ai_mechanism_v1_20261113'));D=Path(os.environ.get('AI_LDL_DATA','/workspace/work/asc_experiments/data'));PRIVATE=Path(os.environ.get('AI_LDL_MAIN_PRIVATE','/workspace/work/ai_mechanism_v1_private_20261113'));sys.path.insert(0,os.environ.get('AI_LDL_E02','/workspace/work/ai_e02_20261113'))
from calibrated import CalibratedPrototypeModel
from prototype import PrototypePredictor,groups_from_representation

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def verify():
 p=json.loads((R/'PROTOCOL.json').read_text())
 for name,h in p['source_hashes'].items():assert sha(name)==h
 return p
def prepare():
 families=json.loads((M/'PROTOCOL.json').read_text())['families'];sources=[R/n for n in ['prototype.py','check.py','CHECKS.json','run.py']]+[M/'PROTOCOL.json']+[p for p in (M/'dependencies').rglob('*') if p.is_file() and p.suffix in ['.py','.json'] and '__pycache__' not in p.parts]
 inputs=[D/f"{f['family']}_{a}.npy" for f in families for a in ['X','L']]+[PRIVATE/f['family']/'repeat_1/split_PRIVATE.json' for f in families]
 for f in families:
  for a in ['X','L']:assert sha(D/f"{f['family']}_{a}.npy")==f[a+'_sha256']
 p={'version':'AI-E0.5-direct-prototype-development-v1','scope':'Post-v1 consulted-data development; same16 training pools/first min192 objects and3 folds as E0.4, no new outer-test scoring. All candidate prediction rules declared before internal scoring.','families':families,'cases':48,'fold_seed':'E0.4 exact fold permutation:202611134000+10000*family_index0based+1000','masks':['Full','v1-repeat1 bank0 cost40 mask'],'geometries':['U uniform','G feature-global mean of fitted local KL weights; no source-local weights in query retrieval'],'parameters':{'zeta':.5,'k':5,'smin':2,'kappa':.1,'radius_alpha':1,'pair_budget':256},'representation':'Each accepted anchored leaf contributes its arithmetic feature centroid in training-scaled selected coordinates and its mean label distribution. Uncovered objects contribute original scaled coordinates and labels. Raw baseline uses all singleton prototypes. Partition remains original frozen oracle.','inference':'Query only selected columns, training-fitted scaling and fixed Full calibration. Use nearest min(5,slots) prototypes, stable original-template anchor order. Compare uniform prototype voting and vote weighted by training group cardinality, both fixed. Predictor stores no training-source object/model reference.','controls':['raw singleton/source 5NN exact route','source neighbors with half ball-label smoothing','source neighbors with half global-mean shrinkage','same real-ball centers but accepted labels set to training mean, residual labels unchanged; uniform and mass votes','5 same-covered random partitions, exactly same accepted group-size sequence, residual IDs and prototype-slot keys; recompute feature centroids and label means; uniform and mass votes','plain global training mean'],'random_seed':'202611135000+10000*family_index0based+100*fold+null_index0..4','capacity':'Ball/random/covered-mean have identical number of slots and numeric array bytes. Raw holds more singleton slots. Report source-free numeric array bytes (centroids,labels,masses,P,scaling,feature weights,p), excluding Python/scalar metadata and training/cache storage.','null_scoring':'Average five seed losses, never loss of prediction ensemble or best-seed selection. Both voting rules reported; no winner selection claim.','isolation':'All48 prediction bundles and statistics frozen before loading internal validation labels for scoring. v1 outer test rows excluded. Previously observed data are not untouched confirmation.','gates':'Independent effect requires comparisons to same-capacity random groups and same-centers prior labels, not only raw. Simple global shrinkage remains a practical baseline. Novelty and external-selector superiority require separate evidence.','source_hashes':{str(p):sha(p) for p in sources},'input_hashes':{str(p):sha(p) for p in inputs},'checks':json.loads((R/'CHECKS.json').read_text())}
 if (R/'PROTOCOL.json').exists():assert json.loads((R/'PROTOCOL.json').read_text())==p
 else:save(R/'PROTOCOL.json',p)
 print('FROZEN',sha(R/'PROTOCOL.json'),flush=True)
def worker(fi,fold):
 p=verify();f=p['families'][fi];name=f['family'];out=R/'cases'/name/f'fold_{fold}';out.mkdir(parents=True,exist_ok=True);s=json.loads((PRIVATE/name/'repeat_1/split_PRIVATE.json').read_text());pool=np.array(s['train_indices'][:192]);parts=np.array_split(np.random.default_rng(202611134000+10000*fi+1000).permutation(len(pool)),3);v=parts[fold];fit=pool[np.setdiff1d(np.arange(len(pool)),v)];val=pool[v];assert set(fit).isdisjoint(val) and not(set(fit)|set(val))&set(s['test_indices'])
 Xall=np.load(D/f'{name}_X.npy',mmap_mode='r');Lall=np.load(D/f'{name}_L.npy',mmap_mode='r');X=Xall[fit];L=Lall[fit];Q=Xall[val];start=time.perf_counter();m=CalibratedPrototypeModel(X,L,zeta=.5);masks={'Full':tuple(range(m.m)),'cost40':tuple(next(x['indices'] for x in s['masks'] if x['name']=='b0_c40'))};pred={};stats=[]
 for mask,P in masks.items():
  for mode in ['U','G']:
   rep=m.representation(P,mode);groups,flags=groups_from_representation(m,rep);raw=PrototypePredictor(m,P,mode);ball=PrototypePredictor(m,P,mode,groups,flags);mean=PrototypePredictor(m,P,mode,groups,flags,covered_mean=True);prefix=f'{mask}__{mode}__';base=raw.predict(Q[:,P]);assert np.array_equal(base,m.predict_selected(Q[:,P],P,mode,readout='raw'));pred[prefix+'raw']=base
   pred[prefix+'source_ball_half']=.5*base+.5*m.predict_selected(Q[:,P],P,mode,readout='ball_residual');pred[prefix+'source_mean_half']=.5*base+.5*m.p
   for mass in [False,True]:
    vote='mass' if mass else 'uniform';pred[prefix+'direct_ball_'+vote]=ball.predict(Q[:,P],mass);pred[prefix+'direct_mean_'+vote]=mean.predict(Q[:,P],mass)
   random_pred={'uniform':[],'mass':[]}
   for j in range(5):
    nullgroups,nullflags=groups_from_representation(m,rep,202611135000+10000*fi+100*fold+j);null=PrototypePredictor(m,P,mode,nullgroups,nullflags);assert np.array_equal(null.masses,ball.masses) and null.array_bytes()==ball.array_bytes()==mean.array_bytes()
    for mass in [False,True]:random_pred['mass' if mass else 'uniform'].append(null.predict(Q[:,P],mass))
   for vote,values in random_pred.items():pred[prefix+'direct_random_'+vote]=np.stack(values)
   stats.append({'mask':mask,'geometry':mode,**rep['statistics'],'prototype_slots':len(ball.labels),'source_objects':m.n,'raw_numeric_array_bytes':raw.array_bytes(),'prototype_numeric_array_bytes':ball.array_bytes(),'array_byte_fraction':ball.array_bytes()/raw.array_bytes(),'accepted_groups':groups,'accepted_flags':flags.tolist()})
 pred['plain_mean']=np.tile(m.p,(len(val),1));np.savez_compressed(out/'predictions_PRIVATE.npz',**pred);save(out/'record_PRIVATE.json',{'family':name,'fold':fold,'fit_indices':fit.tolist(),'validation_indices':val.tolist(),'n_fit':len(fit),'n_validation':len(val),'protocol_sha256':sha(R/'PROTOCOL.json'),'predictions_sha256':sha(out/'predictions_PRIVATE.npz'),'statistics':stats,'wall_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024});print('FROZEN',name,fold,flush=True)
def run():
 p=verify()
 def one(case):
  fi,fold=case;out=R/'cases'/p['families'][fi]['family']/f'fold_{fold}';out.mkdir(parents=True,exist_ok=True)
  with open(out/'worker.log','w') as log:ret=subprocess.run([sys.executable,str(R/'run.py'),'worker',str(fi),str(fold)],stdout=log,stderr=subprocess.STDOUT)
  assert ret.returncode==0,case;print('COMPLETE',p['families'][fi]['family'],fold,flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(one,[(fi,k) for fi in range(16) for k in range(3)]))
 save(R/'ALL_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(R/'PROTOCOL.json'),'records':{str(q.relative_to(R)):sha(q) for q in sorted((R/'cases').rglob('record_PRIVATE.json'))}});print('ALL48 FROZEN',flush=True)
def score():
 verify();frozen=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(frozen['records'])==48;rows=[]
 for name,h in frozen['records'].items():
  path=R/name;assert sha(path)==h;c=json.loads(path.read_text());assert sha(path.parent/'predictions_PRIVATE.npz')==c['predictions_sha256'];a=np.load(path.parent/'predictions_PRIVATE.npz');y=np.load(D/f"{c['family']}_L.npy",mmap_mode='r')[c['validation_indices']]
  for key in a.files:
   values=list(a[key]) if a[key].ndim==3 else [a[key]];loss=[float(np.square(v-y).sum(1).mean()) for v in values];mask,geometry,method=key.split('__') if key!='plain_mean' else ('NA','NA','plain_mean');rows.append({'family':c['family'],'fold':c['fold'],'mask':mask,'geometry':geometry,'method':method,'n_validation':len(y),'brier':float(np.mean(loss)),'seed_briers':loss})
 summary=[]
 for key in sorted(set((r['family'],r['mask'],r['geometry'],r['method']) for r in rows)):
  group=[r for r in rows if (r['family'],r['mask'],r['geometry'],r['method'])==key];summary.append(dict(zip(['family','mask','geometry','method'],key),brier=sum(r['brier']*r['n_validation'] for r in group)/sum(r['n_validation'] for r in group)))
 save(R/'RESULTS.json',{'scope':'Consulted training-internal development only','protocol_sha256':sha(R/'PROTOCOL.json'),'rows':rows,'summary':summary,'new_outer_test_scored':False});print('SCORED',len(rows),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='worker':worker(int(sys.argv[2]),int(sys.argv[3]))
 else:globals()[sys.argv[1]]()
