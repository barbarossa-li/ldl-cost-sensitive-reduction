from pathlib import Path
import csv,json,shutil,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[2];DATA=ROOT/'supplementary'
summary=list(csv.DictReader(open(DATA/'dataset_summary.csv')));runs=list(csv.DictReader(open(DATA/'all_results.csv')))
by={(r['dataset'],r['method']):r for r in summary};names=list(dict.fromkeys(r['dataset'] for r in summary if r['role']=='main'))
def display(n):return {'Natural_Scene':'Natural Scene','SBU_3DFE':'SBU-3DFE','Human_Gene':'Human Gene','FG-Net':'FG-Net','SCUT_FBP':'SCUT-FBP','RAF_ML':'RAF-ML','MOR-PH':'MOR-PH'}.get(n,n.replace('Yeast_','Yeast-'))
def valid(d,m):return by[d,m]['valid_runs']=='3'
def value(d,m,k):return float(by[d,m][k+'_mean'])
methods=['GBIP-O1','GBFRS-EQ paper quota','IWDLFS paper CV','IWCLFS paper CV','GBFRS+objectwise prefix']
headers=['GBIP-O1','GBFRS-EQ','IWDLFS','IWCLFS','GBFRS+O1']
costrows=[];predrows=[]
for n in names:
 full=value(n,'Full','cost');costrows.append([display(n)]+[f'{100*value(n,m,"cost")/full:.2f}' if valid(n,m) else '--' for m in methods])
 predrows.append([display(n)]+[f'{value(n,m,"brier"):.5f}' if valid(n,m) else '--' for m in ['Full','Empty','GBIP-O1','GBFRS-EQ paper quota','IWDLFS paper CV','IWCLFS paper CV']])
plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
ns=[n for n in names if valid(n,'GBIP-O1')];fig,ax=plt.subplots(1,2,figsize=(7.1,9),sharey=True,layout='constrained');y=np.arange(len(ns))
for j,n in enumerate(ns):
 a=value(n,'GBIP-O1','cost');f=value(n,'Full','cost');ax[0].barh(j,100*(1-a/f),color='#287d8e',height=.65)
 rr=[r for r in runs if r['dataset']==n and r['method']=='GBIP-O1'];ff={r['repeat']:r for r in runs if r['dataset']==n and r['method']=='Full'}
 delta=[100*(float(r['brier'])/float(ff[r['repeat']]['brier'])-1) for r in rr]
 ax[1].scatter(delta,[j]*3,s=17,color='#af6635',alpha=.7,label='Frozen split' if j==0 else None);ax[1].scatter([statistics.mean(delta)],[j],marker='D',s=20,color='black',label='Mean across splits' if j==0 else None)
ax[0].set_yticks(y,[display(n) for n in ns]);ax[0].invert_yaxis();ax[0].set_xlabel('Acquisition-cost\nreduction (%)');ax[0].set_xlim(0,100);ax[1].axvline(0,color='.6',lw=.8);ax[1].set_xlabel('Paired Brier change\nrelative to Full (%)');ax[0].set_title('(a) Cost reduction');ax[1].set_title('(b) Paired Brier change');ax[1].legend(loc='lower left',fontsize=8,frameon=False);fig.savefig(ROOT/'cost_prediction.png',dpi=220);plt.close(fig)
fig,ax=plt.subplots(figsize=(6.8,3.8),layout='constrained');labels=[]
for i,m in enumerate(methods):
 group=[r for r in runs if r['role']=='main' and r['method']==m];ok=[r for r in group if r['brier']];passed=sum(float(r['violated_objects'])==0 for r in ok);counts=[passed,len(ok)-passed,75-len(ok)]
 left=0
 for num,color in zip(counts,['#287d8e','#ba7844','#c9c9c9']):
  ax.barh(i,num,left=left,color=color,height=.6)
  if num:ax.text(left+num/2,i,str(num),ha='center',va='center',fontsize=12)
  left+=num
 labels.append(headers[i])
ax.set_yticks(range(len(labels)),labels);ax.invert_yaxis();ax.set_xlim(0,75);ax.set_xlabel('Task–split cases (25 tasks × 3 frozen splits)');from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=c,label=l) for c,l in zip(['#287d8e','#ba7844','#c9c9c9'],['Feasible','Violating','Unavailable'])],loc='upper center',bbox_to_anchor=(.5,-.22),ncol=3,frameon=False);fig.savefig(ROOT/'preservation.png',dpi=220);plt.close(fig)

# Object-level reconstruction changes from the frozen diagnostic CSV.
obj=list(csv.DictReader((DATA/'m1_m2/object_errors.csv').open()))
fig,axes=plt.subplots(2,1,figsize=(8,5.6),layout='constrained')
for ax,name in zip(axes,['Yeast_cold','SCUT_FBP']):
 for method,color,label in [('average','#b76738','Mean preservation'),('objectwise','#277a8a','Objectwise preservation')]:
  group=[r for r in obj if r['dataset']==name and r['criterion']==method]
  x=[int(r['train_position']) for r in group];y=np.array([float(r['error_increase']) for r in group]);y[np.abs(y)<=1e-12]=0
  ax.scatter(x,y,s=10,color=color,alpha=.7,label=label)
 ax.axhline(0,color='.5',lw=.8);ax.set_title(name.replace('_','-'));ax.set_ylabel('Reconstruction error\nchange vs full reference');ax.set_xlabel('Fixed training-object position');ax.legend(frameon=False,fontsize=8,ncol=2)
fig.savefig(ROOT/'paper_figures/objectwise_tradeoff.png',dpi=200);plt.close(fig)
# Nested-sample results: only the label is changed to specify absolute Brier differences.
rr=list(csv.DictReader((DATA/'m3_audit/all_results.csv').open()))
ss=list(csv.DictReader((DATA/'m3_audit/scale_summary.csv').open()))
fig,axes=plt.subplots(2,3,figsize=(10.5,5.5),sharey='row',layout='constrained')
for j,ds in enumerate(['Yeast_cold','SCUT_FBP','Human_Gene']):
 for method,color in [('GBIP-O1','#168294'),('Mean','#cb7942')]:
  # Frozen M3 stores the comparator as Mean.
  group=sorted([r for r in ss if r['dataset']==ds and r['method']==method],key=lambda r:int(r['training_size']))
  assert group,(ds,method,sorted(set(r['method'] for r in ss)))
  n=[int(r['training_size']) for r in group]
  axes[0,j].plot(n,[100*float(r['cost_fraction_mean']) for r in group],'-o',color=color,label=method)
  axes[1,j].plot(n,[float(r['brier_delta_vs_full_mean']) for r in group],'-o',color=color)
  single=[r for r in rr if r['dataset']==ds and r['method']==method]
  axes[0,j].scatter([int(r['training_size']) for r in single],[100*float(r['cost_fraction']) for r in single],s=12,color=color,alpha=.35)
  axes[1,j].scatter([int(r['training_size']) for r in single],[float(r['brier_delta_vs_full']) for r in single],s=12,color=color,alpha=.35)
 axes[0,j].set_title(ds.replace('_','-'));axes[1,j].axhline(0,color='.5',lw=.8)
 axes[1,j].set_xticks(n,n,rotation=25);axes[1,j].set_xlabel('Training objects')
 for ax in axes[:,j]:ax.grid(alpha=.2)
axes[0,0].legend(frameon=False);axes[0,0].set_ylabel('Acquisition cost\nretained (%)');axes[1,0].set_ylabel('Test Brier difference\nB(P) - B(A)')
fig.savefig(ROOT/'paper_figures/sample_size_sensitivity.png',dpi=220);plt.close(fig)

OUT=DATA/"tolerance_envelope/results"
rows=json.loads((OUT/"endpoint_assessment.json").read_text())["rows"]
knots=np.array([r["maximum_increase"] for r in rows])
x=np.r_[knots,.60]
def extended(values):return np.r_[values,values[-1]]
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"svg.fonttype":"none"})
fig,grid=plt.subplots(2,2,figsize=(7.4,5.9))
axes=grid.ravel()
ax=axes[0]
ax.step(x,extended([100*r["attributes"]/512 for r in rows]),where="post",color="#176b87",lw=2)
ax.scatter(knots,[100*r["attributes"]/512 for r in rows],color="#176b87",s=22,zorder=3)
ax.axvspan(0,.48,color="#e8f1f4")
ax.text(.09,45,"Lowest recorded feasible\nstorage\nremains Full\nfor τ ≤ 0.48",fontsize=8)
ax.set(ylabel="Training-feature storage retained (%)",ylim=(-3,105),title="(a) Storage among recorded subsets")
ax=axes[1]
definitions=[
 ("Reference-correct top-1 lost","reference_correct_lost","reference_correct_unique","#b34a37"),
 ("Reference-correct top-2 lost","top2_reference_correct_lost","top2_reference_correct","#735caa"),
 ("Pairwise loss increased","pairwise_rank_worse","pairwise_rank_eligible_objects","#bb8425"),
]
for label,num,den,color in definitions:
    y=[100*r[num]/r[den] if r[den] else np.nan for r in rows]
    ax.step(x,extended(y),where="post",label=label,color=color,lw=1.6)
ax.set(ylabel="Affected eligible occurrences (%)",title="(b) Decisions at selected subsets")
ax.set_ylim(-1, 1.15*max(100*r[num]/r[den] for r in rows for _,num,den,_ in definitions if r[den]))
ax.legend(loc="best",fontsize=7,frameon=False)
ax=axes[2]
y=[r["test"]["brier"] for r in rows]
ax.step(x,extended(y),where="post",color="#307d4c",lw=1.8)
ax.scatter(knots,y,color="#307d4c",s=22)
ax.axhline(y[0],color="#777777",linestyle=":",lw=1)
ax.set(ylabel="Held-out Brier error",title="(c) Held-out distribution prediction")
ax=axes[3]
profile=json.loads((OUT/"margin_certificate_profile.json").read_text())
cx=[point["tolerance"] for point in profile["rows"]]
cy=[100*point["certified"]/profile["unique_target_objects"] for point in profile["rows"]]
ax.step(cx,cy,where="post",color="#42638c",lw=1.8)
ax.scatter(knots,[100*r["margin_certified_correct"]/r["target_unique_max_objects"] for r in rows],color="#42638c",s=22)
ax.set(ylabel="Margin-certified unique maxima (%)",
       title="(d) Bound-based certificate coverage")
for ax in axes:
    ax.set_xlim(-.01,.605);ax.set_xlabel("Allowed maximum error increase τ")
    ax.spines[["top","right"]].set_visible(False);ax.grid(axis="y",alpha=.2)
fig.tight_layout(w_pad=1.2,h_pad=1.6)
fig.savefig(ROOT/"paper_figures/fbp5500_tolerance_storage.png",dpi=260,bbox_inches="tight")
fig.savefig(ROOT/"paper_figures/fbp5500_tolerance_storage.svg",bbox_inches="tight")
plt.close(fig)
