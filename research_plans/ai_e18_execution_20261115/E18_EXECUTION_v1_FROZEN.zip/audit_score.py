"""All20-case freeze gate, independent input/state/CV audit, then outer scoring."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
os.environ.setdefault('LDL_PARENT_SOURCE','/workspace/work/ai_external_v1_20261114/source')
import sys,json,hashlib,csv,collections
import numpy as np
import data,encoding
from selection import resource
import learners as l
r=l.r;ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def metrics(y,v):
 d=abs(y-v);s=y+v;z=np.divide(d,s,out=np.zeros_like(d),where=s>0);return {'brier':float(np.mean(np.sum((y-v)**2,axis=1))),'chebyshev':float(d.max(1).mean()),'clark':float(np.sqrt(np.sum(z*z,axis=1)).mean()),'canberra':float(z.sum(1).mean()),'kl':float(np.sum(np.where(y>0,y*np.log(np.where(y>0,y,1)/np.maximum(v,1e-12)),0),axis=1).mean()),'cosine':float(np.mean(np.sum(y*v,axis=1)/(np.linalg.norm(y,axis=1)*np.linalg.norm(v,axis=1)))),'intersection':float(np.minimum(y,v).sum(1).mean())}
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);a=ap.parse_args();base=a.base;run=base/'run';output=base/'public';output.mkdir(exist_ok=True);freeze=json.loads((run/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(freeze['records'])==20;expected={f'primary/{task}/fold_{i}/record_PRIVATE.json' for task in data.TASKS for i in range(5)}|{f'rater_disjoint/DICES990/fold_{i}/record_PRIVATE.json' for i in range(5)};assert set(freeze['records'])==expected;assert freeze['execution_manifest_sha256']==sha(ROOT/'MANIFEST.json')
 for name,h in freeze['records'].items():assert sha(run/name)==h
 # No new-task outer target is accessed before the full global gate above.
 counts=collections.Counter();rows=[];cvrows=[];selections=[];failures=[];pooled=collections.defaultdict(list);seen={};maxmetric=0.;maxstate=0.
 for name,h in freeze['records'].items():
  path=run/name;directory=path.parent;rec=json.loads(path.read_text());task,stage,fold=rec['task'],rec['stage'],rec['fold'];assert rec['design_protocol_sha256']==sha(base/'source/PROTOCOL.json') and rec['execution_manifest_sha256']==sha(ROOT/'MANIFEST.json')
  for filename,checksum in rec['artifact_sha256'].items():assert sha(directory/filename)==checksum
  counts['frozen_cases']+=1;detail=rec['details']
  if detail['status']=='case_failure':failures.append({'task':task,'stage':stage,'fold':fold,'policy':'ALL17','type':detail['type'],'message':detail['message']});continue
  train,Y,query,parts,metadata=data.case(base,task,fold,stage);assert metadata==rec['metadata'];assert [h.tolist() for h in parts]==detail['inner_folds'];counts['group_split_cases']+=1
  ids,text,targets,keys,info=data.load(base,task,'query' if stage=='rater_disjoint' else 'all');mapping={key:i for i,key in enumerate(ids)};y=np.asarray([targets[mapping[key]] for key in metadata['query_ids']]);qset=seen.setdefault((stage,task),set());assert not qset&set(metadata['query_ids']);qset.update(metadata['query_ids'])
  if stage=='rater_disjoint':assert not set(metadata['cohort']['rater_ids'])&set(info['rater_ids']);counts['rater_disjoint_cases']+=1
  encmeta=json.loads((directory/'encoder_PRIVATE.json').read_text());encarr=np.load(directory/'encoder_PRIVATE.npz');encoder={'vocabulary':encmeta['vocabulary'],'idf':encarr['idf'],'components':encarr['components']};Q=encoding.transform(encoder,query)
  A,B,st,fp=encoding.fit(train,query);assert fp==detail['outer_fingerprint'] and fp==encoding.fingerprint(encoder);assert np.array_equal(Q,B);counts['outer_encoder_refits']+=1
  for inner,h in enumerate(parts):
   fit=np.setdiff1d(np.arange(len(train)),h);old=detail['inner_encoders'][inner];assert old['fit_positions']==fit.tolist() and old['query_positions']==h.tolist();_,_,st,fp=encoding.fit([train[i] for i in fit],[train[i] for i in h]);assert fp==old['fingerprint'];counts['inner_encoder_refits']+=1
  cv=np.load(directory/'inner_predictions_PRIVATE.npz');bymethod=collections.defaultdict(list)
  for row in detail['cv_scores']:
   v=cv[row['method']+'___'+row['id']];assert bool(np.isfinite(v).all())==row['available']
   if row['available']:r.valid(v,len(train),Y.shape[1]);risk=float(np.square(v-Y).sum(1).mean());assert abs(risk-row['risk'])<1e-12;counts['inner_candidate_scores']+=1
   bymethod[row['method']].append(row);cvrows.append({'stage':stage,'task':task,'fold':fold,**row,'params':json.dumps(row['params'],sort_keys=True)})
  for policy,choice in detail['choices'].items():
   method='U' if policy=='G_atU' else policy.split('_')[0];menu=[x for x in bymethod[method] if x['available']];best=min(x['risk'] for x in menu);expected=min([x for x in menu if x['risk']<=best+1e-12],key=lambda x:(resource(method,x['params'],len(train),Q.shape[1],Y.shape[1]),x['id']));assert choice['id']==expected['id'];counts['selection_decisions']+=1;selections.append({'stage':stage,'task':task,'fold':fold,'policy':policy,'candidate_id':choice['id'],'params':json.dumps(choice['params'],sort_keys=True),'mean_only':choice['params'].get('kind')=='Mean','inner_brier':choice['risk']})
  pred=np.load(directory/'predictions_PRIVATE.npz');stored=np.load(directory/'estimator_states_PRIVATE.npz');sizes={}
  for key in pred.files:
   v=pred[key];r.valid(v,len(y),y.shape[1]);state=dict(detail['state_metadata'][key]);prefix=key+'___'
   for k in stored.files:
    if k.startswith(prefix):state[k[len(prefix):]]=stored[k]
   needs=state['kind']!='Mean';replay=l.predict(state,Q if needs else query);err=float(abs(replay-v).max());assert err<1e-7;maxstate=max(maxstate,err);counts['state_predictions']+=1;res=detail['resources'][key];assert l.byte_count(state)==res['estimator_numeric_array_bytes'];sizes[key]=l.byte_count(state);assert res['encoder_numeric_array_bytes']==((encoder['idf'].nbytes+encoder['components'].nbytes) if needs else 0);assert res['latent_query_features']==(Q.shape[1] if needs else 0)
   from selection import state_bytes
   mm,nn=state_bytes(state);assert len(mm)+len(nn)==res['estimator_serialized_bytes'];encsize=(directory/'encoder_PRIVATE.json').stat().st_size+(directory/'encoder_PRIVATE.npz').stat().st_size;assert res['encoder_required']==needs and res['encoder_serialized_bytes']==(encsize if needs else 0);assert res['deployed_serialized_file_bytes']==len(mm)+len(nn)+(encsize if needs else 0)
   score=metrics(y,v);ref=r.metrics(y,v)
   for metric in score:maxmetric=max(maxmetric,abs(score[metric]-ref[metric]));assert abs(score[metric]-ref[metric])<1e-9
   rows.append({'stage':stage,'task':task,'fold':fold,'policy':key,'query_n':len(y),**res,**score});pooled[stage,task,key].append((len(y),score))
  if all(key in sizes for key in ['UU50_fixed','GG50_fixed','GU50_fixed','UG50_fixed']):assert len({sizes[key] for key in ['UU50_fixed','GG50_fixed','GU50_fixed','UG50_fixed']})==1;counts['matched_factorial_cases']+=1
  if 'G_atU' in sizes and 'U_min' in sizes:assert sizes['G_atU']==sizes['U_min'];counts['matched_selected_cases']+=1
  for key,error in detail['policy_failures'].items():failures.append({'task':task,'stage':stage,'fold':fold,'policy':key,**error})
 summary=[]
 for (stage,task,policy),pieces in sorted(pooled.items()):
  n=sum(x[0] for x in pieces);score={m:sum(nn*s[m] for nn,s in pieces)/n for m in pieces[0][1]};summary.append({'stage':stage,'task':task,'policy':policy,'cases_available':len(pieces),'query_n':n,'complete_five_folds':len(pieces)==5,**score})
 for name,items in [('CASE_METRICS.csv',rows),('CV_SCORES.csv',cvrows),('SELECTIONS.csv',selections),('SUMMARY.csv',summary)]:
  if items:
   with (output/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(items[0]));w.writeheader();w.writerows(items)
 lookup={(x['stage'],x['task'],x['policy']):x for x in summary};primary={}
 for task in data.TASKS:
  a=lookup.get(('primary',task,'GG50_fixed'));b=lookup.get(('primary',task,'UU50_fixed'));complete=bool(a and b and a['complete_five_folds'] and b['complete_five_folds']);primary[task]={'complete':complete,'GG_minus_UU':a['brier']-b['brier'] if a and b else None}
 family={}
 for fam,tasks in [('NLI',['ChaosSNLI','ChaosMNLI']),('ConversationSafety',['DICES990'])]:
  complete=all(primary[t]['complete'] for t in tasks);difference=float(np.mean([primary[t]['GG_minus_UU'] for t in tasks])) if all(primary[t]['GG_minus_UU'] is not None for t in tasks) else None;family[fam]={'complete':complete,'GG_minus_UU':difference,'directional_criterion_met':bool(complete and difference< -1e-12),'independent_application_families':1}
 audit={'passed':True,'counts':dict(counts),'max_state_reconstruction_error':maxstate,'max_metric_discrepancy':maxmetric,'policy_failures':failures,'primary_corpora':primary,'primary_application_families':family,'scope':'Two related NLI strata and conversation safety; rater transport secondary, not image-subject confirmation. No p-value from repeated folds. Encoder included in serialized deployment totals.','design_protocol_sha256':sha(base/'source/PROTOCOL.json'),'execution_manifest_sha256':sha(ROOT/'MANIFEST.json')};(output/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
