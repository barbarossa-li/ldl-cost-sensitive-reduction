"""Matched deletion schedules for a deterministic FIXED-reference feasibility oracle."""
import math
import operator


def delete(costs, feasible, start, budget, mode='sweep'):
    costs=tuple(float(c) for c in costs)
    if not costs or any(not math.isfinite(c) or c<=0 for c in costs):
        raise ValueError('Finite positive costs required')
    try: total=math.fsum(costs)
    except OverflowError as error:raise ValueError('Nonfinite total cost') from error
    if not math.isfinite(total):raise ValueError('Nonfinite total cost')
    if mode not in ('sweep','restart'):raise ValueError('Invalid mode')
    if not isinstance(budget,int) or isinstance(budget,bool) or budget<0:raise ValueError('Invalid budget')
    selected=tuple(sorted(operator.index(a) for a in start))
    if len(selected)!=len(set(selected)) or any(a<0 or a>=len(costs) for a in selected):
        raise ValueError('Invalid start')
    cache={}
    def check(P):
        if P not in cache:
            value=feasible(P)
            if not isinstance(value,bool):raise ValueError('Boolean fixed-reference oracle required')
            cache[P]=value
        return cache[P]
    if not check(selected):raise ValueError('Feasible start required')
    initial=selected;requests=0;trace=[];trials=[];passes=[];irreducible=not selected
    while selected:
        order=sorted(selected,key=lambda a:(-costs[a],a));changed=0;scanned=0
        for a in order:
            if requests>=budget:break
            candidate=tuple(b for b in selected if b!=a)
            requests+=1;scanned+=1;accepted=check(candidate)
            trials.append(dict(request=requests,pass_index=len(passes)+1,removed=a,accepted=accepted))
            if accepted:
                trace.append(dict(request=requests,before=list(selected),after=list(candidate),removed=a,saved_cost=costs[a]))
                selected=candidate;changed+=1
                if mode=='restart':break
        complete=scanned==len(order)
        passes.append(dict(initial_attributes=len(order),scanned=scanned,accepted=changed,complete=complete))
        if not selected:irreducible=True;break
        if complete and changed==0:irreducible=True;break
        if requests>=budget:break
    return dict(mode=mode,selected=list(selected),cost=math.fsum(costs[a] for a in selected),
                start=list(initial),candidate_requests=requests,budget=budget,
                accepted_deletions=len(trace),completed_passes=sum(p['complete'] for p in passes),
                single_deletion_irreducible=irreducible,global_optimal=None,
                stop_reason='complete_unsuccessful_scan' if irreducible else 'request_budget',
                unique_oracle_calls=len(cache),trace=trace,trials=trials,passes=passes)
