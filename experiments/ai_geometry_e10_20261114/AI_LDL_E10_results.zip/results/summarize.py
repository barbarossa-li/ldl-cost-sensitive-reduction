"""Complete fixed-setting E10 factorial contrasts; no best-setting selection."""
from pathlib import Path
import argparse,json,itertools
import numpy as np

def summarize(run):
 results=json.loads((run/'RESULTS_PUBLIC.json').read_text());families=sorted({r['family'] for r in results['family_summary']});lookup={(r['family'],r['key']):r for r in results['family_summary']};contrasts=[];settings=[]
 for mask,m,b,a in itertools.product(['Full','cost40'],['geometric','kmeanspp','bisecting','paper20'],['K5','25','50','75','100'],['0.0','0.5']):
  keys={c+q:f'{mask}__{c}__{m}__{b}__{q}__a{a}' for c,q in itertools.product(['U','G'],repeat=2)}
  values={cell:np.array([lookup[f,key]['brier'] for f in families]) for cell,key in keys.items()}
  t=dict(mask=mask,constructor=m,budget=b,alpha=a);settings.append(dict(setting=t,equal_family_risks={cell:float(v.mean()) for cell,v in values.items()},mean_array_fraction=float(np.mean([lookup[f,keys['UU']]['array_fraction'] for f in families])),mean_array_bytes=float(np.mean([lookup[f,keys['UU']]['array_bytes'] for f in families]))))
  diffs={'construction_Q_U':values['GU']-values['UU'],'construction_Q_G':values['GG']-values['UG'],'query_C_U':values['UG']-values['UU'],'query_C_G':values['GG']-values['GU'],'interaction':values['GG']-values['GU']-values['UG']+values['UU'],'combined':values['GG']-values['UU']}
  for kind,delta in diffs.items():
   contrasts.append(dict(kind=kind,setting=t,mean_brier_difference=float(delta.mean()),negative=sum(int(d < -1e-12) for d in delta),tie=sum(int(abs(d)<=1e-12) for d in delta),positive=sum(int(d>1e-12) for d in delta),family_differences=dict(zip(families,delta.tolist()))))
 return dict(scope=results['scope'],families=families,settings=settings,contrasts=contrasts,cell_order='Construction first, query second: UU/GU/UG/GG',difference_direction='Negative conditional contrast favors G; negative interaction is nonadditive reduction relative to UU, not a standalone superiority comparison',primary_display='geometric alpha0.5, Full/cost40, all25/50/75 budgets; all remaining settings retained',tie_tolerance=1e-12)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);a=p.parse_args();print(json.dumps(summarize(a.run),indent=2))
