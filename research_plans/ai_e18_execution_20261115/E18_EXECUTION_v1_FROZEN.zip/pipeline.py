"""Local asynchronous runner -> all-case gate -> independent audit -> archives.
No external uploads, publication or manuscript editing performed here.
"""
from pathlib import Path
import os,sys,json,time,subprocess,traceback,hashlib,zipfile,csv
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
ROOT=Path(__file__).resolve().parent

def save(path,x):
 path=Path(path);t=path.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2)+'\n');t.replace(path)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def archive(base):
 dest=base/'final_private_archives';dest.mkdir(exist_ok=True);files=[p for folder in ['source','execution','run'] for p in (base/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts];parts=[];z=None;counter=0
 for p in sorted(files):
  if z is None:counter+=1;name=dest/f'E18_COMPLETE_PRIVATE_part{counter}.zip';z=zipfile.ZipFile(name,'w',zipfile.ZIP_DEFLATED,compresslevel=6)
  z.write(p,str(p.relative_to(base)))
  if z.fp.tell()>75*1024**2:z.close();parts.append(name);z=None
 if z:z.close();parts.append(name)
 rows=[]
 for p in parts:
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
  rows.append({'file':str(p),'bytes':p.stat().st_size,'sha256_local_archive':sha(p),'external_sync':'pending connector upload/verification'})
 save(dest/'ARCHIVE_MANIFEST_PRIVATE.json',{'parts':rows,'run_freeze_sha256':sha(base/'run/ALL_PREDICTIONS_FROZEN.json'),'raw_source_data':'Already cached separately; no duplication here'})
 return rows

def report(base):
 out=base/'public';audit=json.loads((out/'AUDIT.json').read_text());rows=list(csv.DictReader((out/'SUMMARY.csv').open())) if (out/'SUMMARY.csv').exists() else [];text=['# E18 new-task confirmation results','','Two text application families: related ChaosSNLI/ChaosMNLI NLI strata and DICES conversation safety. Rater-disjoint DICES is secondary transport, not old image-subject confirmation. Original E12 fixed primary and E16/E17 development evidence retain their status.','','## Predeclared primary family contrasts','','| Family | Complete | GG50 minus UU50 Brier | Directional criterion |','|---|---|---:|---|']
 for family,value in audit['primary_application_families'].items():text.append(f"| {family} | {value['complete']} | {value['GG_minus_UU']} | {value['directional_criterion_met']} |")
 text+=['','Negative differences favor informative geometry. Missing primary cases prevent a complete directional confirmation. No p-value from5 folds or2 application families. Per-corpus values must be shown even if a family average improves.','','## Object-pooled risk by task and policy','','| Stage | Task | Policy | Cases | Query objects | Brier |','|---|---|---|---:|---:|---:|']
 for row in rows:text.append(f"| {row['stage']} | {row['task']} | {row['policy']} | {row['cases_available']} | {row['query_n']} | {float(row['brier']):.8f} |")
 text+=['','CASE_METRICS.csv contains estimator-only numeric arrays, required shared encoder arrays, encoder serialized bytes and total deployable file-byte sums. Mean-only selections need no encoder; distinguish these from learned compressed geometry. Independently selected G/U policies can have different capacity. G_atU and U_min are the matched selected comparison. RkNN is the pointwise training-gamma adapter with a limited declared grid, not exhaustive SOTA tuning.','',f"Audit counts: {json.dumps(audit['counts'],sort_keys=True)}. All recorded failures remain in AUDIT.json. Postprocessing is local; external synchronization and manuscript integration have not been performed automatically."]
 (out/'REPORT.md').write_text('\n'.join(text)+'\n');save(out/'ARTIFACT_MANIFEST.json',{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='ARTIFACT_MANIFEST.json'})

def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);ap.add_argument('--parent-source',type=Path,required=True);a=ap.parse_args();base=a.base;status=base/'PIPELINE_STATUS_PRIVATE.json';os.environ['LDL_PARENT_SOURCE']=str(a.parent_source);os.environ.setdefault('MPLCONFIGDIR','/workspace/work/matplotlib_cache');os.environ.setdefault('XDG_CACHE_HOME','/workspace/var/cache')
 try:
  for name,h in json.loads((ROOT/'MANIFEST.json').read_text()).items():assert sha(ROOT/name)==h
  if not (base/'run/ALL_PREDICTIONS_FROZEN.json').exists():
   with (base/'execution_run.log').open('a') as log,(base/'execution_run.stderr').open('a') as error:
    child=subprocess.Popen([sys.executable,str(ROOT/'run.py'),'--base',str(base),'--parent-source',str(a.parent_source)],stdout=log,stderr=error,env=os.environ)
    while child.poll() is None:
     save(status,{'status':'running_predictions','runner_pid':child.pid,'completed_cases':len(list((base/'run').rglob('record_PRIVATE.json'))),'expected_cases':20,'execution_manifest_sha256':sha(ROOT/'MANIFEST.json'),'outer_scoring':'not started; waits for all20 freeze','external_sync':'not attempted'});time.sleep(10)
    if child.returncode:raise RuntimeError('Runner exited with code'+str(child.returncode))
  save(status,{'status':'auditing_after_complete_prediction_freeze','completed_cases':20,'external_sync':'not attempted'})
  with (base/'audit.log').open('w') as log:subprocess.run([sys.executable,str(ROOT/'audit_score.py'),'--base',str(base)],stdout=log,stderr=subprocess.STDOUT,check=True,env=os.environ)
  report(base);parts=archive(base);save(status,{'status':'local_audits_passed_and_archives_ready','completed_cases':20,'archives':parts,'external_sync':'pending connector upload and metadata verification; public publication/manuscript update not automatic','next':'Review all positive/negative/incomplete outcomes, sync private archives, then publish aggregate-only evidence and update author-review manuscript without changing primary endpoints.'})
 except BaseException as e:
  save(status,{'status':'stopped_on_error','type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'external_sync':'not attempted'});raise
if __name__=='__main__':main()
