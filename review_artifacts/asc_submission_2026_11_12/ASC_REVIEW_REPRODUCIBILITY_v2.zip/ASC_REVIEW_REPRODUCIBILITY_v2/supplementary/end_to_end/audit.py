"""Recompute timing medians and confirm the returned trial-level comparisons."""
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import median

path = Path(__file__).with_name("end_to_end.json")
record = json.loads(path.read_text(encoding="utf-8"))
assert record["protocol_sha256"] == "117e13a759d650192b97f51796d55db42b1ea2e552e3c4815d858a23f4f6d621"
assert record["warmups"] == 2 and record["repetitions"] == 7
assert record["torch_threads"] == 4 and record["batch_size"] == 32
assert record["torch"] == "2.5.1+cpu" and record["torchvision"] == "0.20.1+cpu"
timing_keys = ("image_read_decode_seconds", "transform_resnet18_seconds",
               "backend_seconds", "end_to_end_seconds")
summaries = {}
for method in ("Full", "Mean"):
    trials = record["trials"][method]
    assert len(trials) == 7
    for trial in trials:
        assert all(math.isfinite(value) and value >= 0 for value in trial.values())
        assert all(trial[key] > 0 for key in timing_keys)
        assert trial["end_to_end_seconds"] >= sum(trial[key] for key in timing_keys[:-1])
        assert trial["prediction_max_abs_diff"] == 0
    summary = {key: median(trial[key] for trial in trials) for key in trials[0]}
    assert summary == record["summary_medians"][method]
    summaries[method] = summary
full, mean = summaries["Full"], summaries["Mean"]
reduction = 1 - mean["end_to_end_seconds"] / full["end_to_end_seconds"]
assert reduction == record["end_to_end_fraction_reduction"]
print(json.dumps({
    "return_sha256": sha256(path.read_bytes()).hexdigest(),
    "scope": "Recalculation of returned trial summaries; no independent rerun of image inference.",
    "verified_rounds_per_method": 7,
    "summary_medians": summaries,
    "backend_fraction_reduction": 1 - mean["backend_seconds"] / full["backend_seconds"],
    "end_to_end_fraction_reduction": reduction,
    "end_to_end_seconds_saved": full["end_to_end_seconds"] - mean["end_to_end_seconds"],
    "feature_max_abs_diff_over_all_trials": max(
        trial["feature_max_abs_diff"] for trials in record["trials"].values() for trial in trials
    ),
    "prediction_max_abs_diff_over_all_trials": 0,
}, indent=2))
