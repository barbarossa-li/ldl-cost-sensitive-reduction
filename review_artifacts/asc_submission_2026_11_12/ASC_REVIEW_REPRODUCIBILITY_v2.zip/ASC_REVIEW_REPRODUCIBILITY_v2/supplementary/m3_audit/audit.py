from pathlib import Path
import zipfile,json,csv,hashlib,collections,statistics,math
R=Path(__file__).resolve().parent;ROOT=R.parents[1];archive=ROOT.parent/'upload/M3_RESULTS_RETURN.zip';z=zipfile.ZipFile(archive);prefix='reviewer_response/m3_scale/';read=lambda n:json.loads(z.read(prefix+n));sha=lambda b:hashlib.sha256(b).hexdigest();plan=read('protocol.json');manifest=read('execution_manifest.json');mh=sha(z.read(prefix+'execution_manifest.json'));rows=[];checks=[]
with zipfile.ZipFile(ROOT/'m3_windows/LDL_M3_Windows_Run.zip') as bundle:
 assert sha(bundle.read('LDL_M3_Run/reviewer_response/m3_scale/protocol.json'))==manifest['protocol_sha256']==sha(z.read(prefix+'protocol.json'))
 assert sha(bundle.read('LDL_M3_Run/reviewer_response/m3_scale/run_case.py'))==manifest['runner_sha256']
 for path,h in manifest['sources'].items():assert sha(bundle.read('LDL_M3_Run/'+path))==h
 for c in plan['cases']:
  ds,rep,n=c['dataset'],c['repeat'],c['training_size'];name=f'{ds}_{rep}_n{n}';p='results/'+name+'/';f=read(p+'selection_frozen.json');ev=read(p+'evaluation.json');ref=f['reference_errors'];assert f['execution_manifest_sha256']==ev['execution_manifest_sha256']==mh;assert ev['freeze_sha256']==sha(z.read(prefix+p+'selection_frozen.json'))
  assert len(c['training_indices'])==n and not set(c['training_indices'])&set(c['test_indices']);assert f['training_indices']==c['training_indices'] and f['test_indices']==c['test_indices'];assert len(ref)==n
  by={r['method']:r for r in ev['rows']};assert set(by)=={'Full','GBIP-O1','Mean'}
  for method in ['GBIP-O1','Mean']:
   raw=z.read(prefix+p+method+'.json');a=json.loads(raw);result=a['result'];assert sha(raw)==f['selection_file_sha256'][method+'.json'];assert a['execution_manifest_sha256']==mh;assert result['selected']==f['records'][method]['selected'];assert result['status']=='ok' and result['single_deletion_irreducible'];assert result['candidate_requests']<=len(c['costs'])*(len(c['costs'])+1)//2
   selected=result['selected'];assert len(set(selected))==len(selected);assert sum(c['costs'][i] for i in selected)==result['cost']==by[method]['cost'];assert len(selected)==by[method]['attributes'];assert len(a['independent_neighbors'])==len(selected)
   assert {q['removed'] for q in a['independent_neighbors']}==set(selected)
   assert all((q['violated_objects']>0 if method=='GBIP-O1' else q['mean_error_increase']>1e-12) for q in a['independent_neighbors'])
   if method=='GBIP-O1':assert by[method]['violated_objects']==0 and by[method]['maximum_error_increase']<=1e-12
   else:assert by[method]['mean_training_error']<=by['Full']['mean_training_error']+1e-12
   if n==192:
    base=json.loads(bundle.read(f'LDL_M3_Run/reviewer_response/m3_scale/baseline/{ds}_{rep}.json'));assert ref==base['reference_errors']
    if method=='GBIP-O1':assert selected==base['result']['selected']
   by[method]['candidate_requests']=result['candidate_requests']
  for method,row in by.items():
   assert all(math.isfinite(float(row[k])) for k in ['brier','tv','kl','js','cost_fraction','dependency','coverage']);assert row['cost_fraction']==row['cost']/sum(c['costs']);assert abs(row['dependency']-(1-row['normalized_training_error']))<1e-12
   row.update(reference_dependency=by['Full']['dependency'],reference_coverage=by['Full']['coverage'],brier_delta_vs_full=row['brier']-by['Full']['brier'],evaluation_seconds=ev['seconds'],worker_peak_RSS_GiB=ev['peak_RSS_GiB']);rows.append(row)
  checks.append(dict(case=name,freeze_and_source_hashes_verified=True,train_test_disjoint=True,independent_neighbors_verified=True,baseline192_verified=n==192))
assert len(checks)==33 and len(rows)==99
# Compare aggregate export against authoritative per-case records.
export=list(csv.DictReader(z.read(prefix+'current_results.csv').decode().splitlines()));assert len(export)==99
lookup={(q['dataset'],int(q['repeat']),int(q['training_size']),q['method']):q for q in export}
for q in rows:
 old=lookup[q['dataset'],q['repeat'],q['training_size'],q['method']]
 for k in ['cost','brier','violated_objects']:assert float(old[k])==q[k]
groups=collections.defaultdict(list)
for row in rows:groups[row['dataset'],row['training_size'],row['method']].append(row)
summary=[]
for (ds,n,method),qs in groups.items():
 assert len(qs)==3
 out=dict(dataset=ds,training_size=n,method=method,repeats=3)
 for k in ['cost_fraction','brier','brier_delta_vs_full','coverage','dependency','violated_objects','maximum_error_increase','reference_dependency','reference_coverage']:
  out[k+'_mean']=statistics.mean(q[k] for q in qs);out[k+'_std']=statistics.stdev(q[k] for q in qs)
 out['all_full_cost']=all(q['cost_fraction']==1 for q in qs);summary.append(out)
for name,data in [('all_results.csv',rows),('scale_summary.csv',summary),('case_validation.csv',checks)]:
 fields=list(dict.fromkeys(k for q in data for k in q))
 with (R/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
validation=dict(archive_sha256=sha(archive.read_bytes()),cases=33,evaluations=99,selection_files=66,protocol_matches_delivered_package=True,numerical_runner_matches_delivered_package=True,source_hashes_verified=len(manifest['sources']),all_freeze_hashes_match=True,all_train_test_disjoint=True,baseline192_reference_and_O1_endpoints_exact=9,independent_neighbor_certificates_verified=66,all_O1_objectwise_violations_zero=True,all_Mean_average_constraints_pass=True,aggregate_export_matches_case_records=True,scope='Recorded certificates/hashes and baseline replay verified; no full independent recomputation of all larger-sample oracles.',memory_note='Parent-controller RSS is invalid/near-zero on patched jobs; excluded. Worker-reported peak RSS retained as self-reported measurements only. Runtime can exclude work preceding a resume.')
(R/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation,indent=2))
for q in summary:
 if q['method']=='GBIP-O1':print(q['dataset'],q['training_size'],'O1 cost%',round(q['cost_fraction_mean']*100,3),'Brier delta',q['brier_delta_vs_full_mean'],'refgamma',round(q['reference_dependency_mean'],5))
