# E0.3 coverage-matched development controls

See REPORT.md and records/DECISION.json for all positive and negative results. These nine cases were already consulted in E0.2 and are not independent confirmation. Local-weight ball smoothing did not outperform same-covered mean or random grouping at the fixed settings in any of the six family/budget combinations. Nested training-only selection does not change that scope.

Reproduce with Python 3.12, numpy 2.3.5 and scipy 1.17.0:
`python reproduce.py --data /path/to/verified/cache --output /new/empty/directory`
The launcher verifies six NPY hashes and binds the cache path locally; the recorded source/protocol remain unchanged. Private data arrays must come from the upstream repositories or the owner's authorized private cache. The portable rerun is artifact verification, not new independent evidence.

Private row indices, per-object predictions and raw arrays are excluded from this public package. The all-predictions manifest contains hashes/path labels only.
