"""Recompute the pool envelope and export its scientific figure and summaries."""
from pathlib import Path
from hashlib import sha256
import csv
import json
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("results", type=Path)
OUT = parser.parse_args().results.resolve()
plan = json.loads((OUT / "frontier_plan.json").read_text())
assessment = json.loads((OUT / "endpoint_assessment.json").read_text())
candidates = json.loads((OUT / "candidate_summaries.json").read_text())
assert assessment["complete"] and len(assessment["rows"]) == len(plan["frontier"]) == 6
assert len(candidates) == 2043
rows = assessment["rows"]
for point, result in zip(plan["frontier"], rows):
    assert result["attributes"] == point["attributes"]
    assert result["maximum_increase"] == point["maximum_increase"]
    assert result["digest_reproduced"]
    eligible = [p for p in candidates if p["maximum_increase"] <= point["maximum_increase"]]
    optimum = min(eligible, key=lambda p:(p["attributes"],p["selected"]))
    assert point["selected"] == optimum["selected"]
    assert result["stored_training_bytes"] == 3300*4*point["attributes"]
assert all(a["attributes"]>b["attributes"] for a,b in zip(rows,rows[1:]))
assert all(a["maximum_increase"]<b["maximum_increase"] for a,b in zip(rows,rows[1:]))
base = rows[0]
summary = []
for row in rows:
    ncorrect = row["reference_correct_unique"]
    ntop2 = row["top2_reference_correct"]
    nrank = row["pairwise_rank_eligible_objects"]
    assert ncorrect == base["reference_correct_unique"] and ntop2 == base["top2_reference_correct"]
    summary.append({
        "attributes":row["attributes"],
        "tolerance_knot":row["maximum_increase"],
        "storage_MB":row["stored_training_bytes"]/1e6,
        "storage_saving_percent":100*(1-row["attributes"]/512),
        "reference_top_set_changes":row["reference_top_set_changed"],
        "reference_correct_top1_lost":row["reference_correct_lost"],
        "reference_correct_top1_denominator":ncorrect,
        "reference_correct_top2_lost":row["top2_reference_correct_lost"],
        "reference_correct_top2_denominator":ntop2,
        "pairwise_rank_worse":row["pairwise_rank_worse"],
        "pairwise_rank_denominator":nrank,
        "margin_certified_correct":row["margin_certified_correct"],
        "target_unique_max_denominator":row["target_unique_max_objects"],
        "test_Brier":row["test"]["brier"],
        "top1_wrong_to_correct":row["top1_wrong_to_correct"],
        "top1_reference_tie_to_correct":row["top1_reference_tie_to_correct"],
        "top2_wrong_to_correct":row["top2_wrong_to_correct"],
        "pairwise_rank_better":row["pairwise_rank_better"],
        "mean_training_error":row["mean_training_error"],
    })
with (OUT/"frontier_summary.csv").open("w",encoding="utf-8",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=list(summary[0]))
    writer.writeheader();writer.writerows(summary)
(OUT/"SUMMARY.json").write_text(json.dumps({
    "pool_size":2043,"original_queries":1531,"independent_queries":512,
    "frontier_endpoints":summary,
    "maximum_numeric_comparison_tolerance":1e-12,
    "scope":"Observed candidate-pool envelope. Endpoint choices use reconstruction errors and storage only. Downstream outcomes are descriptive assessments.",
    "first_observed_compression_tolerance":rows[1]["maximum_increase"],
    "frontier_error_vector_digests_reproduced":6,
},indent=2)+"\n")

knots=np.array([r["maximum_increase"] for r in rows])
x=np.r_[knots,.60]
def extended(values):return np.r_[values,values[-1]]
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"svg.fonttype":"none"})
fig,grid=plt.subplots(2,2,figsize=(7.4,5.9))
axes=grid.ravel()
ax=axes[0]
ax.step(x,extended([100*r["attributes"]/512 for r in rows]),where="post",color="#176b87",lw=2)
ax.scatter(knots,[100*r["attributes"]/512 for r in rows],color="#176b87",s=22,zorder=3)
ax.axvspan(0,.48,color="#e8f1f4")
ax.text(.09,45,"Lowest feasible storage\nremains Full\nfor τ ≤ 0.48",fontsize=8)
ax.set(ylabel="Training-feature storage retained (%)",ylim=(-3,105),title="(a) Storage among recorded subsets")
ax=axes[1]
definitions=[
 ("Reference-correct top-1 lost","reference_correct_lost","reference_correct_unique","#b34a37"),
 ("Reference-correct top-2 lost","top2_reference_correct_lost","top2_reference_correct","#735caa"),
 ("Pairwise loss increased","pairwise_rank_worse","pairwise_rank_eligible_objects","#bb8425"),
]
for label,num,den,color in definitions:
    y=[100*r[num]/r[den] if r[den] else np.nan for r in rows]
    ax.step(x,extended(y),where="post",label=label,color=color,lw=1.6)
ax.set(ylabel="Affected eligible occurrences (%)",title="(b) Decisions at selected subsets")
ax.set_ylim(-1, 1.15*max(100*r[num]/r[den] for r in rows for _,num,den,_ in definitions if r[den]))
ax.legend(loc="best",fontsize=7,frameon=False)
ax=axes[2]
y=[r["test"]["brier"] for r in rows]
ax.step(x,extended(y),where="post",color="#307d4c",lw=1.8)
ax.scatter(knots,y,color="#307d4c",s=22)
ax.axhline(y[0],color="#777777",linestyle=":",lw=1)
ax.set(ylabel="Held-out Brier error",title="(c) Held-out distribution prediction")
ax=axes[3]
profile=json.loads((OUT/"margin_certificate_profile.json").read_text())
cx=[point["tolerance"] for point in profile["rows"]]
cy=[100*point["certified"]/profile["unique_target_objects"] for point in profile["rows"]]
ax.step(cx,cy,where="post",color="#42638c",lw=1.8)
ax.scatter(knots,[100*r["margin_certified_correct"]/r["target_unique_max_objects"] for r in rows],color="#42638c",s=22)
ax.set(ylabel="Margin-certified unique maxima (%)",
       title="(d) Certified correct maxima")
for ax in axes:
    ax.set_xlim(-.01,.605);ax.set_xlabel("Allowed maximum error increase τ")
    ax.spines[["top","right"]].set_visible(False);ax.grid(axis="y",alpha=.2)
fig.tight_layout(w_pad=1.2,h_pad=1.6)
fig.savefig(OUT/"tolerance_storage.png",dpi=260,bbox_inches="tight")
fig.savefig(OUT/"tolerance_storage.svg",bbox_inches="tight")
plt.close(fig)
print(json.dumps(summary,indent=2))
