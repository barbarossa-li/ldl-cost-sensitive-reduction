"""Development candidate: remove whole-source weight amplitude, retain feature shape."""
from pathlib import Path
import os,sys,numpy as np
E02=Path(os.environ.get('AI_LDL_E02','/workspace/work/ai_e02_20261113'));sys.path.insert(0,str(E02))
from calibrated import CalibratedPrototypeModel

def normalize_rows(W):
 W=np.asarray(W,float)
 if W.ndim!=2 or not W.shape[1] or not np.isfinite(W).all() or np.any(W<0):raise ValueError('Finite nonnegative weight matrix required')
 mass=W.mean(1);N=np.ones_like(W);np.divide(W,mass[:,None],out=N,where=mass[:,None]>0)
 return N

class ShapeWeightedModel(CalibratedPrototypeModel):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);self.N=normalize_rows(self.W);self.N.setflags(write=False)
 def weights(self,mode,permutation=None):
  if mode=='N':return self.N
  if mode=='T':
   super().weights('S',permutation);return self.N[np.asarray(permutation)]
  return super().weights(mode,permutation)
