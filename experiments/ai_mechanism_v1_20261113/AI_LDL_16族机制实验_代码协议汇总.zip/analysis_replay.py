"""Recompute primary family summaries from public aggregate rows only."""
from pathlib import Path
import argparse,json,csv,statistics as st,math
ap=argparse.ArgumentParser();ap.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();B=a.bundle;data=json.loads((B/'AGGREGATE_RESULTS_PUBLIC.json').read_text());rows=data['rows'];lookup={(r['family'],r['repeat'],r['mask'],r['weight'],r['target']):r for r in rows};assert len(lookup)==len(rows)==12560
reference={r['family']:r for r in csv.DictReader(open(B/'family_summary.csv'))};families=[]
for family,ref in reference.items():
 keys=[k for k in lookup if k[0]==family and k[3:] ==('L','raw') and k[2]!='Full'];assert len(keys)==60;vals={k:[] for k in ['geometry','grouping','grouping_random','grouping_global','ball_raw','interaction']}
 for name,r,m,_,_ in keys:
  b=lambda w,t:lookup[(name,r,m,w,t)]['brier'];vals['geometry'].append(b('L','raw')-b('U','raw'));vals['grouping'].append(b('L','ball')-b('L','covered_mean'));vals['grouping_random'].append(b('L','ball')-b('L','random'));vals['grouping_global'].append(b('L','ball')-b('L','global_mean'));vals['ball_raw'].append(b('L','ball')-b('L','raw'));vals['interaction'].append((b('L','ball')-b('U','ball'))-(b('L','raw')-b('U','raw')))
 families.append({'family':family,**{k:st.mean(v) for k,v in vals.items()}})
maximum=max(abs(r[k]-float(reference[r['family']][k])) for r in families for k in r if k!='family');assert maximum<1e-15
summary=json.loads((B/'SUMMARY.json').read_text())
for k in summary['contrasts']:
 v=[r[k] for r in families];assert abs(st.mean(v)-summary['contrasts'][k]['equal_family_mean'])<1e-15;assert sum(x<0 for x in v)==summary['contrasts'][k]['families_negative']
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps({'passed':True,'family_contrast_values':96,'maximum_absolute_difference':maximum,'family_aggregation_and_sign_counts_match':True,'scope':'Public aggregate analysis replay, not another model run or independent dataset'},indent=2));print(a.output.read_text())
