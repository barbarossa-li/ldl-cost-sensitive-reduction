from pathlib import Path
import json,numpy as np
from scipy.spatial.distance import cdist
from budget import bisection_path,lloyd,random_matched,distance_to_centroids

def checks():
 rng=np.random.default_rng(6);X=rng.normal(size=(24,5));L=rng.dirichlet(np.ones(3),24);D=cdist(X,X,'sqeuclidean');ks=[1,6,12,18,24]
 for mix in [0.,.5]:
  path=bisection_path(D,L,ks,mix)
  for k,groups in path.items():
   assert len(groups)==k and sorted(i for B in groups for i in B)==list(range(24));null=random_matched(groups,24,9);assert sorted(map(len,groups))==sorted(map(len,null))
  assert path[24]==[(i,) for i in range(24)]
  for low,high in zip(ks,ks[1:]):assert all(any(set(B)<=set(C) for C in path[low]) for B in path[high])
  assert path==bisection_path(D,L,ks,mix)
 for k in ks:
  groups=lloyd(D,k);direct=cdist(X,np.array([X[list(B)].mean(0) for B in groups]),'sqeuclidean');assert np.allclose(distance_to_centroids(D,groups),direct,atol=1e-12);assert len(groups)==k
 for n in [1,3,10]:
  Dz=np.zeros((n,n));labels=np.tile([.5,.5],(n,1))
  for k in range(1,n+1):assert len(lloyd(Dz,k))==k and len(bisection_path(Dz,labels,[k])[k])==k
 # Geometry-only priority is invariant to arbitrary replacement of training labels.
 assert bisection_path(D,L,ks,0)==bisection_path(D,rng.dirichlet(np.ones(3),24),ks,0)
 # A supervised priority must be able to change leaf choice with identical feature split rules.
 changed=any(bisection_path(D,L,[4,8],.5)!=bisection_path(D,rng.dirichlet(np.ones(3),24),[4,8],.5) for _ in range(10));assert changed
 out={'passed':True,'checks':['exact nonempty budgets and full partition','nested bisection path','deterministic seed/tie rules','random group-size histogram matching','singleton Full endpoint','Lloyd centroid-distance identity vs direct Euclidean','constant-feature/one-object cases','geometry-only label invariance','label priority can change leaf choice']};Path(__file__).with_name('CHECKS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
if __name__=='__main__':checks()
