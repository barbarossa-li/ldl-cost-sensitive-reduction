# Full official-image O1 reselection

This packet records a fresh complete-sweep GBIP-O1 search on all 3,300 official training images / 512 ResNet-18 coordinates. Read records/FINAL_RESULTS.json for completed results; absence means the run is incomplete. Existing official test outcomes were already known: this is reproduction/exploratory evidence, not untouched-test confirmation or subject-disjoint evaluation.

The implementation preserves ordered float64 accumulation and the anchored granulator. It replaces full pair sorting by an exact top-budget ordering. Validation covers small subsets, tie-heavy pair arrays and exact full 3,300-object distances/error vectors. No reassociated approximate distance sum is used. Original code is in the earlier additional-experiment packet's frozen_core directory.

## Reproduce using the private cache

1. Obtain the prior additional-experiment packet and its frozen_core directory from this repository. Obtain authorized official-image inputs using datasets/SCUT_FBP5500 instructions; check the private Drive cache first. The private image-replay cache contains data/official_resnet18_features.npy and data/official_labels_split.npz. The private full-selection cache contains fitted.npz and the actual SQLite error vectors. Original images, labels, features and individual vectors are not embedded in this public packet.
2. `pip install -r requirements.txt`. Install a C++ compiler with OpenMP support.
3. `python reproduce.py --core /path/to/frozen_core --image-cache /path/to/extracted/image-replay-cache --fit-cache /path/to/extracted/selection-cache --output /new/empty/run --run`

The adapter preserves recorded source and changes only local path bindings in a new run. A newly compiled binary has a new SHA and a new protocol; original-source/protocol hashes remain in records. It validates Full against the cached reference, stores every actual query error vector and resumes deterministically from its own SQLite cache. Fit reuse excludes the separately recorded original fitting time from new selection timings. To reconstruct fitting from scratch instead, use the preserved pilot source with the same local bindings; this costs extra computation and requires no new download if cached image features are available.

## Scope

Unit costs measure retained coordinates/storage, not lower image feature-extraction cost. The search establishes its specified endpoint and single-deletion irreducibility; it does not prove a global minimum. Owner IDs in the official sources workbook cover only 99 images and are not a verified complete depicted-subject map. Rating volunteer IDs do not identify image subjects. Do not claim subject-disjoint generalization.

Raw inputs, fitted arrays, individual error vectors, weights and test predictions stay in the private Drive cache. Public records are aggregate results, trace, hash identities and protocols. Cache digests identify artifacts without granting redistribution rights.
