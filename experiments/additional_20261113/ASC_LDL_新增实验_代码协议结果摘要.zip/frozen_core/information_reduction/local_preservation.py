"""Objectwise training-representation criteria; independent of prediction losses."""
import numpy as np


def assess(errors, reference_errors, global_variation, atol=1e-12):
    e, r = np.asarray(errors, float), np.asarray(reference_errors, float)
    if e.ndim != 1 or e.shape != r.shape or not len(e):
        raise ValueError('Nonempty matching objectwise error vectors required')
    if not np.isfinite(e).all() or not np.isfinite(r).all() or (e < 0).any() or (r < 0).any():
        raise ValueError('Errors must be finite and nonnegative')
    if not np.isfinite(global_variation) or global_variation < 0 or not np.isfinite(atol) or atol < 0:
        raise ValueError('Invalid variation or numerical tolerance')
    excess = np.maximum(e-r, 0)
    return dict(objectwise_preserved=bool(np.all(excess <= atol)),
                violated_objects=int(np.sum(excess > atol)),
                maximum_error_increase=float(excess.max()),
                mean_positive_error_increase=float(excess.mean()),
                aggregate_error_increase=float(np.mean(e-r)),
                reference_explained_fraction=(float(1-r.mean()/global_variation)
                                             if global_variation > 0 else None),
                numerical_tolerance=atol)
