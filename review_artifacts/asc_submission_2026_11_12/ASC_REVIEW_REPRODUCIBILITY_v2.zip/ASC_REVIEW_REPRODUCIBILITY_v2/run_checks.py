from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile,shutil
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--figures',action='store_true');args=parser.parse_args()
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
out=ROOT/'verification_outputs';out.mkdir(exist_ok=True)
checks=[('independent_joint_search',['supplementary/independent_joint_search/audit.py']),('recorded_timing',['supplementary/end_to_end/audit.py']),('recorded_envelope',['supplementary/tolerance_envelope/audit.py']),('object_decisions',['supplementary/m1_effects/check_decision_coverage.py']),('family_statistics',['supplementary/m7/run_m7.py','supplementary/all_results.csv','recomputed_statistics'])]
if args.figures:checks.append(('figures',['supplementary/presentation/redraw_figures.py']))
results=[]
with tempfile.TemporaryDirectory(prefix='asc-v2-') as tmp:
 work=Path(tmp)/'inputs';shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('verification_outputs','__pycache__'))
 (work/'paper_figures').mkdir(exist_ok=True);(work/'recomputed_statistics').mkdir()
 for name,command in checks:
  p=subprocess.run([sys.executable,*command],cwd=work,text=True,capture_output=True)
  (out/(name+'.log')).write_text(p.stdout+p.stderr)
  ok=p.returncode==0
  if ok and name=='family_statistics':
   ok=json.loads((work/'recomputed_statistics/summary.json').read_text())==json.loads((work/'supplementary/m7/summary.json').read_text())
  if ok and name=='object_decisions':
   ok=json.loads(p.stdout)==json.loads((work/'supplementary/m1_effects/decision_coverage.json').read_text())
  results.append({'check':name,'passed':ok});print(name,'PASS' if ok else 'FAIL',flush=True)
 if args.figures:
  figures=out/'figures';figures.mkdir(exist_ok=True)
  for p in [*work.glob('*.png'),*(work/'paper_figures').glob('*')]:shutil.copy2(p,figures/p.name)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(0 if all(r['passed'] for r in results) else 1)
