from pathlib import Path
import json,sys,numpy as np
import run
R=Path(__file__).resolve().parent;p=run.verify();f=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(f['records'])==48
for name,h in p['input_hashes'].items():assert run.sha(name)==h
arrays=0;endpoints=0
for name,h in f['records'].items():
 q=R/name;assert run.sha(q)==h;c=json.loads(q.read_text());assert run.sha(q.parent/'predictions_PRIVATE.npz')==c['predictions_sha256'];s=json.loads((run.PRIVATE/c['family']/'repeat_1/split_PRIVATE.json').read_text());assert set(c['fit_indices']).isdisjoint(c['validation_indices']) and not(set(c['fit_indices'])|set(c['validation_indices']))&set(s['test_indices']);a=np.load(q.parent/'predictions_PRIVATE.npz');assert len(a.files)==265
 for key in a.files:
  v=a[key];assert np.isfinite(v).all() and (v>=0).all() and np.allclose(v.sum(-1),1,rtol=0,atol=2e-12);arrays+=1
  parts=key.split('__')
  if len(parts)==6 and parts[2]=='K100':
   ref=a[parts[0]+'__'+parts[1]+'__'+('raw0' if parts[-1]=='a0.0' else 'rawhalf')];vs=list(v) if v.ndim==3 else [v]
   for x in vs:assert np.array_equal(x,ref);endpoints+=1
 for t in c['statistics']:
  groups=t['groups'];assert len(groups)==t['K'] and all(len(B)>0 for B in groups) and sorted(i for B in groups for i in B)==list(range(c['n_fit']));assert t['K']==max(1,t['budget_percent']*c['n_fit']//100)
run.save(R/'PREDICTION_AUDIT.json',{'passed':True,'cases':48,'prediction_arrays':arrays,'exact_full_budget_endpoint_checks':endpoints,'all_input_hashes_reverified':True,'new_outer_test_scored':False});print('Prediction audit PASS',arrays,endpoints)
if len(sys.argv)>1 and sys.argv[1]=='metrics':
 d=json.loads((R/'RESULTS.json').read_text());lookup={(r['family'],r['fold'],r['mask'],r['geometry'],r['budget_percent'],r['method'],r['vote'],r['alpha']):r['brier'] for r in d['rows']};maximum=0;count=0
 for name in f['records']:
  q=R/name;c=json.loads(q.read_text());a=np.load(q.parent/'predictions_PRIVATE.npz');y=np.load(run.D/f"{c['family']}_L.npy",mmap_mode='r')[c['validation_indices']]
  for key in a.files:
   v=a[key];values=list(v) if v.ndim==3 else [v];loss=np.mean([np.einsum('ij,ij->i',x-y,x-y).mean() for x in values]);parts=key.split('__')
   if len(parts)==6:mask,g,k,method,vote,alpha=parts;pct=int(k[1:]);alpha=float(alpha[1:])
   elif len(parts)==3:mask,g,method=parts;pct=100;vote='NA';alpha=0. if method=='raw0' else .5
   else:mask,g,method,pct,vote,alpha='NA','NA','plain_mean',0,'NA',1.
   diff=abs(loss-lookup[(c['family'],c['fold'],mask,g,pct,method,vote,alpha)]);assert diff<1e-12;maximum=max(maximum,diff);count+=1
 run.save(R/'METRIC_AUDIT.json',{'passed':True,'values_compared':count,'maximum_absolute_difference':maximum,'scope':'Development artifact verification'});print('Metric audit PASS',count,maximum)
