"""All predeclared matched-setting contrasts, without selecting a best point."""
import json,itertools,argparse
from pathlib import Path
import numpy as np

def summarize(run):
 result=json.loads((run/'RESULTS_PUBLIC.json').read_text());rows=result['family_summary'];families=sorted({r['family'] for r in rows});lookup={(r['family'],r['key']):r for r in rows}
 contrasts=[]
 def compare(kind,left,right,setting):
  delta=[lookup[f,left]['brier']-lookup[f,right]['brier'] for f in families]
  contrasts.append(dict(kind=kind,setting=setting,left=left,right=right,mean_brier_difference=float(np.mean(delta)),wins=sum(d < -1e-12 for d in delta),ties=sum(abs(d)<=1e-12 for d in delta),losses=sum(d>1e-12 for d in delta),family_differences=dict(zip(families,delta))))
 for mask,g,b,r,a in itertools.product(['Full','cost40'],['U','G'],['K5','25','50','75','100'],['nn5','allp5'],['0.0','0.5']):
  for m in ['kmeanspp','bisecting','paper20']:
   compare('constructor',f'{mask}__{g}__{m}__{b}__{r}__a{a}',f'{mask}__{g}__geometric__{b}__{r}__a{a}',dict(mask=mask,geometry=g,budget=b,readout=r,alpha=a))
 for mask,m,b,r,a in itertools.product(['Full','cost40'],['geometric','kmeanspp','bisecting','paper20'],['K5','25','50','75','100'],['nn5','allp5'],['0.0','0.5']):
  compare('geometry',f'{mask}__G__{m}__{b}__{r}__a{a}',f'{mask}__U__{m}__{b}__{r}__a{a}',dict(mask=mask,constructor=m,budget=b,readout=r,alpha=a))
 for mask,g,m,b,a in itertools.product(['Full','cost40'],['U','G'],['geometric','kmeanspp','bisecting','paper20'],['K5','25','50','75','100'],['0.0','0.5']):
  compare('readout',f'{mask}__{g}__{m}__{b}__allp5__a{a}',f'{mask}__{g}__{m}__{b}__nn5__a{a}',dict(mask=mask,geometry=g,constructor=m,budget=b,alpha=a))
 for mask,g,m,b,r in itertools.product(['Full','cost40'],['U','G'],['geometric','kmeanspp','bisecting','paper20'],['K5','25','50','75','100'],['nn5','allp5']):
  compare('prior',f'{mask}__{g}__{m}__{b}__{r}__a0.5',f'{mask}__{g}__{m}__{b}__{r}__a0.0',dict(mask=mask,geometry=g,constructor=m,budget=b,readout=r))
 return dict(families=families,family_weighting='equal across16 families; within family pool heldout object losses',difference_direction='left minus right; negative favors left',tie_tolerance=1e-12,contrasts=contrasts,readout_caution='NN5 vs ALLP5 changes distance, neighborhood scope and aggregation jointly; same K is not same numeric bytes across readouts',scope=result['scope'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);a=p.parse_args();print(json.dumps(summarize(a.run),indent=2))
