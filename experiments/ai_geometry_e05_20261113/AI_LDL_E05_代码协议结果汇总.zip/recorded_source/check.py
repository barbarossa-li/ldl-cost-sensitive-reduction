from pathlib import Path
import os,sys,json,numpy as np
sys.path.insert(0,os.environ.get('AI_LDL_E02','/workspace/work/ai_e02_20261113'))
from calibrated import CalibratedPrototypeModel
from prototype import PrototypePredictor,groups_from_representation

def checks():
 rng=np.random.default_rng(5);X=rng.normal(size=(12,4));L=rng.dirichlet(np.ones(3),12);Q=rng.normal(size=(7,4));m=CalibratedPrototypeModel(X,L,zeta=.5);P=(0,2)
 for mode in ['U','G']:
  raw=PrototypePredictor(m,P,mode);assert np.array_equal(raw.distances(Q[:,P]),m.incoming_selected(Q[:,P],P,mode));assert np.array_equal(raw.predict(Q[:,P]),m.predict_selected(Q[:,P],P,mode,readout='raw'));assert np.array_equal(raw.predict(Q[:,P]),raw.predict(Q[:,P],True))
  assert np.array_equal(raw.predict(Q[:,P]),np.concatenate([raw.predict(q[None,P]) for q in Q]));state=raw.state();clone=PrototypePredictor.from_state(state);assert np.array_equal(clone.predict(Q[:,P]),raw.predict(Q[:,P]))
 rep={'accepted':[(1,3,4),(6,8)],'covered':np.array([False,True,False,True,True,False,True,False,True,False,False,False])};groups,flags=groups_from_representation(m,rep);random,rflags=groups_from_representation(m,rep,19)
 assert list(map(len,groups))==list(map(len,random));assert np.array_equal(flags,rflags);assert {i for B,f in zip(groups,flags) if f for i in B}=={i for B,f in zip(random,rflags) if f for i in B};assert [B for B,f in zip(groups,flags) if not f]==[B for B,f in zip(random,rflags) if not f]
 ball=PrototypePredictor(m,P,'G',groups,flags);null=PrototypePredictor(m,P,'G',random,rflags);assert ball.array_bytes()==null.array_bytes();assert len(ball.labels)==9
 for mass in [False,True]:assert np.allclose(ball.predict(Q[:,P],mass).sum(1),1)
 # One compressed prototype exercises min(k,slots) and centroid/mean construction.
 single=PrototypePredictor(m,P,'G',[tuple(range(12))],np.array([True]));assert np.allclose(single.predict(Q[:,P]),np.tile(L.mean(0),(7,1)))
 # Standalone state remains usable after the source model is discarded.
 expected=ball.predict(Q[:,P]);del m;assert np.array_equal(PrototypePredictor.from_state(ball.state()).predict(Q[:,P]),expected)
 zero=CalibratedPrototypeModel(np.zeros((8,2)),np.tile([.2,.8],(8,1)),zeta=.5);p=PrototypePredictor(zero,(0,1),'G');assert np.array_equal(p.distances(np.zeros((3,2))),np.zeros((3,8)))
 out={'passed':True,'checks':['singleton distances/raw predictions exact U/G','stable source tie order','batch and selected-only interface','source-free state replay','same-covered random exact group sizes/residuals/slot order','matched prediction-array bytes','probability simplex','one-prototype min-k fallback','constant-feature zero-information fallback']};Path(__file__).with_name('CHECKS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
if __name__=='__main__':checks()
