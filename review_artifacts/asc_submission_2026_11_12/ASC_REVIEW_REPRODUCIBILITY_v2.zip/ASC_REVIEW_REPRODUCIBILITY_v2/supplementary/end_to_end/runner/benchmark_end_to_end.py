"""Time the frozen SCUT-FBP5500 query pipeline on the original test images."""
import argparse
from contextlib import ExitStack
import hashlib
from io import BytesIO
import json
from pathlib import Path
import platform
import sys
from time import perf_counter
from zipfile import ZipFile

from run_joint_search import sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_run", type=Path)
    parser.add_argument("original_return", type=Path)
    parser.add_argument("images", type=Path, help="Original ZIP or directory containing the extracted JPEGs.")
    parser.add_argument("output", type=Path)
    parser.add_argument("--check-images", action="store_true", help="Verify original image hashes only.")
    args = parser.parse_args()
    root = args.original_run.resolve()
    plan = json.loads(Path(__file__).with_name("JOINT_SEARCH_PROTOCOL.json").read_text(encoding="utf-8"))
    protocol = root / "protocol.json"
    if sha(protocol) != plan["original_protocol_sha256"] or sha(args.original_return) != plan["archive_sha256"]:
        raise ValueError("Wrong original protocol or return archive")
    sys.path.insert(0, str(root))
    import run_application as app
    import numpy as np

    app.identity(json.loads(protocol.read_text(encoding="utf-8")))
    with np.load(root / "data/LABELS60_AND_SPLIT.npz", allow_pickle=False) as data:
        train, test, labels = (data[key] for key in ("train_indices", "test_indices", "labels60"))
    assert len(test) == 2200
    manifest = json.loads((root / "data/IMAGE_MANIFEST.json").read_text(encoding="utf-8"))
    images = [manifest[int(i)] for i in test]
    assert [row["row"] for row in images] == test.tolist()
    with ExitStack() as stack:
        if args.images.is_dir():
            def read(row):
                return (args.images / row["filename"]).read_bytes()
        else:
            image_zip = stack.enter_context(ZipFile(args.images))

            def read(row):
                return image_zip.read(row["archive_member"])

        for row in images:
            if hashlib.sha256(read(row)).hexdigest() != row["sha256"]:
                raise ValueError(f"Image bytes differ from the frozen manifest: {row['filename']}")
        print("Verified 2200 original test images.", flush=True)
        if args.check_images:
            return

        from PIL import Image
        import torch
        import torchvision
        from torchvision.models import resnet18, ResNet18_Weights

        extract = json.loads((root / "data/EXTRACTION_IDENTITY.json").read_text(encoding="utf-8"))
        torch.set_num_threads(extract["torch_threads"])
        weights = ResNet18_Weights.IMAGENET1K_V1
        model = resnet18(weights=weights).eval()
        weight_file = Path(torch.hub.get_dir()) / "checkpoints" / weights.url.rsplit("/", 1)[1]
        if sha(weight_file) != extract["weights_sha256"]:
            raise ValueError("ResNet-18 weights differ from the frozen extractor")
        model.fc = torch.nn.Identity()
        transform = weights.transforms()
        batch_size = extract["batch_size"]
        x = np.load(root / "data/RESNET18_FEATURES.npy", allow_pickle=False)
        with ZipFile(args.original_return) as archive:
            frozen = json.loads(archive.read("results/selection_frozen.json"))
            methods = ("Full", "Mean")
            selected = {method: frozen["records"][method]["selected"] for method in methods}
            saved = {
                method: np.load(BytesIO(archive.read(f"results/{method}_test_predictions.npy")), allow_pickle=False)
                for method in methods
            }
        assert len(selected["Full"]) == 512 and len(selected["Mean"]) == 51
        train_features, train_labels = x[train], labels[train]
        results = {method: [] for method in methods}
        with torch.inference_mode():
            for repeat in range(9):
                for method in methods[::(-1 if repeat % 2 else 1)]:
                    decode_time = cnn_time = 0.0
                    batches = []
                    total_start = perf_counter()
                    for start in range(0, len(images), batch_size):
                        t0 = perf_counter()
                        decoded = []
                        for row in images[start:start + batch_size]:
                            with Image.open(BytesIO(read(row))) as image:
                                decoded.append(image.convert("RGB"))
                        t1 = perf_counter()
                        batches.append(model(torch.stack([transform(image) for image in decoded])).numpy())
                        t2 = perf_counter()
                        decode_time += t1 - t0
                        cnn_time += t2 - t1
                    query = np.concatenate(batches)
                    t3 = perf_counter()
                    prediction = app.predict_five_neighbors(train_features, train_labels, query, selected[method])
                    finished = perf_counter()
                    if repeat >= 2:
                        results[method].append({
                            "image_read_decode_seconds": decode_time,
                            "transform_resnet18_seconds": cnn_time,
                            "backend_seconds": finished - t3,
                            "end_to_end_seconds": finished - total_start,
                            "feature_max_abs_diff": float(np.max(np.abs(query - x[test]))),
                            "prediction_max_abs_diff": float(np.max(np.abs(prediction - saved[method]))),
                        })
                    print(method, "round", repeat + 1, "seconds", round(finished - total_start, 3), flush=True)
        summary = {method: {
            key: float(np.median([row[key] for row in rows])) for key in rows[0]
        } for method, rows in results.items()}
        reduction = 1 - summary["Mean"]["end_to_end_seconds"] / summary["Full"]["end_to_end_seconds"]
        args.output.parent.mkdir(parents=True, exist_ok=True)
        app.save(args.output, {
            "protocol_sha256": plan["original_protocol_sha256"],
            "host": platform.platform(), "cpu": platform.processor(),
            "torch": torch.__version__, "torchvision": torchvision.__version__,
            "torch_threads": extract["torch_threads"], "batch_size": batch_size,
            "warmups": 2, "repetitions": 7, "summary_medians": summary,
            "end_to_end_fraction_reduction": reduction, "trials": results,
        })


if __name__ == "__main__":
    main()
