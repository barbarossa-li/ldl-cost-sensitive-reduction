"""Prospective geometry diagnostics and original-data replay; frozen selection first."""
from pathlib import Path
import os
for name in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[name]='1'
import argparse,csv,datetime,hashlib,json,platform,resource,sqlite3,subprocess,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parent
CODE=Path('/workspace/work/asc_review/code_bundle')
sys.path.insert(0,str(CODE))
from granulation_reference import TrainingGeometry
from information_reduction.safe_extension import granulate
from information_reduction.formal_method import reduce_from_full
SPLITS=CODE/'expansion25/splits'
DATASETS=['Yeast_cold','SCUT_FBP','Human_Gene']
VARIANTS=['full_max','pair_mean','raw']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(p)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def protocol():
    return json.loads((ROOT/'PROTOCOL.json').read_text())
def verify():
    p=protocol()
    for f,h in p['source_hashes'].items():assert sha(Path(f))==h,('code changed',f)
    for f,h in p['input_hashes'].items():assert sha(Path(f))==h,('input changed',f)
    return p

def prepare():
    files=[Path(__file__),CODE/'granulation_reference.py',CODE/'information_reduction/safe_extension.py',CODE/'information_reduction/alternative_seeds.py',CODE/'information_reduction/formal_method.py',CODE/'information_reduction/sweep_search.py',CODE/'information_reduction/local_preservation.py',CODE/'stability/fast_granulate.py',CODE/'baseline_revision/prediction_evaluation.py']
    inputs=[ROOT/'input_verification.json']
    for d in DATASETS:
        inputs += [ROOT/'data'/f'{d}_X.npy',ROOT/'data'/f'{d}_L.npy']
        inputs += [SPLITS/d/f'repeat_{r}.json' for r in [1,2,3]]
    value=dict(version='ASC-additional-20261113-v1',frozen_at=stamp(),scope='New exploratory ablations on known benchmark splits, plus actual original-data replay; not independent confirmatory data',datasets=DATASETS,repeats=[1,2,3],n=192,variants=VARIANTS,
       geometry_definitions={'full_max':'Unchanged TrainingGeometry.subset(P): max(rho_ij,rho_ji)','pair_mean':'Same fitted local W and per-feature discrepancies: (rho_ij+rho_ji)/2; removes source-dependent pair imbalance by reciprocal averaging','raw':'Sum of original label-independent per-attribute geometric terms, fixed full m'},
       interpretation='Nested contrast, not a 2x2 factorial. Full-to-pair-mean changes source-weight symmetrization; pair-mean-to-raw removes weighting. All ball inputs are symmetric. Cannot claim pure asymmetry causal effects apart from their associated geometry.',
       representation=dict(beta=1,zeta=.1,smin=2,kappa=.1,alpha=1,eps_v=0,eps_r=0,pair_budget=256,epsilon_safe=1e-12,epsilon_rec=1e-12,bandwidth='Frozen median-positive-pairwise rule'),
       search='Unchanged complete-sweep cost-descending reduction from Full with own fixed per-object reference for each geometry and exact zero-reference status. All modes use same costs/splits; no result-based tuning.',
       evaluation='All 27 selection records frozen and hashed before test-label scoring. Fixed min-max stable 5NN. Cross-score each selected subset against all three fixed-reference geometries. Compare full_max endpoints and raw reconstructed errors to old records only after selection freeze.',
       resources='Each run in a fresh isolated Python process, sequential jobs, BLAS one thread. Fit and deletion-search wall/CPU seconds; process peak RSS before endpoint checks; imports and training input residency included. Error-vector recording buffer included; SQLite export and independent endpoint checks excluded from selection timings. No claim of cross-hardware latency reproducibility.',
       records='Save every distinct queried subset and actual float64 error vector in per-run SQLite; retain source, input, split and protocol hashes. Repeated vectors must match exactly. Independent fresh-oracle final-neighbor checks.',
       outcomes=['retained cost/cardinality','own and cross-reference objectwise violation counts','held-out Brier/TV/KL/JS','training fit and search wall/CPU time','peak process RSS','reference/final error hashes','full_max replay agreement'],
       analysis='Report every task/repeat/mode, failures included; descriptive contrasts only across three feature families. Do not treat nine overlapping repeats as nine independent tasks. Do not select protocols with test outcomes.',
       excluded=['Image inference/official 3300-object pipeline unless original inputs and identity manifests are located','Subject-disjoint evaluation without verified row-to-subject metadata','Full 25-task baseline parameter-grid rerun'],
       source_hashes={str(p):sha(p) for p in files},input_hashes={str(p):sha(p) for p in inputs})
    path=ROOT/'PROTOCOL.json'
    if path.exists():
        old=json.loads(path.read_text());value['frozen_at']=old['frozen_at'];assert value==old
    else:save(path,value)
    print('FROZEN',sha(path),value['frozen_at'],flush=True)

class Oracle:
    def __init__(self,X,L,variant,record=True):
        self.X=X;self.L=L;self.variant=variant;self.p=L.mean(0);self.record=record;self.records={};self.calls=0
        self.model=TrainingGeometry(X,L,kinds=['numerical']*X.shape[1])
    def __call__(self,P):
        P=tuple(sorted(P));self.calls+=1
        if self.variant=='full_max':D,keys=self.model.subset(P)
        else:
            keys=[tuple(row[list(P)]) for row in self.model.X]
            if self.variant=='pair_mean':
                f=self.model.directed(P);D=.5*(f+f.T)
            elif self.variant=='raw':
                D=np.zeros((len(self.L),len(self.L)))
                for a in P:D+=self.model.geometry[a]
            else:raise ValueError(self.variant)
        _,eligible,_,_,audit=granulate(D,self.L,keys)
        rec=np.tile(self.p,(len(self.L),1))
        for B in eligible:rec[B]=self.L[B].mean(0)
        error=np.sum((self.L-rec)**2,axis=1)
        if self.record:
            if P in self.records:assert np.array_equal(error,self.records[P]),('nondeterministic oracle',P)
            else:self.records[P]=error.copy()
        return error

def destination(d,r,v):return ROOT/'results'/d/f'repeat_{r}'/v

def train(d,r,v):
    protocol_record=verify();out=destination(d,r,v);out.mkdir(parents=True,exist_ok=True)
    done=out/'selection.json'
    if done.exists():assert json.loads(done.read_text())['protocol_sha256']==sha(ROOT/'PROTOCOL.json');print('REUSE',d,r,v,flush=True);return
    split=json.loads((SPLITS/d/f'repeat_{r}.json').read_text());idx=split['train_indices']
    # Only training indices are dereferenced before the global selection freeze.
    X=np.asarray(np.load(ROOT/'data'/f'{d}_X.npy',mmap_mode='r')[idx],float)
    L=np.asarray(np.load(ROOT/'data'/f'{d}_L.npy',mmap_mode='r')[idx],float)
    v0=float(np.mean(np.sum((L-L.mean(0))**2,axis=1)))
    print('START',d,r,v,stamp(),flush=True)
    w=time.perf_counter();c=time.process_time();oracle=Oracle(X,L,v)
    fit_wall=time.perf_counter()-w;fit_cpu=time.process_time()-c
    w=time.perf_counter();c=time.process_time();res=reduce_from_full(split['costs'],oracle,v0)
    search_wall=time.perf_counter()-w;search_cpu=time.process_time()-c
    peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    selection_calls=oracle.calls;selection_unique=len(oracle.records)
    full=tuple(range(X.shape[1]));reference=oracle.records[full].copy();selected=res['selected']
    validation=[];final=None
    # Rebuild endpoints and neighbors without the search's verdict caches.
    if selected is not None:
        final=oracle(selected);assert np.all(final<=reference+1e-12)
        assert res.get('single_deletion_irreducible',not selected)
        for a in selected:
            error=oracle([b for b in selected if b!=a]);n=int(np.sum(error>reference+1e-12));assert n>0
            validation.append({'removed':a,'violated_objects':n,'maximum_error_increase':float(np.max(error-reference))})
    # Export loss vectors after the measured training phases.
    db=sqlite3.connect(out/'errors.sqlite');db.execute('create table if not exists vectors (subset text primary key, n integer, dtype text, sha256 text, errors blob)')
    for P,e in oracle.records.items():
        b=e.astype('<f8').tobytes();db.execute('insert or replace into vectors values (?,?,?,?,?)',(json.dumps(P,separators=(',',':')),len(e),'<f8',hashlib.sha256(b).hexdigest(),b))
    db.commit();db.close()
    np.savez_compressed(out/'endpoint_errors.npz',reference=reference,final=final if final is not None else np.empty(0))
    result=dict(dataset=d,repeat=r,variant=v,protocol_sha256=sha(ROOT/'PROTOCOL.json'),split_sha256=sha(SPLITS/d/f'repeat_{r}.json'),training_arrays_sha256=hashlib.sha256(X.tobytes()+L.tobytes()).hexdigest(),result=res,
       full_cost=sum(split['costs']),retained_cost_percent=None if selected is None else 100*sum(split['costs'][a] for a in selected)/sum(split['costs']),
       fit_wall_seconds=fit_wall,fit_cpu_seconds=fit_cpu,search_wall_seconds=search_wall,search_cpu_seconds=search_cpu,training_peak_rss_bytes=peak_rss_bytes,
       selection_oracle_calls=selection_calls,selection_unique_subsets=selection_unique,recorded_subsets_including_verification=len(oracle.records),
       reference_mean_error=float(reference.mean()),final_mean_error=None if final is None else float(final.mean()),
       reference_errors_sha256=hashlib.sha256(reference.astype('<f8').tobytes()).hexdigest(),final_errors_sha256=None if final is None else hashlib.sha256(final.astype('<f8').tobytes()).hexdigest(),
       independent_neighbor_checks=validation,errors_database_sha256=sha(out/'errors.sqlite'),endpoint_file_sha256=sha(out/'endpoint_errors.npz'),finished_at=stamp())
    save(done,result)
    print('DONE',d,r,v,'cost%',result['retained_cost_percent'],'search_s',round(search_wall,3),'rss_MB',round(peak_rss_bytes/1e6,2),flush=True)

def run_all():
    verify();begin=stamp();print('ALL BEGIN',begin,flush=True)
    for d in DATASETS:
        for r in [1,2,3]:
            for v in VARIANTS:subprocess.run([sys.executable,str(Path(__file__).resolve()),'train',d,str(r),v],check=True)
    paths=[destination(d,r,v)/'selection.json' for d in DATASETS for r in [1,2,3] for v in VARIANTS]
    frozen={'protocol_sha256':sha(ROOT/'PROTOCOL.json'),'selections':{str(p.relative_to(ROOT)):sha(p) for p in paths},'frozen_at':stamp(),'started_at':begin}
    save(ROOT/'ALL_SELECTIONS_FROZEN.json',frozen);print('ALL 27 SELECTIONS FROZEN',flush=True)

if __name__=='__main__':
    cmd=sys.argv[1]
    if cmd=='prepare':prepare()
    elif cmd=='train':train(sys.argv[2],int(sys.argv[3]),sys.argv[4])
    elif cmd=='run':run_all()
    else:raise SystemExit(cmd)
