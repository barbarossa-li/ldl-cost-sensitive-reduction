"""Independent integrity/feasibility audit of recorded actual error vectors."""
from pathlib import Path
import hashlib,json,sqlite3
import numpy as np
ROOT=Path(__file__).resolve().parent
assert (ROOT/'ALL_SELECTIONS_FROZEN.json').exists()
reports=[]
for p in sorted((ROOT/'results').rglob('selection.json')):
 record=json.loads(p.read_text());root=p.parent;conn=sqlite3.connect(root/'errors.sqlite');assert conn.execute('pragma integrity_check').fetchone()[0]=='ok'
 vectors={};count=0
 for subset,n,dtype,h,raw in conn.execute('select subset,n,dtype,sha256,errors from vectors'):
  assert hashlib.sha256(raw).hexdigest()==h
  e=np.frombuffer(raw,dtype=dtype);assert len(e)==n==192 and np.isfinite(e).all() and np.all(e>=0)
  vectors[tuple(json.loads(subset))]=e;count+=1
 conn.close()
 endpoint=np.load(root/'endpoint_errors.npz');reference=endpoint['reference'];selected=record['result']['selected']
 if selected is not None:
  selected=tuple(selected);assert np.array_equal(vectors[selected],endpoint['final']);assert np.all(vectors[selected]<=reference+1e-12)
  for a in selected:
   neighbor=tuple(x for x in selected if x!=a);assert neighbor in vectors and np.any(vectors[neighbor]>reference+1e-12)
 reports.append({'dataset':record['dataset'],'repeat':record['repeat'],'variant':record['variant'],'recorded_subsets':count,'recorded_error_values':count*192,'own_feasible':selected is not None,'terminal_single_deletion_certificate':selected is not None})
summary={'rows':reports,'total_subsets':sum(x['recorded_subsets'] for x in reports),'total_error_values':sum(x['recorded_error_values'] for x in reports),'all_27_records_present':len(reports)==27,'all_database_and_vector_digests_valid':True}
(ROOT/'record_audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='rows'}))
