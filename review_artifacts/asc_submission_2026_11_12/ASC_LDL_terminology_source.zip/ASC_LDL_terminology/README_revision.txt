Entry: main_short_flowcharts.tex
Compile: latexmk -pdf main_short_flowcharts.tex
Revision: 2026-11-12
Title explicitly includes granular-ball computing. Terminology, headings, captions and table headers unified. Mathematical expressions and table numeric rows checked against the supplied source and unchanged.
