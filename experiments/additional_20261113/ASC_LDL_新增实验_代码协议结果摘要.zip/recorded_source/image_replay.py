"""Independent image-to-feature-to-prediction replay of six frozen pool endpoints."""
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parent
os.environ['TORCH_HOME']=str(ROOT/'models')
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import hashlib,json,sys,time,zipfile
from io import BytesIO
import numpy as np
BASE=Path('/workspace/work/asc_review/repro/ASC_REVIEW_REPRODUCIBILITY_v2/supplementary/tolerance_envelope/results')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def prepare():
 archive=ROOT/'data/SCUT-FBP5500_v2.1.zip'
 protocol={'version':'official-image-replay-20261113-v1','scope':'Original official images/60 ratings -> fresh ResNet-18 features -> held-out predictions at six pre-existing pool endpoints. No new 3300-object O1 selection or training-reconstruction certification.',
 'archive_sha256':sha(archive),'official_archive_url':'https://drive.google.com/file/d/1w0TorBfTIqbquQVd6k3h_77ypnrvfGwf/view',
 'labels':'ALL sheet; third column final Rating, not fourth original Rating; require 60 unique raters/image, integer scores1..5; five-bin empirical distribution',
 'split':'Official 60/40 train.txt,test.txt in file order; additionally check canonical lexicographic train order for stable-tie sensitivity without selecting between them.',
 'extractor':'torch2.5.1+cpu torchvision0.20.1+cpu ResNet18_Weights.IMAGENET1K_V1 weights.transforms(), fc=Identity, eval, float32, batches32, CPU3threads',
 'endpoints':'All six stored frontier_plan.json subsets, selected before this study; no endpoint selection from re-evaluated test losses.',
 'prediction':'Frozen training-minmax stable 5NN; all four original metrics; compare returned values to stored endpoint_assessment.json. Store reconstructed predictions and features.',
 'schedule':'Run CPU image inference after all27 array selections complete. Record extraction time and backend time, not old-hardware speedup replication.',
 'limits':['No verified row-to-subject mapping for historical descriptor arrays; filenames are image identifiers, not proven person IDs','Original model-cache/return image identities unavailable; archive and model identities recorded here','Full eager m*n*n double relations for3300x512 exceed current8GiB; image O1 reselection not claimed'],
 'source_sha256':sha(Path(__file__)),'frontier_sha256':sha(BASE/'frontier_plan.json'),'assessments_sha256':sha(BASE/'endpoint_assessment.json')}
 path=ROOT/'IMAGE_PROTOCOL.json'
 if path.exists():assert protocol==json.loads(path.read_text())
 else:save(path,protocol)
 print('IMAGE PROTOCOL FROZEN',sha(path),flush=True)

def run():
 assert (ROOT/'ALL_SELECTIONS_FROZEN.json').exists(),'Wait until array selections finish to isolate timed training jobs'
 protocol=json.loads((ROOT/'IMAGE_PROTOCOL.json').read_text());assert protocol['source_sha256']==sha(Path(__file__))
 assert sha(ROOT/'data/SCUT-FBP5500_v2.1.zip')==protocol['archive_sha256']
 import openpyxl
 from PIL import Image
 import torch,torchvision
 from torchvision.models import resnet18,ResNet18_Weights
 sys.path.insert(0,'/workspace/work/asc_review/code_bundle')
 from baseline_revision.prediction_evaluation import predict_five_neighbors,metrics
 torch.set_num_threads(3);torch.set_num_interop_threads(1)
 weights=ResNet18_Weights.IMAGENET1K_V1
 t=time.perf_counter();model=resnet18(weights=weights).eval();model.fc=torch.nn.Identity();transform=weights.transforms()
 names=[];labels=None;image_hashes={}
 with zipfile.ZipFile(ROOT/'data/SCUT-FBP5500_v2.1.zip') as z:
  members={Path(n).name:n for n in z.namelist() if '/Images/' in n and n.lower().endswith('.jpg')};names=sorted(members);assert len(names)==5500
  index={name:i for i,name in enumerate(names)}
  count=np.zeros(5500,int);bins=np.zeros((5500,5),int);raters=[set() for _ in names]
  book=openpyxl.load_workbook(BytesIO(z.read('SCUT-FBP5500_v2/All_Ratings.xlsx')),read_only=True,data_only=True)
  for rater,filename,rating,*other in book['ALL'].iter_rows(min_row=2,max_row=330001,values_only=True):
   if filename is None:continue
   i=index[filename];assert int(rating)==rating and 1<=rating<=5 and rater not in raters[i]
   bins[i,int(rating)-1]+=1;count[i]+=1;raters[i].add(rater)
  assert np.all(count==60)
  labels=bins/60.
  split={}
  for kind in ['train','test']:
   p=f'SCUT-FBP5500_v2/train_test_files/split_of_60%training and 40%testing/{kind}.txt'
   lines=[line.split() for line in z.read(p).decode().splitlines() if line.strip()]
   split[kind]=np.array([index[x[0]] for x in lines],int)
   expected=np.array([float(x[1]) for x in lines]);actual=labels[split[kind]]@np.arange(1,6)
   assert np.max(np.abs(expected-actual))<1e-6
  assert len(split['train'])==3300 and len(split['test'])==2200 and set(split['train']).isdisjoint(split['test'])
  np.savez_compressed(ROOT/'data/official_labels_split.npz',labels=labels,train=split['train'],test=split['test'],names=np.array(names))
  feature_file=ROOT/'data/official_resnet18_features.npy'
  if feature_file.exists():features=np.load(feature_file);assert features.shape==(5500,512)
  else:
   features=np.empty((5500,512),np.float32);start=time.perf_counter()
   with torch.inference_mode():
    for pos in range(0,len(names),32):
     batch=[]
     for name in names[pos:pos+32]:
      raw=z.read(members[name]);image_hashes[name]=hashlib.sha256(raw).hexdigest()
      with Image.open(BytesIO(raw)) as im:batch.append(transform(im.convert('RGB')))
     features[pos:pos+len(batch)]=model(torch.stack(batch)).numpy()
     if pos%512==0:print('IMAGES',pos+len(batch),'/5500',round(time.perf_counter()-start,2),flush=True)
   np.save(feature_file,features);save(ROOT/'IMAGE_MANIFEST.json',image_hashes)
  extraction_seconds=time.perf_counter()-t
 frontier=json.loads((BASE/'frontier_plan.json').read_text())['frontier'];old=json.loads((BASE/'endpoint_assessment.json').read_text())['rows']
 rows=[];predictions={}
 for j,endpoint in enumerate(frontier):
  selected=endpoint['selected'];train=split['train'];test=split['test']
  start=time.perf_counter();prediction=predict_five_neighbors(features[train],labels[train],features[test],selected);elapsed=time.perf_counter()-start
  result=metrics(labels[test],prediction);predictions[f'endpoint_{j}']=prediction
  canonical=np.sort(train);canonical_prediction=predict_five_neighbors(features[canonical],labels[canonical],features[test],selected)
  row={'endpoint':j,'attributes':len(selected),'metrics':result,'old_metrics':old[j]['test'],'delta':{k:result[k]-old[j]['test'][k] for k in result},'backend_seconds':elapsed,'train_order_max_prediction_diff':float(np.max(np.abs(prediction-canonical_prediction))),'selected_sha256':hashlib.sha256(json.dumps(selected).encode()).hexdigest()}
  rows.append(row);print('PREDICTION',len(selected),result,'delta',row['delta'],flush=True)
 np.savez_compressed(ROOT/'image_predictions.npz',**predictions)
 # Image hashes detect exact duplicates, not same-person identity.
 hashes=json.loads((ROOT/'IMAGE_MANIFEST.json').read_text());train_hash={hashes[names[i]] for i in split['train']};test_hash={hashes[names[i]] for i in split['test']}
 weightfile=ROOT/'models/hub/checkpoints'/weights.url.rsplit('/',1)[1]
 save(ROOT/'image_replay_results.json',{'protocol_sha256':sha(ROOT/'IMAGE_PROTOCOL.json'),'torch':torch.__version__,'torchvision':torchvision.__version__,'threads':3,'weights_sha256':sha(weightfile),'archive_sha256':sha(ROOT/'data/SCUT-FBP5500_v2.1.zip'),'labels_split_sha256':sha(ROOT/'data/official_labels_split.npz'),'features_sha256':sha(feature_file),'predictions_sha256':sha(ROOT/'image_predictions.npz'),'image_manifest_sha256':sha(ROOT/'IMAGE_MANIFEST.json'),'extraction_plus_preparation_seconds':extraction_seconds,'exact_image_hash_overlap_between_splits':len(train_hash&test_hash),'unique_image_hashes':len(set(hashes.values())),'rows':rows})
 print('IMAGE REPLAY DONE',flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='run':run()
