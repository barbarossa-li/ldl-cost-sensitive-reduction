from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,csv,subprocess,time,resource
import numpy as np
R=Path(__file__).resolve().parent
E02=Path(os.environ.get('AI_LDL_E02','/workspace/work/ai_e02_20261113'));sys.path.insert(0,str(E02))
from calibrated import CalibratedPrototypeModel,E0
from model import CORE
from run_pilot import DATA,DATASETS
from controls import predict,check
ZS=[.1,.5,.9];AS=[0.,.25,.5,.75,1.];TARGETS=['raw','global_mean','covered_mean','ball','random']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def seeds(di,f,stage):return [202611130300+di*10000+f*100+stage*10+i for i in range(5)]
def loss(y,p):return float(np.square(y-p).sum(1).mean())
def mixed(b,target,alpha):
 if target=='raw':return b['raw']
 return (1-alpha)*b['raw']+alpha*b[target]
def expected_loss(y,p):return np.mean([loss(y,a) for a in p]) if p.ndim==3 else loss(y,p)
def choose(rows):
 # No validation outcomes enter this function. At alpha=0 targets tie with raw.
 return min(rows,key=lambda r:(r['brier'],r['alpha'],abs(r['zeta']-.5),r['zeta']))
def prepare():
 sources=[R/'run.py',R/'controls.py',E02/'calibrated.py',E0/'model.py']
 inputs=[DATA/f'{d}_{a}.npy' for d in DATASETS for a in ['X','L']]+[CORE/'expansion25/splits'/d/'repeat_1.json' for d in DATASETS]
 p={'version':'AI-E0.3-coverage-matched-nested-development-v1','scope':'Nine already consulted E0.2 development folds, 128 training/64 validation. New inner 3-fold training-only tuning. No independent confirmation or outer-test scoring.','datasets':DATASETS,'outer_folds':[0,1,2],'inner_folds':3,'zeta_grid':ZS,'alpha_grid':AS,'weights':['U','L'],'masks':['Full','cost40 from E0.2'],'targets':TARGETS,'calibration':'balanced training-Full fixed scales, refit on each inner training fold','random_control':'5 seeds; permute only covered training IDs into the same accepted group-size sequence. Preserve exact covered IDs, group sizes, residual IDs and prototype slots. Average losses across seeds for tuning; report mean of seed losses, not loss of ensemble.','tuning':'Each weight/mask/target separately minimizes pooled per-object Brier across three inner folds. Tie: smaller alpha, zeta closer to .5, smaller zeta. Raw uses three zetas. All other targets get 15 grid entries; random seeds never selected.','fixed_analysis':'zeta=.5, alpha=.5 for all nonraw targets; additionally ball residual alpha=1. All outcomes disclosed.','inner_seed':'202611130300+10000*dataset_index+100*fold; random seed=base+10*stage+seed_index where stage0..2 inner,3 final; dataset_index0..2','isolation':'Only fit128 labels accessed during selection and final prediction. Final64 labels loaded in score only after all nine prediction bundles and selected parameter records have been hashed. All external test indices excluded.','source_hashes':{str(p):sha(p) for p in sources},'input_hashes':{str(p):sha(p) for p in inputs},'checks':check()}
 old=R/'PROTOCOL.json'
 if old.exists():assert json.loads(old.read_text())==p
 else:save(old,p)
 print('PROTOCOL FROZEN',sha(old),flush=True)
def verify():
 p=json.loads((R/'PROTOCOL.json').read_text())
 for f,h in {**p['source_hashes'],**p['input_hashes']}.items():assert sha(f)==h
 return p
def worker(di,f):
 verify();d=DATASETS[di];out=R/'cases'/d/f'fold_{f}';out.mkdir(parents=True,exist_ok=True);start=time.perf_counter()
 split=json.loads((CORE/'expansion25/splits'/d/'repeat_1.json').read_text());parent=np.array(split['train_indices']);v=np.array(split['fold_validation_positions'][f]);fit=parent[np.setdiff1d(np.arange(192),v)];val=parent[v]
 assert not(set(fit)|set(val))&set(split['test_indices']) and set(fit).isdisjoint(val)
 Xall=np.load(DATA/f'{d}_X.npy',mmap_mode='r');Lall=np.load(DATA/f'{d}_L.npy',mmap_mode='r');X=Xall[fit];L=Lall[fit];Q=Xall[val]
 cost=np.array(split['costs']);order=np.random.default_rng(202611130000+1000*di+100+f).permutation(X.shape[1]);masks={'Full':tuple(range(X.shape[1])),'cost40':tuple(sorted(map(int,order[np.cumsum(cost[order])<=.4*sum(cost)])))}
 folds=np.array_split(np.random.default_rng(202611130300+10000*di+100*f).permutation(128),3);sums={};private_inner={}
 for j,iv in enumerate(folds):
  it=np.setdiff1d(np.arange(128),iv)
  for z in ZS:
   m=CalibratedPrototypeModel(X[it],L[it],zeta=z)
   for w in ['U','L']:
    for mask,P in masks.items():
     b,_=predict(m,X[iv][:,P],P,w,seeds(di,f,j))
     for t in TARGETS:
      for a in ([0.] if t=='raw' else AS):
       key=(w,mask,t,z,a);sums[key]=sums.get(key,0.)+len(iv)*expected_loss(L[iv],mixed(b,t,a))
     for t,p in b.items():private_inner[f'{j}_{z}_{w}_{mask}_{t}']=p
 rows=[dict(weight=w,mask=mask,target=t,zeta=z,alpha=a,brier=s/128) for (w,mask,t,z,a),s in sums.items()]
 choices=[]
 for w in ['U','L']:
  for mask in masks:
   for t in TARGETS:choices.append(choose([r for r in rows if (r['weight'],r['mask'],r['target'])==(w,mask,t)]))
 # Final predictions for selected and fixed analyses are generated without final validation labels.
 final={};stats=[]
 for z in ZS:
  m=CalibratedPrototypeModel(X,L,zeta=z)
  for w in ['U','L']:
   for mask,P in masks.items():
    b,s=predict(m,Q[:,P],P,w,seeds(di,f,3))
    for t,p in b.items():final[f'{z}_{w}_{mask}_{t}']=p
    stats.append({'zeta':z,'weight':w,'mask':mask,**s})
 final['plain_mean']=np.tile(L.mean(0),(64,1));np.savez_compressed(out/'predictions.npz',**final);np.savez_compressed(out/'inner_predictions.npz',**private_inner)
 save(out/'record.json',{'dataset':d,'fold':f,'fit_indices':fit.tolist(),'validation_indices':val.tolist(),'inner_validation_positions':[x.tolist() for x in folds],'choices':choices,'inner_scores':rows,'statistics':stats,'predictions_sha256':sha(out/'predictions.npz'),'inner_predictions_sha256':sha(out/'inner_predictions.npz'),'protocol_sha256':sha(R/'PROTOCOL.json'),'wall_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024});print('FROZEN',d,f,round(time.perf_counter()-start,2),flush=True)
def run():
 verify()
 for di in range(3):
  for f in range(3):subprocess.run([sys.executable,str(R/'run.py'),'worker',str(di),str(f)],check=True)
 save(R/'ALL_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(R/'PROTOCOL.json'),'records':{str(p.relative_to(R)):sha(p) for p in sorted((R/'cases').rglob('record.json'))}})
def score():
 verify();frozen=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());rows=[]
 for name,h in frozen['records'].items():
  p=R/name;assert sha(p)==h;c=json.loads(p.read_text());a=np.load(p.parent/'predictions.npz');assert sha(p.parent/'predictions.npz')==c['predictions_sha256'];y=np.load(DATA/f"{c['dataset']}_L.npy",mmap_mode='r')[c['validation_indices']]
  settings=[('nested',r) for r in c['choices']]+[('fixed',{'weight':w,'mask':mask,'target':t,'zeta':.5,'alpha':0. if t=='raw' else .5}) for w in ['U','L'] for mask in ['Full','cost40'] for t in TARGETS]+[('residual_endpoint',{'weight':w,'mask':mask,'target':'ball','zeta':.5,'alpha':1.}) for w in ['U','L'] for mask in ['Full','cost40']]
  for policy,r in settings:
   b={t:a[f"{r['zeta']}_{r['weight']}_{r['mask']}_{t}"] for t in TARGETS};value=mixed(b,r['target'],r['alpha']);vals=[loss(y,v) for v in value] if value.ndim==3 else [loss(y,value)]
   rows.append({'dataset':c['dataset'],'fold':c['fold'],'policy':policy,**{k:r[k] for k in ['weight','mask','target','zeta','alpha']},'brier':float(np.mean(vals)),'seed_briers':vals})
  rows.append({'dataset':c['dataset'],'fold':c['fold'],'policy':'plain_mean','weight':'NA','mask':'NA','target':'plain_mean','zeta':None,'alpha':None,'brier':loss(y,a['plain_mean']),'seed_briers':[]})
 keys=sorted(set((r['dataset'],r['policy'],r['weight'],r['mask'],r['target']) for r in rows));summary=[]
 for key in keys:
  group=[r for r in rows if (r['dataset'],r['policy'],r['weight'],r['mask'],r['target'])==key];summary.append(dict(zip(['dataset','policy','weight','mask','target'],key),brier_mean=float(np.mean([r['brier'] for r in group])),folds=len(group)))
 save(R/'RESULTS.json',{'protocol_sha256':sha(R/'PROTOCOL.json'),'scope':'Already consulted internal development cases only','rows':rows,'summary':summary,'outer_test_scored':False});print('SCORED',len(rows),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='worker':worker(int(sys.argv[2]),int(sys.argv[3]))
 else:globals()[sys.argv[1]]()
