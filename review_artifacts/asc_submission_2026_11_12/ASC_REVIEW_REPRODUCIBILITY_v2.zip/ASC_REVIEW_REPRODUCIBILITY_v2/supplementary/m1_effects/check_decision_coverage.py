"""Recompute the manuscript's decision diagnostics from frozen object records."""
import csv
import json
from pathlib import Path

records = Path(__file__).with_name("all_objects.csv")
tolerance = 1e-12


def flag(row, name):
    return row[name] == "True"


def summarize(rows, method, error_prefix):
    feasible = [
        row for row in rows
        if float(row[f"{error_prefix}_error"]) <= float(row["full_error"]) + tolerance
    ]
    correct = [row for row in feasible if flag(row, "reference_correct_unique")]
    certified = [
        row for row in feasible
        if flag(row, "truth_unique")
        and float(row["full_error"]) + tolerance < float(row["truth_top_margin"]) ** 2 / 2
    ]
    assert all(flag(row, "reference_correct_unique") for row in certified)
    assert all(not flag(row, f"{method}_top_set_changed") for row in certified)
    return {
        "object_occurrences": len(rows),
        "o1_feasible": len(feasible),
        "reference_top_set_unchanged": sum(
            not flag(row, f"{method}_top_set_changed") for row in feasible
        ),
        "reference_correct_unique": len(correct),
        "still_correct_unique": sum(
            not flag(row, f"{method}_correct_to_wrong")
            and not flag(row, f"{method}_correct_to_tied") for row in correct
        ),
        "pairwise_rank_loss_not_increased": sum(
            float(row[f"{method}_rank_loss_increase"]) <= tolerance for row in feasible
        ),
        "unique_true_maximum_certified": len(certified),
    }


with records.open(encoding="utf-8", newline="") as handle:
    primary = [row for row in csv.DictReader(handle) if row["training_size"] == "192"]

assert len(primary) == 1728
assert len({(row["dataset"], row["repeat"]) for row in primary}) == 9
print(json.dumps({
    "GBIP-O1": summarize(primary, "GBIP-O1", "O1"),
    "Mean": summarize(primary, "Mean", "mean"),
}, indent=2))
