"""Family-blocked comparisons on the frozen min--max predictor benchmark."""
import csv
from collections import defaultdict
from itertools import product
import json
from pathlib import Path
import statistics
import sys

import numpy as np
from scipy.stats import rankdata

O1 = "GBIP-O1"
GB = "GBFRS-EQ paper quota"
METHODS = (O1, GB, "Full", "IWDLFS paper CV", "IWCLFS paper CV")
TOL = 1e-12
DRAWS = 49999
SEED = 20261109


def records(path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def family_means(rows, methods):
    by_task = defaultdict(lambda: defaultdict(dict))
    for row in rows:
        if row["role"] != "main" or row["status"] != "ok" or row["method"] not in {*methods, "Full"}:
            continue
        slot = by_task[row["dataset"]][row["method"]]
        assert row["repeat"] not in slot
        slot[row["repeat"]] = row
    by_family = defaultdict(list)
    excluded = []
    for task, group in sorted(by_task.items()):
        if any(set(group[m]) != {"1", "2", "3"} for m in methods):
            excluded.append(task)
            continue
        name = "Yeast" if task.startswith("Yeast_") else task
        by_family[name].append((task, group))
    output = []
    for family, tasks in by_family.items():
        for method in methods:
            brier, costs = [], []
            for _, group in tasks:
                brier.append(statistics.mean(float(r["brier"]) for r in group[method].values()))
                costs.append(statistics.mean(100 * float(r["cost"]) / float(group["Full"][rep]["cost"])
                                             for rep, r in group[method].items()))
            output.append(dict(family=family, conditions=";".join(t for t, _ in tasks),
                               method=method, brier=statistics.mean(brier),
                               normalized_cost=statistics.mean(costs)))
    return output, excluded


def paired(rows, left, right, metric):
    values = {(r["family"], r["method"]): r[metric] for r in rows}
    differences = np.array([v-values[f, right] for (f, m), v in values.items() if m == left])
    rounded = np.round(differences, 12)
    rounded[np.abs(rounded) <= TOL] = 0
    nonzero = rounded[rounded != 0]
    ranks = rankdata(np.abs(nonzero))
    observed = abs(np.sign(nonzero) @ ranks)
    signed_sums = (abs(np.array(s) @ ranks) for s in product((-1, 1), repeat=len(ranks)))
    p = sum(s >= observed for s in signed_sums) / 2**len(ranks)
    return dict(left=left, right=right, metric=metric, n=len(differences),
                lower=int(sum(rounded<0)), ties=int(sum(rounded==0)), higher=int(sum(rounded>0)),
                median_delta=float(np.median(differences)),
                rank_biserial=float(np.sign(nonzero) @ ranks / ranks.sum()) if len(ranks) else 0,
                p=p)


def holm(tests):
    ordered = sorted(tests, key=lambda r: r["p"])
    previous = 0
    for i, row in enumerate(ordered):
        previous = max(previous, min(1, (len(ordered)-i)*row["p"]))
        row["p_holm"] = previous


def friedman(rows):
    by_family = defaultdict(dict)
    for r in rows:
        by_family[r["family"]][r["method"]] = r["brier"]
    values = np.array([[round(v[m],12) for m in METHODS] for v in by_family.values()])
    ranks = rankdata(values, axis=1)
    n,k = ranks.shape
    centered = ranks - (k+1)/2
    observed = np.square(centered.sum(axis=0)).sum()
    rng = np.random.default_rng(SEED)
    extreme = 0
    for offset in range(0,DRAWS,1000):
        size = min(1000,DRAWS-offset)
        order = rng.random((size,n,k)).argsort(axis=2)
        simulated = np.take_along_axis(centered[None,:,:],order,axis=2)
        extreme += int(np.count_nonzero(np.square(simulated.sum(axis=1)).sum(axis=1) >= observed))
    dispersion = np.square(centered).sum()
    q = (k-1) * observed / dispersion if dispersion else 0
    return dict(n=n, q=float(q), p_permutation=(extreme+1)/(DRAWS+1), draws=DRAWS, seed=SEED,
                mean_ranks=dict(zip(METHODS,ranks.mean(axis=0).tolist())))


def main(source, output):
    rows = records(source)
    primary, primary_excluded = family_means(rows, (O1, GB))
    omnibus, omnibus_excluded = family_means(rows, METHODS)
    tests = [paired(primary, GB, O1, m) for m in ("brier","normalized_cost")]
    holm(tests)
    overall = friedman(omnibus)
    posthoc = [paired(omnibus, m, O1, "brier") for m in METHODS if m != O1] if overall["p_permutation"] < .05 else []
    holm(posthoc)
    no_yeast = [paired([r for r in primary if r["family"] != "Yeast"], GB, O1, m)
                for m in ("brier","normalized_cost")]
    holm(no_yeast)
    assert all(t["n"] == 15 for t in tests) and overall["n"] == 14
    write_rows(output / "primary_family_means.csv", primary)
    write_rows(output / "omnibus_family_means.csv", omnibus)
    summary = dict(primary=tests, primary_excluded_tasks=primary_excluded,
                   friedman=overall, omnibus_excluded_tasks=omnibus_excluded,
                   posthoc=posthoc, primary_excluding_yeast=no_yeast)
    (output / "summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary,indent=2))


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:]))
