"""Coverage-matched smoothing targets; no validation labels accepted."""
import numpy as np

def targets(model, representation, seeds):
 covered=representation['covered'];groups=representation['accepted'];base=model.L.copy()
 cm=base.copy();cm[covered]=model.p
 random=[]
 for seed in seeds:
  ids=np.random.default_rng(seed).permutation(np.flatnonzero(covered));r=base.copy();pos=0
  for group in groups:
   g=ids[pos:pos+len(group)];pos+=len(group);r[g]=model.L[g].mean(0)
  assert pos==int(covered.sum())
  assert np.array_equal(r[~covered],base[~covered])
  random.append(r)
 return {'global_mean':np.broadcast_to(model.p,base.shape).copy(),'covered_mean':cm,'ball':representation['ball_residual'],'random':np.stack(random)}

def predict(model,Q,P,weight,seeds):
 result=model.evaluate_selected(Q,P,weight);ids=result['neighbors'];rep=result['representation'];t=targets(model,rep,seeds)
 out={'raw':result['predictions']['raw']}
 for key,v in t.items():
  if key=='random':out[key]=np.stack([r[ids].mean(1) for r in v])
  else:out[key]=v[ids].mean(1)
 return out,rep['statistics']

def check():
 from types import SimpleNamespace
 L=np.array([[.9,.1],[.8,.2],[.1,.9],[.2,.8],[.6,.4],[.4,.6]])
 m=SimpleNamespace(L=L,p=L.mean(0));rep={'covered':np.array([1,1,1,1,0,0],bool),'accepted':[(0,1),(2,3)],'ball_residual':L.copy()}
 rep['ball_residual'][:2]=L[:2].mean(0);rep['ball_residual'][2:4]=L[2:4].mean(0)
 t=targets(m,rep,range(5));assert np.array_equal(t['covered_mean'][4:],L[4:]);assert np.array_equal(t['covered_mean'][:4],np.tile(m.p,(4,1)))
 assert t['random'].shape==(5,6,2);assert np.allclose(t['random'].sum(2),1);assert np.array_equal(t['random'][:,4:],np.broadcast_to(L[4:],(5,2,2)))
 for covered,groups in [(np.zeros(6,bool),[]),(np.ones(6,bool),[(0,1),(2,3,4,5)])]:
  r=targets(m,{'covered':covered,'accepted':groups,'ball_residual':L},range(5));assert r['random'].shape==(5,6,2)
 return {'passed':True,'checks':['same-covered-object randomization','accepted group-size preservation','uncovered residual invariance','probability simplex','no/all coverage','training-only target API']}
if __name__=='__main__':print(check())
