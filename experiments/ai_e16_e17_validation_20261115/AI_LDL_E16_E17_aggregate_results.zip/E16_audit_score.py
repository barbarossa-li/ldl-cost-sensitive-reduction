"""Post-freeze audit and aggregate scoring; never run before complete prediction freeze."""
from pathlib import Path
import os,sys,json,hashlib,csv,collections
import numpy as np
BASE=Path('/workspace/work/ai_e16_20261115');SOURCE=BASE/'source';PARENT=Path('/workspace/work/ai_external_v1_20261114/source');RUN=BASE/'run';OUT=BASE/'public'
os.environ['LDL_PARENT_SOURCE']=str(PARENT);sys.path.insert(0,str(SOURCE));import learners as l
from study import resource
r=l.r

def independent_metrics(y,v):
 d=abs(y-v);eps=1e-12
 return {'brier':float(np.mean(np.sum((y-v)**2,axis=1))),'chebyshev':float(d.max(1).mean()),'clark':float(np.sqrt(np.sum((d/np.where(y+v>0,y+v,1))**2,axis=1)).mean()),'canberra':float(np.sum(d/np.where(y+v>0,y+v,1),axis=1).mean()),'kl':float(np.sum(np.where(y>0,y*np.log(np.where(y>0,y,1)/np.maximum(v,eps)),0),axis=1).mean()),'cosine':float(np.mean(np.sum(y*v,axis=1)/(np.linalg.norm(y,axis=1)*np.linalg.norm(v,axis=1)))),'intersection':float(np.minimum(y,v).sum(1).mean())}

def main():
 frozen=json.loads((RUN/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(frozen['records'])==53
 for n,h in frozen['records'].items():assert r.sha(RUN/n)==h
 OUT.mkdir(exist_ok=True);parent=r.verify();rows=[];selection=[];checks=collections.Counter();maxerr=0.;metricsmax=0.;failures=[]
 for name,h in frozen['records'].items():
  file=RUN/name;rec=json.loads(file.read_text());case=file.parent
  assert rec['protocol_sha256']==r.sha(SOURCE/'PROTOCOL.json') and rec['source_manifest_sha256']==r.sha(SOURCE/'MANIFEST.json')
  for key,fn in [('predictions_sha256','predictions_PRIVATE.npz'),('states_sha256','inference_state_PRIVATE.npz'),('inner_predictions_sha256','inner_predictions_PRIVATE.npz')]:assert r.sha(case/fn)==rec[key]
  f=next(x for x in parent['stages']['e11']['families'] if x['family']==rec['family']) if rec['stage']=='e11' else parent['stages']['e12']['family'];X,Y=r.checked_data(Path('/workspace/work/asc_experiments/data' if rec['stage']=='e11' else '/workspace/work/ai_e12_20261114/data'),f);fit=np.array(rec['fit_indices']);held=np.array(rec['validation_indices']);parts=[np.array(x) for x in rec['inner_folds']];pred=np.load(case/'predictions_PRIVATE.npz');states=np.load(case/'inference_state_PRIVATE.npz');cv=np.load(case/'inner_predictions_PRIVATE.npz');old=np.load(Path('/workspace/work/ai_external_v1_20261114/run')/name.replace('record_PRIVATE.json','predictions_PRIVATE.npz'))
  _,grp=np.unique(X[fit],axis=0,return_inverse=True)
  for i in range(3):
   for j in range(i):assert not set(grp[parts[i]])&set(grp[parts[j]])
  assert sorted(np.concatenate(parts).tolist())==list(range(len(fit)));checks['group_partition_cases']+=1
  bymenu=collections.defaultdict(list)
  for item in rec['cv_scores']:
   key=item['mask']+'___'+item['method']+'___'+item['id'];v=cv[key];assert np.isfinite(v).all()==item['available']
   if item['available']:
    loss=np.sum((v-Y[fit])**2,axis=1);assert abs(loss.mean()-item['risk'])<1e-12
    fr=[float(loss[h].mean()) for h in parts];assert np.allclose(fr,item['fold_risks'],atol=1e-12,rtol=0)
    assert abs(np.std(fr,ddof=1)/np.sqrt(3)-item['se'])<1e-12;checks['inner_candidate_scores']+=1
   bymenu[item['mask'],item['method']].append(item)
  for key,choice in rec['choices'].items():
   mask,policy=key.split('__');method='U' if policy=='G_atU' else policy.split('_')[0];menu=[x for x in bymenu[mask,method] if x['available']];best=min(x['risk'] for x in menu)
   if mask=='Full':d=X.shape[1]
   else:
    if rec['stage']=='e11':fi=next(i for i,z in enumerate(parent['stages']['e11']['families']) if z['family']==f['family']);d=len(r.known_design(f,fi)[2][mask])
    else:d=len(r.novel_design(X)[1][mask])
   tie=[x for x in menu if x['risk']<=best+1e-12];minrow=min(tie,key=lambda x:(resource(method,x['params'],len(fit),d,Y.shape[1]),x['id']))
   if policy=='G_oneSE':eligible=[x for x in menu if x['risk']<=minrow['risk']+minrow['se']];expected=min(eligible,key=lambda x:(resource(method,x['params'],len(fit),d,Y.shape[1]),x['risk'],x['id']))
   else:expected=minrow
   assert choice['id']==expected['id'];checks['independent_selection_checks']+=1
   selection.append({'stage':rec['stage'],'family':rec['family'],'fold':rec['fold'],'mask':mask,'policy':policy,'candidate_id':choice['id'],'mean_only':choice['params'].get('kind')=='Mean','params':json.dumps(choice['params'],sort_keys=True),'inner_brier':choice['risk']})
  for key in pred.files:
   v=pred[key];r.valid(v,len(held),Y.shape[1]);meta=rec['state_metadata'][key];st={k:val for k,val in meta.items() if k!='array_bytes'}
   for k in states.files:
    prefix=key+'___'
    if k.startswith(prefix):st[k[len(prefix):]]=states[k]
   assert l.byte_count(st)==meta['array_bytes'];again=l.predict(st,X[held],native='native_atSelected' in key);err=float(abs(again-v).max());assert err<1e-7;maxerr=max(maxerr,err);checks['state_predictions']+=1
   if 'fixed' in key:
    oldkey=key.replace('_fixed','');assert np.array_equal(v,old[oldkey]);checks['exact_fixed_anchor_replays']+=1
   if key=='plain_mean':mask,policy='Shared','plain_mean'
   else:mask,policy=key.split('__')
   mm=independent_metrics(Y[held],v);ref=r.metrics(Y[held],v)
   for metric,val in mm.items():
    refval=ref[metric] if metric in ref else ref[metric.capitalize()];metricsmax=max(metricsmax,abs(val-refval));assert abs(val-refval)<1e-9
   rows.append({'stage':rec['stage'],'family':rec['family'],'fold':rec['fold'],'mask':mask,'policy':policy,'query_n':len(held),'array_bytes':meta['array_bytes'],'query_feature_count':0 if st['kind']=='Mean' else len(st['P']),**mm})
  for key,val in rec['details']['failures'].items():failures.append({'stage':rec['stage'],'family':rec['family'],'fold':rec['fold'],'policy':key,**val})
 for name,data in [('CASE_METRICS.csv',rows),('SELECTIONS.csv',selection)]:
  with (OUT/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 summaries=[]
 for stage in ['e11','e12']:
  for mask in ['Full','cost40']:
   for policy in sorted({x['policy'] for x in rows if x['mask']==mask}):
    rr=[x for x in rows if x['stage']==stage and x['mask']==mask and x['policy']==policy];families=sorted({x['family'] for x in rr});means={metric:float(np.mean([np.mean([z[metric] for z in rr if z['family']==fam]) for fam in families])) for metric in ['brier','array_bytes','query_feature_count']} if rr else {};summaries.append({'stage':stage,'mask':mask,'policy':policy,'cases':len(rr),'families':len(families),**means})
 with (OUT/'SUMMARY.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
 audit={'passed':True,'checks':dict(checks),'state_prediction_max_error':maxerr,'metric_max_error':metricsmax,'outer_prediction_rows':len(rows),'missing_policies':failures,'protocol_sha256':r.sha(SOURCE/'PROTOCOL.json'),'manifest_sha256':r.sha(SOURCE/'MANIFEST.json'),'restriction':'All consulted development cases; no confirmation or exhaustive SOTA claim.'};r.save(OUT/'AUDIT.json',audit);print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
