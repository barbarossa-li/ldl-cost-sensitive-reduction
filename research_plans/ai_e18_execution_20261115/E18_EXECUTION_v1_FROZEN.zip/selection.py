"""E18 nested text selection: no outer query targets accepted."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np,traceback,json,io
import learners as l
import encoding
r=l.r

def resource(method,p,n,d,q):
 if p.get('kind')=='Mean':return 8*q
 a=p['alpha']
 if method in ['G','U']:return 8*(max(1,p['budget']*n//100)*(d+q+1)+4*d+q)
 if method=='AA':return 8*(n*(d+q)+3*d+(q if a else 0))
 if method=='Ridge':return 8*(d*q+3*d+q+(q if a else 0))
 return 8*n*(d+q)+4*n*q+4*n+24*d+(8*q if a else 0)
def choose(rows,method,n,d,q):
 vv=[x for x in rows if x['available']];best=min(x['risk'] for x in vv);return min([x for x in vv if x['risk']<=best+1e-12],key=lambda x:(resource(method,x['params'],n,d,q),x['id']))
def fixed_states(model):
 P=tuple(range(model.m));states={}
 for c in ['U','G']:
  for budget in [25,50,75,100]:
   st=l.prototype_state(model,P,c,budget,5);states[c+c+str(budget)+'_fixed']=l.with_prior(st,.5,model.p)
   if budget==50:
    q='G' if c=='U' else 'U';other=dict(st);other['weight']=model.weights(q)[0,list(P)].copy();other['scales']=dict(model.scales(q));states[c+q+'50_fixed']=l.with_prior(other,.5,model.p)
 states['plain_mean']={'kind':'Mean','p':model.p.copy()};return states

def select(train,L,query,parts,ti,fold,epochs=None,feature_fit=encoding.fit):
 epochs=tuple(epochs or l.EPOCHS);n,q=L.shape;assert sorted(np.concatenate(parts).tolist())==list(range(n));methods=['G','U','AA','Ridge','RKNN'];cv={m:{} for m in methods};params={m:{} for m in methods};mean=np.zeros((n,q));diagnostics=[];encoders=[];candidate_failures=[]
 for inner,held in enumerate(parts):
  fit=np.setdiff1d(np.arange(n),held);A,B,encoder,fp=feature_fit([train[i] for i in fit],[train[i] for i in held]);assert A.shape[0]==len(fit) and B.shape[0]==len(held);encoders.append({'inner':inner,'fit_positions':fit.tolist(),'query_positions':held.tolist(),'fingerprint':fp});D=L[fit];p=D.mean(0);mean[held]=p;P=tuple(range(A.shape[1]));model=r.CalibratedPrototypeModel(A,D,zeta=.5)
  def add(method,key,v,param):
   target=cv[method].setdefault(key,np.full((n,q),np.nan));params[method][key]=param
   try:r.valid(v,len(held),q)
   except ValueError as e:candidate_failures.append({'inner':inner,'method':method,'candidate':key,'message':str(e)});return
   target[held]=v
  for g in ['G','U']:
   vv,pp=l.proto_candidates(model,B,P,g)
   for key,v in vv.items():add(g,key,v,pp[key])
  for k in l.AA_KS:
   v=l.predict(l.aa_state(A,D,P,min(k,len(A))),B)
   for alpha in [0.,.5]:add('AA',f'k{k}_a{alpha}',(1-alpha)*v+alpha*p,{'k':k,'alpha':alpha})
  for lam in l.RIDGE_ALPHAS:
   v=l.predict(l.ridge_state(A,D,P,lam),B)
   for alpha in [0.,.5]:add('Ridge',f'lam{lam}_a{alpha}',(1-alpha)*v+alpha*p,{'lambda':lam,'alpha':alpha})
  for ai,anchor in enumerate(l.ANCHORS):
   seed=(202611181000+10000*ti+1000*fold+100*inner+ai)%(2**32);vv,ss,detail=l.rknn_checkpoints(A,D,B,P,anchor,seed,epochs);diagnostics.append({'inner':inner,'anchor':ai,**detail})
   for ep in epochs:
    for alpha in [0.,.5]:
     key=f'c{ai}_e{ep}_a{alpha}';param={'anchor':ai,'epoch':ep,'alpha':alpha};params['RKNN'][key]=param
     if ep in vv:add('RKNN',key,(1-alpha)*vv[ep]+alpha*p,param)
     else:cv['RKNN'].setdefault(key,np.full((n,q),np.nan))
 for method in methods:cv[method]['mean']=mean;params[method]['mean']={'kind':'Mean'}
 # Outer representation is separate from every inner encoder and fitted after CV.
 X,Q,encoder,outerfp=feature_fit(train,query);d=X.shape[1];P=tuple(range(d));rows=[];choices={}
 for method,values in cv.items():
  menu=[]
  for key,v in values.items():
   available=bool(np.isfinite(v).all());risk=float(np.square(v-L).sum(1).mean()) if available else None;row={'method':method,'id':key,'params':params[method][key],'available':available,'risk':risk};menu.append(row);rows.append(row)
  choices[method+'_min']=choose(menu,method,n,d,q)
 choices['G_atU']={**choices['U_min'],'selected_on':'U'};base=r.CalibratedPrototypeModel(X,L,zeta=.5);p=base.p;states={};outputs={};failures={};outerdiag=[]
 for policy in ['G_min','U_min','G_atU','AA_min','Ridge_min','RKNN_min']:
  param=choices[policy]['params']
  try:
   if param.get('kind')=='Mean':state={'kind':'Mean','p':p.copy()}
   else:
    if policy.startswith(('G_','U_')):state=l.prototype_state(base,P,'U' if policy=='U_min' else 'G',param['budget'],param['k'])
    elif policy=='AA_min':state=l.aa_state(X,L,P,min(param['k'],n))
    elif policy=='Ridge_min':state=l.ridge_state(X,L,P,param['lambda'])
    else:
     ai=param['anchor'];seed=(202611189000+10000*ti+1000*fold+ai)%(2**32);vv,ss,detail=l.rknn_checkpoints(X,L,Q,P,l.ANCHORS[ai],seed,(param['epoch'],));outerdiag.append({'anchor':ai,**detail})
     if param['epoch'] not in ss:raise FloatingPointError('Selected RKNN outer checkpoint unavailable')
     state=ss[param['epoch']]
    state=l.with_prior(state,param['alpha'],p)
   value=l.predict(state,Q);r.valid(value,len(query),q)
   if l.byte_count(state)!=resource('U' if policy=='U_min' else policy.split('_')[0],param,n,d,q):raise SystemExit('State byte formula mismatch')
   states[policy]=state;outputs[policy]=value
  except Exception as e:failures[policy]={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
 for key,st in fixed_states(base).items():
  try:v=l.predict(st,Q);r.valid(v,len(query),q);states[key]=st;outputs[key]=v
  except Exception as e:failures[key]={'type':type(e).__name__,'message':str(e)}
 assert len(outputs)+len(failures)==17
 for budget in [25,50,75,100]:assert l.byte_count(states['GG'+str(budget)+'_fixed'])==l.byte_count(states['UU'+str(budget)+'_fixed'])
 for key in ['GU50_fixed','UG50_fixed']:assert l.byte_count(states[key])==l.byte_count(states['GG50_fixed'])
 if 'G_atU' in states and 'U_min' in states:assert l.byte_count(states['G_atU'])==l.byte_count(states['U_min'])
 return {'outputs':outputs,'states':states,'encoder':encoder,'choices':choices,'cv_scores':rows,'cv':cv,'diagnostics':{'inner_models':diagnostics,'outer_models':outerdiag,'invalid_candidate_predictions':candidate_failures},'inner_encoders':encoders,'outer_fingerprint':outerfp,'failures':failures}

def state_bytes(st):
 meta={k:v for k,v in st.items() if not isinstance(v,np.ndarray)};f=io.BytesIO();np.savez_compressed(f,**l.arrays(st));return json.dumps(meta,sort_keys=True).encode(),f.getvalue()
