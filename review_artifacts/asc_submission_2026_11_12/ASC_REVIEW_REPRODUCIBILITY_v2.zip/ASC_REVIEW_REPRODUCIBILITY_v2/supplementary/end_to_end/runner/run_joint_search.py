"""Evaluate the frozen joint candidates with the original low-memory oracle."""
import argparse
from collections import Counter
import hashlib
from io import BytesIO
import json
from pathlib import Path
import platform
import sqlite3
import sys
import threading
from zipfile import ZipFile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def mask(selected):
    return sum(1 << i for i in selected)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original_run", type=Path)
    parser.add_argument("original_return", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--limit", type=int, help="Stop at this number of planned candidates; relaunch to resume.")
    parser.add_argument("--check", action="store_true", help="Validate the frozen inputs and candidate list without fitting.")
    args = parser.parse_args()
    protocol_path = Path(__file__).with_name("JOINT_SEARCH_PROTOCOL.json")
    plan = json.loads(protocol_path.read_text(encoding="utf-8"))
    root = args.original_run.resolve()
    original_protocol = root / "protocol.json"
    if sha(original_protocol) != plan["original_protocol_sha256"] or sha(args.original_return) != plan["archive_sha256"]:
        raise ValueError("Wrong original protocol or return archive")
    original = json.loads(original_protocol.read_text(encoding="utf-8"))
    sys.path.insert(0, str(root))
    import run_application as app
    import numpy as np

    identity = app.identity(original)
    features = np.load(root / "data/RESNET18_FEATURES.npy", allow_pickle=False)
    with np.load(root / "data/LABELS60_AND_SPLIT.npz", allow_pickle=False) as data:
        train_indices = data["train_indices"]
        labels = data["labels60"][train_indices]
    with ZipFile(args.original_return) as archive:
        prior = json.loads(archive.read("results/oracle_audit.json"))["rows"]
        frozen = json.loads(archive.read("results/selection_frozen.json"))
        original_reference = np.load(BytesIO(archive.read("results/Full_training_errors.npy")), allow_pickle=False)

    dimension = features.shape[1]
    assert features.dtype == np.float32 and list(features.shape) == original["feature_shape"]
    assert train_indices.tolist() == frozen["train_indices"] and labels.shape == (3300, 5)
    assert original_reference.shape == (3300,) and np.isfinite(original_reference).all()
    candidates = [tuple(sorted(set(range(dimension)) - set(row["deleted"]))) for row in plan["candidates"]]
    strata = Counter(dimension - len(candidate) for candidate in candidates)
    assert strata == dict(plan["strata_deleted_coordinates_and_counts"])
    masks = {mask(p) for p in candidates}
    assert len(masks) == len(candidates) == plan["candidate_budget"]
    excluded = {int(r["mask_hex"], 16) for r in prior}
    assert len(excluded) == plan["excluded_cached_masks"] and masks.isdisjoint(excluded)
    print("Verified original inputs and", len(candidates), "previously unqueried candidates", flush=True)
    if args.check:
        return

    args.output.mkdir(parents=True, exist_ok=True)
    app.ROOT = args.output.resolve()
    app.OUTPUT = app.ROOT
    limit = args.limit if args.limit is not None else len(candidates)
    if not 1 <= limit <= len(candidates):
        raise ValueError("Invalid candidate limit")
    for key in ("numpy", "scipy"):
        if identity[key] != frozen["identity"][key]:
            raise ValueError(f"{key} version must match the original environment")
    identity["joint_protocol_sha256"] = sha(protocol_path)
    identity["platform"] = platform.platform()
    lock = app.acquire_lock()
    stop = threading.Event()
    try:
        threading.Thread(target=app.heartbeat, args=(stop,), daemon=True).start()
        with sqlite3.connect(":memory:") as scratch:
            scratch.execute("CREATE TABLE errors (subset TEXT PRIMARY KEY, values_blob BLOB NOT NULL)")
            app.phase("Fitting original training geometry")
            model = app.LowMemoryTrainingGeometry(features[train_indices].astype(float), labels,
                                                  kinds=["numerical"] * dimension)
            app.phase("Replaying the full-feature reference")
            check = app.Oracle(model, labels, scratch)(tuple(range(dimension)))
            discrepancy = float(np.max(np.abs(check - original_reference)))
            if discrepancy > plan["reference_replay_atol"]:
                raise RuntimeError(f"Reference replay failed: {discrepancy:.16g}")
        database = app.open_database(identity)
        try:
            oracle = app.Oracle(model, labels, database)
            tolerance = plan["numeric_tolerance"]
            records = []
            for index, selected in enumerate(candidates[:limit], 1):
                app.PHASE = f"Candidate {index} of {limit}"
                error = oracle(selected)
                delta = error - original_reference
                record = {
                    "candidate": index,
                    "deleted": dimension - len(selected),
                    "bytes": 4 * len(train_indices) * len(selected),
                    "violations_at_zero": int(np.count_nonzero(delta > 0)),
                    "violations_at_numeric_tolerance": int(np.count_nonzero(error > original_reference + tolerance)),
                    "maximum_increase": max(0.0, float(delta.max())),
                    "errors_sha256": hashlib.sha256(error.astype("<f8").tobytes()).hexdigest(),
                }
                records.append(record)
                print("CHECKED", index, "of", limit, "violations", record["violations_at_numeric_tolerance"], flush=True)
            feasible = [row for row in records if row["violations_at_numeric_tolerance"] == 0]
            best = min(feasible, key=lambda row: (row["bytes"], row["candidate"]), default=None)
            app.save(app.OUTPUT / "JOINT_SEARCH_RESULTS.json", {
                "identity": identity, "reference_replay_max_abs_diff": discrepancy,
                "complete": limit == len(candidates), "tested": len(records),
                "best_at_numeric_tolerance": best, "rows": records,
            })
        finally:
            database.close()
    finally:
        stop.set()
        lock.close()


if __name__ == "__main__":
    main()
