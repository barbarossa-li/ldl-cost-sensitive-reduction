from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;p=json.loads((R/'RESULTS_PUBLIC.json').read_text());rows=p['family_summary'];families=sorted({r['family'] for r in rows});look={(r['family'],r['key']):r for r in rows}
fig,axes=plt.subplots(2,2,figsize=(11,7),layout='constrained')
for i,mask in enumerate(['Full','cost40']):
 for j,alpha in enumerate([0.,.5]):
  ax=axes[i,j]
  for method,label in [('geometric','Geometry-only hierarchy'),('lloyd','Old Lloyd (20 iterations)'),('kmeanspp','KMeans++ (10 starts)'),('bisecting','Standard bisecting (10 starts)')]:
   x=[];y=[]
   for pct in [25,50,75,100]:
    rr=[look[f,f'{mask}__G__{method}__{pct}__a{alpha}'] for f in families];x.append(100*np.mean([r['array_fraction'] for r in rr]));y.append(np.mean([r['brier'] for r in rr]))
   ax.plot(x,y,marker='o',label=label)
  ax.set_title(f'{mask}, G geometry, prior alpha={alpha}');ax.set_xlabel('Numerical predictor arrays (% of singleton)');ax.set_ylabel('Equal-family Brier');ax.grid(alpha=.25)
axes[0,0].legend(fontsize=8);fig.suptitle('E0.8 strong-baseline comparison: consulted training pools');fig.savefig(R/'strong_baseline_curves.png',dpi=170)
