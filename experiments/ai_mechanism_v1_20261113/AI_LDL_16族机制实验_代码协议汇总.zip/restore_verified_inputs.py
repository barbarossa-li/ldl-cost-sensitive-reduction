"""Restore authorized private raw caches without network requests."""
from pathlib import Path
import argparse,zipfile,json,hashlib,numpy as np
from scipy.io import loadmat
ap=argparse.ArgumentParser();ap.add_argument('--protocol',type=Path,required=True);ap.add_argument('--archives',type=Path,nargs='+',required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();p=json.loads(a.protocol.read_text());a.output.mkdir(parents=True,exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for f in p['families']:
 name=f['family'];paths=[a.output/f'{name}_{x}.npy' for x in ['X','L']]
 if all(q.exists() and sha(q)==f[x+'_sha256'] for x,q in zip(['X','L'],paths)):print('CACHE OK',name);continue
 dest=a.output/f'{name}.mat'
 if not dest.exists():
  for archive in a.archives:
   with zipfile.ZipFile(archive) as z:
    candidate=next((n for n in z.namelist() if Path(n).name==name+'.mat'),None)
    if candidate:
     raw=z.read(candidate);assert hashlib.sha256(raw).hexdigest()==f['mat_sha256'];dest.write_bytes(raw);break
 if not dest.exists():raise FileNotFoundError('Missing authorized cache for '+name)
 assert sha(dest)==f['mat_sha256'];m=loadmat(dest);X=np.asarray(m['features'],float);L=np.asarray(m['labels'],float);L=L/L.sum(1,keepdims=True)
 for x,values,path in zip(['X','L'],[X,L],paths):
  if path.exists():assert sha(path)==f[x+'_sha256']
  else:
   temp=path.with_suffix('.restore.npy');np.save(temp,values);assert sha(temp)==f[x+'_sha256'];temp.replace(path)
 print('RESTORED',name)
