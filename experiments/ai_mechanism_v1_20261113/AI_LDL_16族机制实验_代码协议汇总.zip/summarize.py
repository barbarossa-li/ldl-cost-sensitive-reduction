from pathlib import Path
import json,csv,statistics as st,hashlib,collections
import numpy as np
R=Path(__file__).resolve().parent;P=Path('/workspace/work/ai_mechanism_v1_private_20261113');M=Path('/workspace/work/ai_mechanism_v1_20261113');protocol=json.loads((M/'PROTOCOL.json').read_text());d=json.loads((P/'AGGREGATE_RESULTS_PUBLIC.json').read_text());rows=d['rows'];lookup={(r['family'],r['repeat'],r['mask'],r['weight'],r['target']):r for r in rows};assert len(lookup)==len(rows)==12560
pairs=[];families=[];budget_summary=[]
for f in protocol['families']:
 name=f['family'];casepairs=[]
 for repeat in range(1,6):
  s=json.loads((P/name/f'repeat_{repeat}'/'split_PRIVATE.json').read_text())
  for mask in s['masks']:
   def b(w,t):return lookup[(name,repeat,mask['name'],w,t)]['brier']
   result={'family':name,'repeat':repeat,'mask':mask['name'],'budget':mask['budget'],'bank':mask['bank'],'geometry':b('L','raw')-b('U','raw'),'grouping':b('L','ball')-b('L','covered_mean'),'grouping_random':b('L','ball')-b('L','random'),'grouping_global':b('L','ball')-b('L','global_mean'),'ball_raw':b('L','ball')-b('L','raw'),'interaction':(b('L','ball')-b('U','ball'))-(b('L','raw')-b('U','raw'))}
   for w in ['U','L']:
    for t in ['raw','ball','covered_mean','random','global_mean']:result[w+'_'+t]=b(w,t)
   pairs.append(result);casepairs.append(result)
 reduced=[r for r in casepairs if r['budget']<100];full=[r for r in casepairs if r['budget']==100];assert len(reduced)==60 and len(full)==5
 keys=[k for k in reduced[0] if k not in ['family','repeat','mask','budget','bank']]
 family={'family':name,'reduced_positions':60,'full_positions':5}
 for k in keys:family[k]=st.mean(r[k] for r in reduced);family['full_'+k]=st.mean(r[k] for r in full)
 families.append(family)
 for budget in [20,40,60,80,100]:
  group=[r for r in casepairs if r['budget']==budget];budget_summary.append({'family':name,'budget':budget,'positions':len(group),**{k:st.mean(r[k] for r in group) for k in keys}})
contrasts={}
for k in ['geometry','grouping','grouping_random','grouping_global','ball_raw','interaction']:
 values=[f[k] for f in families];contrasts[k]={'equal_family_mean':st.mean(values),'median':st.median(values),'families_negative':sum(v<0 for v in values),'families_positive':sum(v>0 for v in values),'families_zero':sum(v==0 for v in values),'min':min(values),'max':max(values)}
def writecsv(name,rr):
 with open(R/name,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
writecsv('paired_contrasts.csv',pairs);writecsv('family_summary.csv',families);writecsv('family_budget_summary.csv',budget_summary)
# Independent Brier audit at Full and one reduced mask per case, all controls.
checks=0;delta=0
for f in protocol['families']:
 name=f['family'];labels=np.load(Path('/workspace/work/asc_experiments/data')/f'{name}_L.npy',mmap_mode='r')
 for repeat in range(1,6):
  path=P/name/f'repeat_{repeat}';s=json.loads((path/'split_PRIVATE.json').read_text());y=labels[s['test_indices']];a=np.load(path/'predictions_PRIVATE.npz')
  for mask in [s['masks'][0],s['masks'][-1]]:
   for w in ['U','L']:
    raw=a[f"{mask['name']}__{w}__raw"]
    for t in ['raw','ball','covered_mean','random','global_mean','ball_endpoint']:
     target='ball' if t=='ball_endpoint' else t;alpha=1 if t=='ball_endpoint' else .5;pred=raw if t=='raw' else (1-alpha)*raw+alpha*a[f"{mask['name']}__{w}__{target}"];vs=list(pred) if pred.ndim==3 else [pred];brier=float(np.mean([np.einsum('ij,ij->i',v-y,v-y).mean() for v in vs]));diff=abs(brier-lookup[(name,repeat,mask['name'],w,t)]['brier']);delta=max(delta,diff);assert diff<1e-12;checks+=1
resources=[json.loads(p.read_text()) for p in P.rglob('record_PRIVATE.json')];result={'protocol_sha256':hashlib.sha256((M/'PROTOCOL.json').read_bytes()).hexdigest(),'families':16,'outer_cases':80,'mask_positions':1040,'aggregate_metric_rows':len(rows),'primary_unit':'one mean per feature family; repeats/banks/budgets are nested, not independent samples','contrasts':contrasts,'independent_brier_audit':{'comparisons':checks,'maximum_absolute_difference':delta,'passed':True},'total_case_wall_seconds_including_two_worker_contention':sum(r['wall_seconds'] for r in resources),'maximum_worker_peak_rss_bytes':max(r['worker_peak_rss_bytes'] for r in resources),'scope':'Fixed known-benchmark object-level mechanism study on random budget masks. Not external feature-selector superiority, subject-disjoint validation or untouched confirmation.','all_results_retained':True}
(R/'SUMMARY.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
