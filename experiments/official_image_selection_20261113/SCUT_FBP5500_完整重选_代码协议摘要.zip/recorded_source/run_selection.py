"""Official3300 full-to-fixed-reference O1 reselection with exact streamed geometry."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,time,datetime,json,hashlib,sqlite3,resource,platform
import numpy as np
from optimized import distances,granulate
ROOT=Path(__file__).resolve().parent;BASE=Path('/workspace/work/asc_experiments');CODE=Path('/workspace/work/asc_review/code_bundle')
sys.path.insert(0,str(CODE))
from information_reduction.formal_method import reduce_from_full

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for block in iter(lambda:f.read(2**20),b''):h.update(block)
 return h.hexdigest()
def save(p,x):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def protocol():
 sources=[ROOT/x for x in ['run_selection.py','optimized.py','distance.cpp','distance.so']]+[CODE/x for x in ['information_reduction/safe_extension.py','information_reduction/alternative_seeds.py','stability/fast_granulate.py','information_reduction/formal_method.py','information_reduction/sweep_search.py','information_reduction/local_preservation.py']]
 inputs=[BASE/'data/official_labels_split.npz',BASE/'data/official_resnet18_features.npy',ROOT/'fitted.npz',ROOT/'optimization_validation.json']
 return {'version':'SCUT-official3300-full-O1-20261113-v1','n_training':3300,'features':512,'costs':'All feature coordinates cost1, consistent with descriptor storage; no extraction-cost reduction claimed','split':'Official3300 training in published file order; existing2200 test; image extraction cache verified','reference':'Rebuild Full using original anchored safe extension, own fixed full per-object error; beta1,zeta.1,kappa.1,smin2,alpha1,eps_v0,eps_r0,pair_budget256,epsilon_safe1e-12,epsilon_rec1e-12','search':'Frozen reduce_from_full; complete cost-descending/index-tied deletion sweeps; no historical warm start, tolerances or test-based choices','implementation':'Numerical-only streamed same-order float64 distances; C++ -O3 -march=native -fopenmp -ffp-contract=off -fno-fast-math; no approximate arithmetic. Exact top256 pair ordering by cutoff partition then (-distance,i,j) lexsort; gates/anchor unchanged. Original and optimized full3300 distance and error vectors bitwise equal; small subset and tie tests recorded','cache':'Private fitted weights, normalized coordinates; immutable SQLite per-subset actual3300 float64 errors, transaction after each oracle. On restart replay frozen search from Full using hash-verified cached vectors. Not a time benchmark against prior platform','timings':'Individual distance/granulation wall and process CPU; RSS includes reused fitted arrays and recording overhead; original fit was separately measured in pilot, excluded from this search timing','evaluation':'Freeze final selection before recomputing new endpoint predictions. Existing image test results have already been inspected in earlier study; this is reproducibility/exploratory evidence, not untouched-test confirmation','limits':['No subject-disjoint assertion','No all-baseline or25-task rerun','Only final-selection and terminal-neighbor feasibility established; not global minimum'], 'source_sha256':{str(p):sha(p) for p in sources},'input_sha256':{str(p):sha(p) for p in inputs},'python':platform.python_version(),'numpy':np.__version__}

def run():
 record=protocol();path=ROOT/'SELECTION_PROTOCOL.json'
 if path.exists():assert json.loads(path.read_text())==record,'Frozen protocol mismatch'
 else:save(path,record)
 print('PROTOCOL FROZEN',sha(path),stamp(),flush=True)
 s=np.load(BASE/'data/official_labels_split.npz');train=s['train'];X=np.asarray(np.load(BASE/'data/official_resnet18_features.npy',mmap_mode='r')[train],float);L=s['labels'][train];f=np.load(ROOT/'fitted.npz');Z=f['Z'];W=f['W'];n,m=X.shape
 db=sqlite3.connect(ROOT/'selection_errors.sqlite');db.execute('create table if not exists vectors (subset text primary key,n integer,dtype text,sha256 text,errors blob,distance_seconds real,granulation_seconds real,cpu_seconds real,eligible_leaves integer,finished_at text)');db.execute('create table if not exists metadata (key text primary key,value text)')
 h=sha(path);old=db.execute("select value from metadata where key='protocol_sha256'").fetchone()
 if old:assert old[0]==h
 else:db.execute('insert into metadata values (?,?)',('protocol_sha256',h));db.commit()
 p=L.mean(0);calls=0
 def oracle(P):
  nonlocal calls
  P=tuple(sorted(P));key=json.dumps(P,separators=(',',':'));calls+=1
  cached=db.execute('select n,dtype,sha256,errors from vectors where subset=?',(key,)).fetchone()
  if cached:
   count,dtype,hashvalue,blob=cached;assert count==n and dtype=='<f8' and hashlib.sha256(blob).hexdigest()==hashvalue;return np.frombuffer(blob,dtype='<f8').copy()
  c=time.process_time();t=time.perf_counter();D=distances(Z,W,P);dt=time.perf_counter()-t;t=time.perf_counter()
  keys=[tuple(row[list(P)]) for row in X];g=granulate(D,L,keys);rec=np.tile(p,(n,1))
  for B in g[1]:rec[B]=L[B].mean(0)
  e=np.sum((L-rec)**2,axis=1);gt=time.perf_counter()-t;cpu=time.process_time()-c;blob=e.astype('<f8').tobytes()
  db.execute('insert into vectors values (?,?,?,?,?,?,?,?,?,?)',(key,n,'<f8',hashlib.sha256(blob).hexdigest(),blob,dt,gt,cpu,len(g[1]),stamp()));db.commit()
  count=db.execute('select count(*) from vectors').fetchone()[0]
  print('QUERY',count,'dimensions',len(P),'distance',round(dt,3),'granulate',round(gt,3),'mean',float(e.mean()),stamp(),flush=True)
  save(ROOT/'progress.json',{'protocol_sha256':h,'computed_queries':count,'last_dimensions':len(P),'last_error_sha256':hashlib.sha256(blob).hexdigest(),'timestamp':stamp(),'rss_peak_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024})
  return e
 start=time.perf_counter();cpu=time.process_time();v0=float(np.mean(np.sum((L-p)**2,axis=1)));res=reduce_from_full([1.]*m,oracle,v0);reference=oracle(range(m));final=oracle(res['selected']) if res['selected'] is not None else None
 if final is not None:assert np.all(final<=reference+1e-12)
 # Every distinct final deletion neighbor must have an actual stored vector;
 # successful final complete sweep supplies these without rerunning all queries.
 neighbors=[]
 if res['selected'] is not None:
  for a in res['selected']:
   e=oracle([b for b in res['selected'] if b!=a]);k=int(np.sum(e>reference+1e-12));assert k>0
   neighbors.append({'removed':a,'violated_objects':k,'maximum_error_increase':float(np.max(e-reference))})
 assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
 for count,dtype,hv,blob in db.execute('select n,dtype,sha256,errors from vectors'):
  assert count==n and dtype=='<f8' and len(blob)==8*n and hashlib.sha256(blob).hexdigest()==hv
 total=db.execute('select count(*) from vectors').fetchone()[0];db.close()
 np.savez_compressed(ROOT/'selection_endpoint_errors.npz',reference=reference,final=final if final is not None else np.empty(0))
 record={'protocol_sha256':h,'result':res,'reference_errors_sha256':hashlib.sha256(reference.astype('<f8').tobytes()).hexdigest(),'reference_matches_pilot_exactly':bool(np.array_equal(reference,np.load(ROOT/'reference.npy'))),'reference_mean_error':float(reference.mean()),'final_mean_error':None if final is None else float(final.mean()),'recorded_subsets':total,'recorded_float64_values':total*n,'final_neighbor_checks':neighbors,'session_search_wall_seconds':time.perf_counter()-start,'session_search_cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'errors_database_sha256':sha(ROOT/'selection_errors.sqlite'),'finished_at':stamp(),'test_labels_used_for_selection':False}
 save(ROOT/'SELECTION_FROZEN.json',record);print('FULL SELECTION FROZEN',res['status'],None if res['selected'] is None else len(res['selected']),stamp(),flush=True)
if __name__=='__main__':run()
