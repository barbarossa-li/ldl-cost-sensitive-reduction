from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np,json
from calibrated import CalibratedPrototypeModel,E0
from model import NumericalPrototypeModel
R=Path(__file__).resolve().parent;rng=np.random.default_rng(2026111302);X=rng.normal(size=(10,4));L=rng.dirichlet([1,1,1],10);old=NumericalPrototypeModel(X,L,k=3);original=CalibratedPrototypeModel(X,L,k=3,calibration='original');new=CalibratedPrototypeModel(X,L,k=3);checks=[]
for mask in range(16):
 P=tuple(i for i in range(4) if mask>>i&1)
 for mode in ['U','G','L']:
  assert np.array_equal(old.training_distances(P,mode),original.training_distances(P,mode));assert np.array_equal(old.predict_selected(X[:,P],P,mode),original.predict_selected(X[:,P],P,mode))
  D=new.directed_training(P,mode);assert np.max(np.abs(new.incoming_selected(X[:,P],P,mode).T-D))<1e-12
  assert np.all(D>=0) and np.max(D)<=1+1e-12
  full=new.directed_training(tuple(range(4)),mode);assert np.all(D<=full+1e-12)
checks.append('16 subsets ×3 weights: old route exact; calibrated source direction, positivity, fixed-Full range and subset monotonicity pass')
# Training geometry calibration must not depend on requested subset/order.
a=new.scales('L').copy();new.training_distances((1,3));assert a==new.scales('L');checks.append('Full-fitted scales remain fixed across subsets')
# Query batching and selected-only features remain valid.
Q=rng.normal(size=(7,2));P=(0,2);p=new.predict_selected(Q,P);assert np.array_equal(p,np.vstack([new.predict_selected(Q[i:i+1],P) for i in range(7)]));checks.append('Calibrated query batching and selected-only API pass')
# Zero-info and zero-geometry branches are distinct.
z=CalibratedPrototypeModel(np.arange(12.).reshape(6,2),np.tile([.5,.5],(6,1)),k=2);assert z.scales()['kind']=='zero_information_raw_fallback';assert np.isfinite(z.training_distances((0,1))).all()
c=CalibratedPrototypeModel(np.ones((6,2)),L[:6],k=2);assert c.scales()['kind']=='constant_geometry';assert np.array_equal(c.training_distances((0,1)),np.zeros((6,6)));checks.append('Exactly zero information and constant geometry branches pass')
# Uniform calibration is a positive scalar of raw L1, so generic neighbor order remains.
assert np.array_equal(new.neighbors(X[:,:2],(0,1),'U'),old.neighbors(X[:,:2],(0,1),'U'));checks.append('Uniform control neighbor order unchanged on nontied fixture')
(R/'CALIBRATION_CHECKS.json').write_text(json.dumps({'passed':True,'checks':checks,'scope':'Technical/algebraic fixtures, no real-data outcomes'},indent=2));print('Calibration checks PASS')
