from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
os.environ.setdefault('LDL_PARENT_SOURCE','/workspace/work/ai_external_v1_20261114/source')
import numpy as np,json,io
from selection import select,choose,resource
import learners as l,encoding
from design import TextFeatures

def main():
 from scipy.optimize import minimize
 for v in np.random.default_rng(75).normal(size=(4,3)):
  z=l.project(v[None,:])[0];ref=minimize(lambda x:np.sum((x-v)**2),np.ones(3)/3,method='SLSQP',bounds=[(0,1)]*3,constraints={'type':'eq','fun':lambda x:x.sum()-1},options={'ftol':1e-12});assert ref.success and np.linalg.norm(z-ref.x)<1e-6
 assert np.array_equal(l.project(np.array([[1e20,0.,-1e20]])),np.array([[1.,0.,0.]]))
 rng=np.random.default_rng(123);n=144;train=['shared text feature'+str(i//2)+' family'+str(i%7)+' category'+str(i%4)+(' specialfoldzero' if i<48 else '') for i in range(n)];Y=rng.dirichlet(np.ones(3),n);query=['shared category1 QUERYONLYNEVERFIT','family3 feature5'];parts=list(np.array_split(np.arange(n),3));calls=[]
 def fit(traintext,querytext):
  A,B,st,fp=encoding.fit(traintext,querytext);calls.append({'fit':list(traintext),'query':list(querytext),'vocab':dict(st['vocabulary'])});return A,B,st,fp
 a=select(train,Y,query,parts,0,0,epochs=(1,2),feature_fit=fit);assert len(calls)==4;assert len(calls[0]['fit'])==96 and 'specialfoldzero' not in calls[0]['vocab'];assert 'specialfoldzero' in calls[3]['vocab'];assert all('queryonlyneverfit' not in c['vocab'] for c in calls)
 for inner,c in enumerate(calls[:3]):assert set(c['fit'])=={train[i] for i in np.setdiff1d(np.arange(n),parts[inner])}
 
 if a['failures']:raise RuntimeError(json.dumps({'failures':a['failures'],'outputs':len(a['outputs']),'cv_scores':len(a['cv_scores'])}))
 assert len(a['outputs'])==17 and len(a['cv_scores'])==99
 em,en=encoding.dumps(a['encoder']);ee=json.loads(em);ea=np.load(io.BytesIO(en));decoded={'vocabulary':ee['vocabulary'],'idf':ea['idf'],'components':ea['components']};assert np.array_equal(encoding.transform(decoded,query),encoding.transform(a['encoder'],query))
 for key,st in a['states'].items():assert np.array_equal(l.predict(st,encoding.transform(a['encoder'],query)),a['outputs'][key])
 assert l.byte_count(a['states']['G_atU'])==l.byte_count(a['states']['U_min'])
 for key in ['GG50_fixed','UU50_fixed','GU50_fixed','UG50_fixed']:assert l.byte_count(a['states'][key])==l.byte_count(a['states']['GG50_fixed'])
 # Independent pooled-risk and tie/resource check of all selected candidates.
 for policy,row in a['choices'].items():
  method='U' if policy=='G_atU' else policy.split('_')[0];menu=[r for r in a['cv_scores'] if r['method']==method and r['available']];best=min(r['risk'] for r in menu);expected=min([r for r in menu if r['risk']<=best+1e-12],key=lambda r:(resource(method,r['params'],n,a['encoder']['components'].shape[0],3),r['id']));assert row['id']==expected['id']
 for method,vv in a['cv'].items():
  for key,v in vv.items():
   r=next(r for r in a['cv_scores'] if r['method']==method and r['id']==key)
   if r['available']:assert abs(np.square(v-Y).sum(1).mean()-r['risk'])<1e-12
 b=select(train,Y,query,parts,0,0,epochs=(1,2));assert a['choices']==b['choices']
 for key in a['outputs']:assert np.array_equal(a['outputs'][key],b['outputs'][key])
 print(json.dumps({'passed':True,'checks':['Translation-stabilized simplex projection agrees with independent constrained optimization and extreme-scale analytic result','Every inner text vocabulary/SVD fit uses exactly its own training rows','Held-fold canary excluded from its inner vocabulary but present in outer fit','Outer query-only token absent from every fitted vocabulary','Portable vocabulary+IDF+SVD state, including JSON/NPZ roundtrip, reproduces query transforms exactly','All17 standalone predictions reconstruct exactly; fixed CU and selected matched states have equal numeric bytes','All99 short-checkpoint synthetic CV scores and every selection checked independently','Complete short-epoch synthetic pipeline repeats bit-exactly'],'scope':'Synthetic tests only; epochs1/2 for toolkit execution checks. Real protocol remains100/500/1000 and105candidates. No new-task model fitting/scoring.'},indent=2))
if __name__=='__main__':main()
