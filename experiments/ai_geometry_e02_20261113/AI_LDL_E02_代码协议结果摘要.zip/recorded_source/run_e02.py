"""E0.2: predeclared small training-internal scale/shrinkage development probe."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import json,sys,hashlib,time,resource,datetime,subprocess,csv,statistics as st
import numpy as np
from calibrated import CalibratedPrototypeModel,E0
from model import CORE
from run_pilot import DATA,DATASETS,sha
from baseline_revision.prediction_evaluation import metrics,predict_five_neighbors
R=Path(__file__).resolve().parent
READOUTS=['raw','ball_residual','ball_global_legacy'];ALPHAS=[.25,.5,.75]
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)
def specs():
 a=[{'calibration':'original','zeta':.1,'weight':w,'null_index':-1} for w in ['U','G','L']]
 for z in [.1,.5,.9]:
  a += [{'calibration':'balanced','zeta':z,'weight':w,'null_index':-1} for w in ['U','G','L']]
  a += [{'calibration':'balanced','zeta':z,'weight':'S','null_index':i} for i in range(5)]
 return a

def prepare():
 assert json.loads((R/'CALIBRATION_CHECKS.json').read_text())['passed']
 src=[R/'calibrated.py',R/'check_calibration.py',R/'run_e02.py',E0/'model.py',E0/'run_pilot.py',CORE/'information_reduction/safe_extension.py',CORE/'information_reduction/alternative_seeds.py',CORE/'stability/fast_granulate.py',CORE/'baseline_revision/prediction_evaluation.py']
 inp=[DATA/f'{d}_{a}.npy' for d in DATASETS for a in ['X','L']]+[CORE/'expansion25/splits'/d/'repeat_1.json' for d in DATASETS]+[R/'CALIBRATION_CHECKS.json']
 p={'version':'AI-E0.2-calibration-development-v1','scope':'Already-consulted training-internal development folds only, repeat1 of three cached families; no new outer-test scoring or confirmatory inference','fold_cases':9,'families':DATASETS,'repeat':1,'folds':[0,1,2],'fit_n':128,'validation_n':64,'masks':['Full','same predetermined cost40 mask as E0'],'specifications':specs(),'null_seed':'202611130200+10000*dataset_index+100*fold+null_index','shrinkage':{'alphas':ALPHAS,'global':'(1-alpha)*raw + alpha*training_mean','ball':'(1-alpha)*raw + alpha*legacy_ball_global','report':'Report all strengths, no best-point selection claim'},'scheduled_metric_rows':4401,'prediction_schedule':'Freeze every base prediction before scoring; mixtures are deterministic declared functions of those frozen predictions and training mean','calibration':'I and G divided by their own training-Full off-diagonal means, then mixed by zeta and divided by training-Full maximum. All scales fixed across P and queries. Zero-info => normalized raw fallback; constant geometry => zero. This new geometry is distinct from old strict-O1 records.','source_hashes':{str(p):sha(p) for p in src},'input_hashes':{str(p):sha(p) for p in inp},'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 if (R/'PROTOCOL.json').exists():
  old=json.loads((R/'PROTOCOL.json').read_text());p['frozen_at']=old['frozen_at'];assert old==p
 else:save(R/'PROTOCOL.json',p)
 print('E0.2 PROTOCOL FROZEN',sha(R/'PROTOCOL.json'),flush=True)
def verify():
 p=json.loads((R/'PROTOCOL.json').read_text())
 for f,h in {**p['source_hashes'],**p['input_hashes']}.items():assert sha(f)==h,('identity changed',f)
 return p
def worker(dataset,fold):
 verify();out=R/'cases'/dataset/f'fold_{fold}';out.mkdir(parents=True,exist_ok=True)
 split=json.loads((CORE/'expansion25/splits'/dataset/'repeat_1.json').read_text());parent=np.array(split['train_indices']);v=np.array(split['fold_validation_positions'][fold]);fitpos=np.setdiff1d(np.arange(192),v);fit=parent[fitpos];val=parent[v]
 assert len(fit)==128 and len(val)==64 and set(fit).isdisjoint(val) and not(set(fit)|set(val))&set(split['test_indices'])
 Xall=np.load(DATA/f'{dataset}_X.npy',mmap_mode='r');Lall=np.load(DATA/f'{dataset}_L.npy',mmap_mode='r');X=Xall[fit];L=Lall[fit];Q=Xall[val];cost=np.array(split['costs']);seed=202611130000+1000*DATASETS.index(dataset)+100+fold;order=np.random.default_rng(seed).permutation(X.shape[1]);P40=tuple(sorted(map(int,order[np.cumsum(cost[order])<=.4*sum(cost)])));masks={'Full':tuple(range(X.shape[1])),'cost40':P40}
 models={};pred={};meta=[];c=time.process_time();t=time.perf_counter()
 for j,s in enumerate(specs()):
  key=(s['calibration'],s['zeta'])
  if key not in models:models[key]=CalibratedPrototypeModel(X,L,calibration=key[0],zeta=key[1])
  model=models[key];pi=None if s['null_index']<0 else np.random.default_rng(202611130200+10000*DATASETS.index(dataset)+100*fold+s['null_index']).permutation(128)
  for mask,P in masks.items():
   result=model.evaluate_selected(Q[:,P],P,s['weight'],permutation=pi);label=f'{mask}__g{j}';pred['neighbors__'+label]=result['neighbors']
   for r in READOUTS:pred['pred__'+label+'__'+r]=result['predictions'][r]
   scales=model.scales(s['weight'],pi) if s['calibration']=='balanced' else None
   meta.append({'id':label,'mask':mask,**s,**result['representation']['statistics'],'scales':scales,'actual_cost_percent':100*cost[list(P)].sum()/sum(cost),'attributes':len(P)})
 for mask,P in masks.items():pred['euclidean__'+mask]=predict_five_neighbors(X,L,Q,P)
 pred['mean']=np.tile(L.mean(0),(64,1));np.savez_compressed(out/'predictions.npz',**pred)
 # Old original route must still reproduce E0 exactly where private records exist.
 oldpath=E0/'cases'/dataset/'repeat_1'/f'fold_{fold}'/'predictions.npz';replay=None
 if oldpath.exists():
  old=np.load(oldpath);replay=True
  for j,w in enumerate(['U','G','L']):
   for mask in masks:
    for r in READOUTS:assert np.array_equal(pred[f'pred__{mask}__g{j}__{r}'],old[f'pred__{mask}__{w}__{r}'])
 save(out/'record.json',{'dataset':dataset,'fold':fold,'fit_indices':fit.tolist(),'validation_indices':val.tolist(),'protocol_sha256':sha(R/'PROTOCOL.json'),'predictions_sha256':sha(out/'predictions.npz'),'variants':meta,'old_e0_original_route_exact':replay,'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-c,'worker_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024});print('FROZEN CASE',dataset,fold,round(time.perf_counter()-t,2),flush=True)
def run():
 verify()
 for d in DATASETS:
  for fold in [0,1,2]:subprocess.run([sys.executable,str(Path(__file__).resolve()),'worker',d,str(fold)],check=True)
 files=[R/'cases'/d/f'fold_{f}'/'record.json' for d in DATASETS for f in [0,1,2]];save(R/'ALL_PREDICTIONS_FROZEN.json',{'protocol_sha256':sha(R/'PROTOCOL.json'),'records':{str(p.relative_to(R)):sha(p) for p in files}});print('ALL9 FROZEN',flush=True)
def score():
 verify();freeze=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());rows=[];agreement=[]
 for name,h in freeze['records'].items():
  p=R/name;assert sha(p)==h;c=json.loads(p.read_text());y=np.load(DATA/f"{c['dataset']}_L.npy",mmap_mode='r')[c['validation_indices']];a=np.load(p.parent/'predictions.npz');assert sha(p.parent/'predictions.npz')==c['predictions_sha256']
  for v in c['variants']:
   label=v['id'];base={r:a['pred__'+label+'__'+r] for r in READOUTS};values=base.copy()
   for alpha in ALPHAS:
    values[f'mean_shrink_{alpha}']=(1-alpha)*base['raw']+alpha*a['mean'];values[f'ball_shrink_{alpha}']=(1-alpha)*base['raw']+alpha*base['ball_global_legacy']
   for readout,value in values.items():rows.append({'dataset':c['dataset'],'fold':c['fold'],**{k:v[k] for k in ['mask','calibration','zeta','weight','null_index','coverage','prototype_slots_residual','attributes','actual_cost_percent']},'readout':readout,**metrics(y,value)})
   if v['weight']=='L':
    peers=next(t for t in c['variants'] if (t['mask'],t['calibration'],t['zeta'],t['weight'])==(v['mask'],v['calibration'],v['zeta'],'U'));U=np.sort(a['neighbors__'+peers['id']],axis=1);Lids=np.sort(a['neighbors__'+label],axis=1);agreement.append({'dataset':c['dataset'],'fold':c['fold'],'mask':v['mask'],'calibration':v['calibration'],'zeta':v['zeta'],'same_neighbor_set_fraction':float(np.mean(np.all(U==Lids,axis=1)))})
  for mask in ['Full','cost40']:rows.append({'dataset':c['dataset'],'fold':c['fold'],'mask':mask,'calibration':'euclidean','zeta':None,'weight':'E','null_index':-1,'readout':'raw',**metrics(y,a['euclidean__'+mask])})
  rows.append({'dataset':c['dataset'],'fold':c['fold'],'mask':'none','calibration':'mean','zeta':None,'weight':'none','null_index':-1,'readout':'mean',**metrics(y,a['mean'])})
 assert len(rows)==4401
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with (R/'metrics.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 group={}
 for row in rows:
  k=tuple(row.get(x) for x in ['dataset','mask','calibration','zeta','weight','readout']);group.setdefault(k,[]).append(row)
 summary=[]
 for key,block in group.items():summary.append({**dict(zip(['dataset','mask','calibration','zeta','weight','readout'],key)),'fold_or_null_records':len(block),**{m+'_mean':st.mean(r[m] for r in block) for m in ['brier','tv','kl','js']}})
 save(R/'RESULTS.json',{'scope':'9 consulted training-internal development folds; no outer-test scores, no significance tests or best-zeta claim','metric_rows':len(rows),'summary':summary,'neighbor_agreement':agreement,'all_original_e0_routes_exact':all(json.loads((R/name).read_text())['old_e0_original_route_exact'] for name in freeze['records']),'outer_test_scored':False});print('SCORED 4401 INTERNAL DEVELOPMENT ROWS',flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='run':run()
 elif sys.argv[1]=='worker':worker(sys.argv[2],int(sys.argv[3]))
 elif sys.argv[1]=='score':score()
