from pathlib import Path
import argparse,os,shutil,sys,subprocess,json,hashlib
B=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--run',action='store_true');a=p.parse_args();data=a.data.resolve();out=a.output.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Use a new empty output directory')
expected=json.loads((B/'records/E0_PROTOCOL.json').read_text())['input_hashes']
for path,hashvalue in expected.items():
 if not path.endswith('.npy'):continue
 local=data/Path(path).name
 if hashlib.sha256(local.read_bytes()).hexdigest()!=hashvalue:raise SystemExit('Cached array mismatch: '+str(local))
out.mkdir(parents=True,exist_ok=True)
for p in (B/'recorded_source').glob('*.py'):
 text=p.read_text().replace('/workspace/work/asc_experiments/data',str(data));(out/p.name).write_text(text)
env=os.environ.copy();env['AI_LDL_CORE']=str(B/'frozen_core');env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
(out/'LOCAL_BINDINGS.json').write_text(json.dumps({'core':env['AI_LDL_CORE'],'data':str(data)},indent=2))
if not a.run:print('Prepared',out);raise SystemExit(0)
def run(*args):subprocess.run([sys.executable,*map(str,args)],cwd=out,env=env,check=True)
run(out/'check_interface.py');run(out/'run_pilot.py','prepare');run(out/'run_pilot.py','run');run(out/'score_pilot.py')
ref=json.loads((B/'records/PILOT_RESULTS.json').read_text())['summary'];actual=json.loads((out/'PILOT_RESULTS.json').read_text())['summary'];key=lambda r:(r['dataset'],r['mask'],r['weight'],r['readout']);lookup={key(r):r for r in actual};assert len(actual)==len(ref)==60;differences=[]
for row in ref:
 other=lookup[key(row)]
 for metric in ['brier_mean','tv_mean','kl_mean','js_mean']:differences.append(abs(row[metric]-other[metric]))
maximum=max(differences);assert maximum<=1e-12
(out/'PORTABLE_COMPARISON.json').write_text(json.dumps({'summary_rows':60,'metrics_compared':240,'maximum_absolute_difference':maximum,'scope':'Artifact reproduction; not additional independent data evidence'},indent=2));print('Portable reproduction exact/tolerance check passed:',maximum)
