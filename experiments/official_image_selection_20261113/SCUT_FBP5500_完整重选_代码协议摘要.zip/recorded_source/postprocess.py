"""Post-selection audit and held-out scoring. Does not change selections."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np,json,hashlib,sqlite3,sys,time,csv
ROOT=Path(__file__).resolve().parent;BASE=Path('/workspace/work/asc_experiments');CODE=Path('/workspace/work/asc_review/code_bundle');sys.path.insert(0,str(CODE))
from baseline_revision.prediction_evaluation import predict_five_neighbors,metrics
from optimized import distances,granulate,original_safe

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def run():
 frozen=json.loads((ROOT/'SELECTION_FROZEN.json').read_text());protocol=json.loads((ROOT/'SELECTION_PROTOCOL.json').read_text());assert sha(ROOT/'SELECTION_PROTOCOL.json')==frozen['protocol_sha256']
 for p,h in protocol['source_sha256'].items():assert sha(p)==h
 assert frozen['errors_database_sha256']==sha(ROOT/'selection_errors.sqlite')
 s=np.load(BASE/'data/official_labels_split.npz');train=s['train'];test=s['test'];allX=np.load(BASE/'data/official_resnet18_features.npy');X=np.asarray(allX[train],float);L=s['labels'][train];reference=np.load(ROOT/'reference.npy');db=sqlite3.connect(ROOT/'selection_errors.sqlite')
 assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
 rows=[];vectors={}
 for sub,n,dtype,h,blob,dt,gt,cpu,leaves,finished in db.execute('select * from vectors'):
  P=tuple(json.loads(sub));assert n==3300 and dtype=='<f8' and hashlib.sha256(blob).hexdigest()==h;e=np.frombuffer(blob,'<f8').copy();assert np.isfinite(e).all() and np.min(e)>=0;vectors[P]=e
  removed=[j for j in range(512) if j not in P]
  rows.append({'attributes':len(P),'removed':','.join(map(str,removed)),'mean_error':float(e.mean()),'violated_objects':int(np.sum(e>reference+1e-12)),'maximum_error_increase':float(np.max(e-reference)),'distance_seconds':dt,'granulation_seconds':gt,'cpu_seconds':cpu,'eligible_leaves':leaves,'error_sha256':h})
 selected=frozen['result']['selected'];final=vectors[tuple(selected)];assert np.all(final<=reference+1e-12)
 for a in selected:assert np.any(vectors[tuple(b for b in selected if b!=a)]>reference+1e-12)
 with (ROOT/'query_summary.csv').open('w') as out:
  w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(sorted(rows,key=lambda r:(-r['attributes'],r['removed'])))
 # Original unoptimized alternative-pair ordering independently re-evaluates
 # two predeclared first/last-coordinate deletion candidates after freeze.
 f=np.load(ROOT/'fitted.npz');rechecks=[]
 for removed in [0,511]:
  P=tuple(a for a in range(512) if a!=removed)
  if P not in vectors:continue
  t=time.perf_counter();D=distances(f['Z'],f['W'],P);keys=[tuple(row[list(P)]) for row in X];g=original_safe(D,L,keys);rec=np.tile(L.mean(0),(len(L),1))
  for leaf in g[1]:rec[leaf]=L[leaf].mean(0)
  e=np.sum((L-rec)**2,axis=1);equal=bool(np.array_equal(e,vectors[P]));assert equal
  rechecks.append({'removed':removed,'original_sort_error_exact':equal,'seconds':time.perf_counter()-t})
 prediction=predict_five_neighbors(allX[train],s['labels'][train],allX[test],selected);np.save(ROOT/'selected_test_predictions.npy',prediction);score=metrics(s['labels'][test],prediction)
 full_prediction=predict_five_neighbors(allX[train],s['labels'][train],allX[test],list(range(512)));full_score=metrics(s['labels'][test],full_prediction)
 report={'selection_frozen_sha256':sha(ROOT/'SELECTION_FROZEN.json'),'postprocessor_sha256':sha(Path(__file__)),'selected_attributes':len(selected),'retained_cost_percent':100*len(selected)/512,'selected_test_metrics':score,'full_test_metrics':full_score,'selected_predictions_equal_full':bool(np.array_equal(prediction,full_prediction)),'recorded_subsets':len(rows),'float64_error_values':len(rows)*3300,'all_vector_hashes_and_database_valid':True,'terminal_single_deletion_irreducible':True,'independent_original_pair_sort_rechecks':rechecks,'sum_recorded_distance_seconds':sum(r['distance_seconds'] for r in rows),'sum_recorded_granulation_seconds':sum(r['granulation_seconds'] for r in rows),'sum_recorded_cpu_seconds':sum(r['cpu_seconds'] for r in rows),'peak_process_rss_bytes':frozen['peak_rss_bytes'],'query_summary_sha256':sha(ROOT/'query_summary.csv'),'test_predictions_sha256':sha(ROOT/'selected_test_predictions.npy'),'disclaimer':'Known official split and previously inspected test results. Fresh full selection from Full; not independent confirmatory or subject-disjoint evidence. Unit coordinate costs/storage, not image extraction savings.'}
 save(ROOT/'FINAL_RESULTS.json',report);print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':run()
