from pathlib import Path
import json,zipfile,hashlib,sys
import numpy as np
from scipy.io import loadmat
R=Path(__file__).resolve().parent;ROOT=R.parents[1];CODE=ROOT/'LDL_25_Expanded_Run';sys.path.insert(0,str(CODE))
from baseline_revision.prediction_evaluation import predict_five_neighbors,metrics
z=zipfile.ZipFile(ROOT.parent/'upload/M3_RESULTS_RETURN.zip');prefix='reviewer_response/m3_scale/';plan=json.loads(z.read(prefix+'protocol.json'));cache={};maximum=0.;count=0
for c in plan['cases']:
 ds=c['dataset'];rep=c['repeat'];n=c['training_size']
 if ds not in cache:
  p=ROOT/'reviewer_response'/('joint_families' if ds=='Human_Gene' else 'm1_m2')/'inputs'/ds/'source.mat';assert hashlib.sha256(p.read_bytes()).hexdigest()==c['source']['mat_sha256'];d=loadmat(p);x=np.asarray(d['features'],float);l=np.asarray(d['labels'],float);l=l/l.sum(1,keepdims=True);cache[ds]=x,l
 x,l=cache[ds];f=json.loads(z.read(prefix+f'results/{ds}_{rep}_n{n}/selection_frozen.json'));e=json.loads(z.read(prefix+f'results/{ds}_{rep}_n{n}/evaluation.json'));ids=c['training_indices'];test=c['test_indices']
 for row in e['rows']:
  selected=f['records'][row['method']]['selected'];computed=metrics(l[test],predict_five_neighbors(x[ids],l[ids],x[test],selected))
  for k,v in computed.items():difference=abs(v-row[k]);maximum=max(maximum,difference);assert difference<=1e-12,(ds,rep,n,row['method'],k,difference)
  count+=1
v=json.loads((R/'validation.json').read_text());v.update(independent_prediction_recomputations=count,maximum_metric_absolute_difference=maximum,prediction_recompute_tolerance=1e-12);(R/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print('Independent predictor check',count,'outputs; max delta',maximum)
