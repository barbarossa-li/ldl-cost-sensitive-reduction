import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json
import numpy as np
from scipy.special import softmax
from audit import sha,recompute
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--parent',type=Path,required=True);p.add_argument('--known-data',type=Path,required=True);p.add_argument('--novel-data',type=Path,required=True);a=p.parse_args();fr=json.loads((a.run/'ALL_PREDICTIONS_FROZEN.json').read_text());res=json.loads((a.run/'RESULTS_PUBLIC.json').read_text());assert len(fr['records'])==53 and len(res['rows'])==212;lookup={(r['stage'],r['family'],r['fold'],r['key']):r for r in res['rows']};count=standalone=oldexact=converged=0;maxerr={k:0. for k in ['brier','chebyshev','clark','canberra','kl','cosine','intersection']};maxobj=-float('inf')
for name,h in fr['records'].items():
 file=a.run/name;assert sha(file)==h;rec=json.loads(file.read_text());oldfile=a.parent/name;old=json.loads(oldfile.read_text());pf=file.parent/'predictions_PRIVATE.npz';sf=file.parent/'inference_state_PRIVATE.npz';assert sha(pf)==rec['predictions_sha256'] and sha(sf)==rec['inference_state_sha256']
 for field in ['fit_indices','validation_indices','excluded_original_test_indices']:assert rec[field]==old[field]
 folder=a.known_data if rec['stage']=='e11' else a.novel_data;X=np.load(folder/(rec['family']+'_X.npy'),mmap_mode='r');L=np.load(folder/(rec['family']+'_L.npy'),mmap_mode='r');Q=X[rec['validation_indices']];y=L[rec['validation_indices']]
 with np.load(pf) as arr,np.load(sf) as state,np.load(oldfile.parent/'predictions_PRIVATE.npz') as prior:
  for mask,d in rec['diagnostics'].items():
   W=state[mask+'__W'];P=state[mask+'__P'];lo=state[mask+'__lo'];span=state[mask+'__span'];mean=state[mask+'__prior'];A=Q[:,P];B=np.divide(A-lo,span,out=np.zeros_like(A),where=span>0);v=softmax(B@W,axis=1);rawbytes=sum(z.nbytes for z in [W,P,lo,span]);assert rawbytes==d['native_array_bytes']==8*(len(P)*y.shape[1]+3*len(P));assert rawbytes+mean.nbytes==d['half_prior_array_bytes'];assert np.array_equal(mean,L[rec['fit_indices']].mean(0));assert d['optimizer']['objective']<=d['old_optimizer']['objective']+max(1e-8,abs(d['old_optimizer']['objective'])*1e-10);maxobj=max(maxobj,d['optimizer']['objective']-d['old_optimizer']['objective']);converged+=int(d['optimizer']['success'])
   for label,expected in [('native',v),('half_prior',.5*v+.5*mean)]:
    key=f'{mask}__SABFGS20000__{label}';pred=arr[key];assert np.array_equal(pred,expected);standalone+=1;row=lookup[rec['stage'],rec['family'],rec['fold'],key]
    for metric,value in recompute(y,pred).items():
     err=abs(value-row[metric]);assert err<1e-11;maxerr[metric]=max(maxerr[metric],err)
    count+=1
   if d['old_optimizer']['success']:assert np.array_equal(arr[mask+'__SABFGS20000__native'],prior[mask+'__SABFGS']);oldexact+=1
assert count==212
print(json.dumps({'passed':True,'cases':53,'fitted_mask_models':106,'converged':converged,'still_nonconverged':106-converged,'metric_rows':count,'metric_values_checked':count*7,'max_absolute_metric_error':maxerr,'exact_standalone_state_predictions':standalone,'already_converged_native_exact_replays':oldexact,'maximum_training_objective_change':maxobj,'scope':'Post-outcome numericaldiagnostic,notnewconfirmation'},indent=2))
