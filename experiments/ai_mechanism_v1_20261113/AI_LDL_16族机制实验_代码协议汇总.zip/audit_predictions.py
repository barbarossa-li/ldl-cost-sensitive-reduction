from pathlib import Path
import json,hashlib,numpy as np
R=Path(__file__).resolve().parent;P=Path('/workspace/work/ai_mechanism_v1_private_20261113');D=Path('/workspace/work/asc_experiments/data');M=Path('/workspace/work/ai_mechanism_v1_20261113');ph=hashlib.sha256((M/'PROTOCOL.json').read_bytes()).hexdigest();f=json.loads((P/'ALL_80_PREDICTIONS_FROZEN.json').read_text());assert f['protocol_sha256']==ph and len(f['records'])==80
arrays=0;cases=[]
for name,h in f['records'].items():
 p=P/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;c=json.loads(p.read_text());s=json.loads((p.parent/'split_PRIVATE.json').read_text());assert set(s['train_indices']).isdisjoint(s['test_indices']);assert len(c['statistics'])==26
 assert hashlib.sha256((p.parent/'predictions_PRIVATE.npz').read_bytes()).hexdigest()==c['prediction_sha256'];a=np.load(p.parent/'predictions_PRIVATE.npz');L=np.load(D/f"{c['family']}_L.npy",mmap_mode='r');mean=L[s['train_indices']].mean(0)
 assert np.array_equal(a['plain_mean'],np.tile(mean,(len(s['test_indices']),1)))
 for k in a.files:
  v=a[k];assert v.shape[-2:]==(len(s['test_indices']),L.shape[1]);assert np.isfinite(v).all() and (v>=0).all() and np.allclose(v.sum(-1),1,rtol=0,atol=2e-12)
  if k.endswith('__random'):assert v.shape[0]==5
  arrays+=1
 cases.append({'family':c['family'],'repeat':c['repeat'],'arrays':len(a.files),'test_n':len(s['test_indices'])})
result={'passed':True,'protocol_sha256':ph,'cases':80,'prediction_arrays_checked':arrays,'test_labels_used_for_this_audit':False,'checks':['all80 frozen record/prediction hashes','source split disjointness','probability simplex and dimensions','exact training-only mean fallback','five random seeds retained','26 mask/geometry statistics per case'],'case_counts':cases};(R/'PREDICTION_AUDIT.json').write_text(json.dumps(result,indent=2));print('Prediction integrity PASS',arrays)
