"""Synthetic engineering scaling probe, not a dataset performance experiment."""
from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,time,resource,numpy as np
from model import NumericalPrototypeModel
R=Path(__file__).resolve().parent

def run(n,m,q):
 rng=np.random.default_rng(202611130000+n+m+q);X=rng.normal(size=(n,m));L=rng.dirichlet(np.ones(q),n);query=rng.normal(size=(128,m));t=time.perf_counter();c=time.process_time();model=NumericalPrototypeModel(X,L);fitwall=time.perf_counter()-t;fitcpu=time.process_time()-c
 t=time.perf_counter();c=time.process_time();out=model.evaluate_selected(query,tuple(range(m)));evaluatewall=time.perf_counter()-t;evaluatecpu=time.process_time()-c
 for v in out['predictions'].values():assert np.allclose(v.sum(1),1,atol=1e-12) and np.isfinite(v).all()
 record={'n':n,'m':m,'q':q,'queries':128,'fit_wall_seconds':fitwall,'fit_cpu_seconds':fitcpu,'one_full_L_representation_and_all_readouts_wall_seconds':evaluatewall,'one_full_L_representation_and_all_readouts_cpu_seconds':evaluatecpu,'peak_process_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'scope':'Synthetic CPU/memory capacity probe, NumPy streamed fitting; no predictive accuracy estimate and no cross-method speed comparison.'}
 (R/'resources').mkdir(exist_ok=True);(R/'resources'/f'n{n}_m{m}_q{q}.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
