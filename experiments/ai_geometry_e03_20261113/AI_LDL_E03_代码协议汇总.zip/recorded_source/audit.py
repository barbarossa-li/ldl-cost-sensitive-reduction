from pathlib import Path
import json,sys,hashlib,numpy as np
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));from run import DATA,DATASETS,ZS,AS,TARGETS,mixed,expected_loss,choose,sha
count=0
for path in sorted((R/'cases').rglob('record.json')):
 c=json.loads(path.read_text());fit=np.array(c['fit_indices']);val=np.array(c['validation_indices']);assert len(set(fit))==128 and len(set(val))==64 and not set(fit)&set(val)
 folds=[np.array(x) for x in c['inner_validation_positions']];assert sorted(np.concatenate(folds).tolist())==list(range(128))
 a=np.load(path.parent/'inner_predictions.npz');L=np.load(DATA/f"{c['dataset']}_L.npy",mmap_mode='r')[fit]
 for row in c['inner_scores']:
  total=0
  for j,iv in enumerate(folds):
   b={t:a[f"{j}_{row['zeta']}_{row['weight']}_{row['mask']}_{t}"] for t in TARGETS};total+=len(iv)*expected_loss(L[iv],mixed(b,row['target'],row['alpha']))
  assert abs(total/128-row['brier'])<1e-15;count+=1
 for choice in c['choices']:
  candidates=[r for r in c['inner_scores'] if all(r[k]==choice[k] for k in ['weight','mask','target'])];assert choose(candidates)==choice
 # Pairing must use the same raw neighbor output: alpha=0 is identical for all targets/seeds.
 for z in ZS:
  for w in ['U','L']:
   for mask in ['Full','cost40']:
    b={t:a[f'0_{z}_{w}_{mask}_{t}'] for t in TARGETS}
    for t in TARGETS:
     p=mixed(b,t,0.);assert np.all(p==b['raw'])
result={'passed':True,'recomputed_inner_grid_scores':count,'fold_cases':9,'fold_partition_and_disjointness':True,'choices_recomputed_exactly':True,'zero_alpha_controls_equal_raw':True,'outer_test_scored':False,'scope':'Audit of saved development artifacts, not additional independent evidence'}
(R/'AUDIT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
