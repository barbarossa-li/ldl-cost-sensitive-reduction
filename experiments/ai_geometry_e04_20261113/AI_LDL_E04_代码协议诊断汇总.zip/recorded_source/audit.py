from pathlib import Path
import json,hashlib,sys,numpy as np
from candidate import ShapeWeightedModel
import run
R=Path(__file__).resolve().parent;p=json.loads((R/'PROTOCOL.json').read_text());frozen=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());records={};compared=0;delta=0;results=json.loads((R/'RESULTS.json').read_text());look={(r['family'],r['fold'],r['mask'],r['mode'],r['target']):r['brier'] for r in results['rows']}
for name,h in p['input_hashes'].items():assert run.sha(name)==h
for name,h in frozen['records'].items():
 q=R/name;assert run.sha(q)==h;c=json.loads(q.read_text());assert run.sha(q.parent/'predictions_PRIVATE.npz')==c['predictions_sha256'];a=np.load(q.parent/'predictions_PRIVATE.npz');assert set(c['fit_indices']).isdisjoint(c['validation_indices']);parent=json.loads((run.PRIVATE/c['family']/'repeat_1/split_PRIVATE.json').read_text());assert not(set(c['fit_indices'])|set(c['validation_indices']))&set(parent['test_indices'])
 L=np.load(run.D/f"{c['family']}_L.npy",mmap_mode='r');y=L[c['validation_indices']]
 for key in a.files:
  v=a[key];assert np.isfinite(v).all() and (v>=0).all() and np.allclose(v.sum(-1),1,rtol=0,atol=2e-12);vs=list(v) if v.ndim==3 else [v];score=np.mean([np.einsum('ij,ij->i',x-y,x-y).mean() for x in vs]);mask,mode,target=key.split('__') if key!='plain_mean' else ('NA','NA','plain_mean');diff=abs(score-look[(c['family'],c['fold'],mask,mode,target)]);assert diff<1e-12;delta=max(delta,diff);compared+=1
 records[(c['family'],c['fold'])]=c
# Verify the smoothing-energy identity and bound on six actual fitted representations.
c=records[('Natural_Scene',0)];L=np.load(run.D/'Natural_Scene_L.npy')[c['fit_indices']];X=np.load(run.D/'Natural_Scene_X.npy')[c['fit_indices']];m=ShapeWeightedModel(X,L,zeta=.5);parent=json.loads((run.PRIVATE/'Natural_Scene/repeat_1/split_PRIVATE.json').read_text());P40=tuple(next(x['indices'] for x in parent['masks'] if x['name']=='b0_c40'));v0=float(np.square(L-L.mean(0)).sum(1).mean());identity=[]
for P in [tuple(range(m.m)),P40]:
 for mode in ['U','L','N']:
  r=m.representation(P,mode);energy=float(np.square(r['ball_residual']-L).sum(1).mean());rhs=0
  for group in r['accepted']:
   dispersion=float(np.square(L[list(group)]-L[list(group)].mean(0)).sum(1).mean());assert dispersion<=m.settings['kappa']*v0+1e-12;rhs+=len(group)*dispersion/m.n
  bound=m.settings['kappa']*v0*r['statistics']['coverage'];assert abs(energy-rhs)<1e-14 and energy<=bound+1e-12;identity.append({'mode':mode,'attributes':len(P),'train_shift_energy':energy,'identity_rhs':rhs,'bound':bound})
# Actual imported modules match their pinned archived copies.
transitive={}
for name,rel in [('model','e0/model.py'),('calibrated','e02/calibrated.py'),('controls','e03/controls.py')]:
 live=Path(sys.modules[name].__file__);archived=run.M/'dependencies'/rel;assert run.sha(live)==run.sha(archived);transitive[name]=run.sha(live)
out={'passed':True,'cases':48,'all_input_hashes_reverified':True,'independent_brier_values':compared,'maximum_brier_difference':delta,'new_outer_test_rows_accessed':False,'sampled_actual_energy_identity_and_bound':identity,'transitive_dependency_hash_matches':transitive,'scope':'Development artifact audit, not new independent evidence'};run.save(R/'AUDIT.json',out);print(json.dumps({k:v for k,v in out.items() if k not in ['sampled_actual_energy_identity_and_bound','transitive_dependency_hash_matches']},indent=2))
