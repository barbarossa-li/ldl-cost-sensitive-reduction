"""Check the existing eight-object figure against the frozen implementation.

Usage: python check_synthetic_example.py /path/to/extracted/LDL_25_Expanded_Run
The implementation is the verified payload in local_runner/BOOTSTRAP_25.py.
This command does not overwrite a plot or run feature selection.
"""
from pathlib import Path
import sys
import numpy as np
if len(sys.argv)!=2:
    raise SystemExit(__doc__)
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from granulation_reference import TrainingGeometry, granulate
rows=np.loadtxt(Path(__file__).parent/'figures/negative_gain_construction.csv',delimiter=',',skiprows=1)
X=rows[:,:2].astype(int);labels=rows[:,2:]
geometry=TrainingGeometry(X,labels)
for subset,value in zip(((0,),(0,1)),(0.0922402760947,0.0)):
    distances,keys=geometry.subset(subset)
    leaves,eligible,gamma,_=granulate(distances,labels,keys)
    assert np.isclose(gamma,value,rtol=0,atol=1e-12)
    print({'subset':subset,'gamma':gamma,'leaves':leaves,'eligible':eligible})
print('Existing synthetic figure dependency values: PASS')
