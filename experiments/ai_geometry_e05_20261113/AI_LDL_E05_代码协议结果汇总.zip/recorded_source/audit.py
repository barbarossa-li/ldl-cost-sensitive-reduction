from pathlib import Path
import sys,json,numpy as np
import run
from prototype import PrototypePredictor,groups_from_representation
R=Path(__file__).resolve().parent;p=run.verify();frozen=json.loads((R/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(frozen['records'])==48
for name,h in p['input_hashes'].items():assert run.sha(name)==h
checked=0;nullcases=0
for name,h in frozen['records'].items():
 path=R/name;assert run.sha(path)==h;c=json.loads(path.read_text());assert run.sha(path.parent/'predictions_PRIVATE.npz')==c['predictions_sha256'];s=json.loads((run.PRIVATE/c['family']/'repeat_1/split_PRIVATE.json').read_text());assert not(set(c['fit_indices'])|set(c['validation_indices']))&set(s['test_indices']);a=np.load(path.parent/'predictions_PRIVATE.npz');assert len(a.files)==37
 for k in a.files:
  v=a[k];assert np.isfinite(v).all() and (v>=0).all() and np.allclose(v.sum(-1),1,rtol=0,atol=2e-12);checked+=1
 for t in c['statistics']:
  groups=t['accepted_groups'];assert sorted(i for B in groups for i in B)==list(range(c['n_fit']));assert sum(len(B) for B,f in zip(groups,t['accepted_flags']) if f)==round(t['coverage']*c['n_fit']);assert t['prototype_slots']==len(groups)
  prefix=t['mask']+'__'+t['geometry']+'__'
  if t['coverage']==0:
   nullcases+=1
   for method in ['direct_ball_uniform','direct_ball_mass','direct_mean_uniform','direct_mean_mass']:assert np.array_equal(a[prefix+'raw'],a[prefix+method])
run.save(R/'PREDICTION_AUDIT.json',{'passed':True,'cases':48,'prediction_arrays':checked,'zero_coverage_cases_checked':nullcases,'all_input_hashes_reverified':True,'new_outer_test_scored':False})
print('Prediction audit PASS',checked)
if len(sys.argv)>1 and sys.argv[1]=='metrics':
 d=json.loads((R/'RESULTS.json').read_text());look={(r['family'],r['fold'],r['mask'],r['geometry'],r['method']):r['brier'] for r in d['rows']};maximum=0;count=0
 for name in frozen['records']:
  path=R/name;c=json.loads(path.read_text());a=np.load(path.parent/'predictions_PRIVATE.npz');y=np.load(run.D/f"{c['family']}_L.npy",mmap_mode='r')[c['validation_indices']]
  for key in a.files:
   values=list(a[key]) if a[key].ndim==3 else [a[key]];loss=np.mean([np.einsum('ij,ij->i',v-y,v-y).mean() for v in values]);mask,g,method=key.split('__') if key!='plain_mean' else ('NA','NA','plain_mean');diff=abs(loss-look[(c['family'],c['fold'],mask,g,method)]);assert diff<1e-12;maximum=max(maximum,diff);count+=1
 run.save(R/'METRIC_AUDIT.json',{'passed':True,'values_compared':count,'maximum_absolute_difference':maximum,'scope':'Development artifact verification'});print('Metric audit PASS',count,maximum)
