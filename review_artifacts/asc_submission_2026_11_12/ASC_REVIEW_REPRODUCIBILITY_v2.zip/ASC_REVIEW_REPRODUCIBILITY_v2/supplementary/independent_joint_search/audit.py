"""Check the returned summaries against the frozen independent-candidate protocol."""
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
protocol_path = root / "JOINT_SEARCH_PROTOCOL.json"
results_path = root / "JOINT_SEARCH_RESULTS.json"
plan = json.loads(protocol_path.read_text(encoding="utf-8"))
result = json.loads(results_path.read_text(encoding="utf-8"))
assert sha256(protocol_path.read_bytes()).hexdigest() == result["identity"]["joint_protocol_sha256"]
assert result["identity"]["protocol_sha256"] == plan["original_protocol_sha256"]
assert result["complete"] is True
assert result["tested"] == len(result["rows"]) == len(plan["candidates"]) == plan["candidate_budget"] == 512
assert result["reference_replay_max_abs_diff"] == 0.0
masks = set()
for index, (row, candidate) in enumerate(zip(result["rows"], plan["candidates"]), 1):
    deleted = candidate["deleted"]
    assert deleted == sorted(set(deleted))
    assert all(isinstance(i, int) and 0 <= i < 512 for i in deleted)
    assert len(deleted) == candidate["stratum"] == row["deleted"]
    key = ((1 << 512) - 1) ^ sum(1 << i for i in deleted)
    assert key not in masks
    masks.add(key)
    assert row["candidate"] == index
    assert row["bytes"] == 3300 * (512 - len(deleted)) * 4
    assert 0 < row["violations_at_numeric_tolerance"] <= row["violations_at_zero"] <= 3300
    assert math.isfinite(row["maximum_increase"]) and row["maximum_increase"] > 1e-12
    assert len(row["errors_sha256"]) == 64
    int(row["errors_sha256"], 16)
assert Counter(row["deleted"] for row in result["rows"]) == dict(plan["strata_deleted_coordinates_and_counts"])
assert result["best_at_numeric_tolerance"] is None

# When the original return archive is supplied, additionally check that every
# frozen independent candidate is outside the original query pool.
import sys
disjoint_verified = False
if len(sys.argv) == 2:
    old_return = Path(sys.argv[1])
    assert sha256(old_return.read_bytes()).hexdigest() == plan["archive_sha256"]
    with ZipFile(old_return) as old:
        prior = json.loads(old.read("results/oracle_audit.json"))["rows"]
        assert len(prior) == plan["excluded_cached_masks"] == 1531
        assert masks.isdisjoint({int(row["mask_hex"], 16) for row in prior})
    disjoint_verified = True

groups = []
for deleted, count in plan["strata_deleted_coordinates_and_counts"]:
    rows = [row for row in result["rows"] if row["deleted"] == deleted]
    groups.append({
        "deleted": deleted,
        "retained": 512 - deleted,
        "candidates": count,
        "feasible": 0,
        "violating_objects_min": min(row["violations_at_numeric_tolerance"] for row in rows),
        "violating_objects_max": max(row["violations_at_numeric_tolerance"] for row in rows),
        "maximum_increase_min": min(row["maximum_increase"] for row in rows),
        "maximum_increase_max": max(row["maximum_increase"] for row in rows),
    })
print(json.dumps({
    "returned_results_sha256": sha256(results_path.read_bytes()).hexdigest(),
    "frozen_protocol_sha256": sha256(protocol_path.read_bytes()).hexdigest(),
    "complete": True,
    "candidates": 512,
    "feasible": 0,
    "original_query_pool_disjoint_verified": disjoint_verified,
    "scope": "Returned summaries, original query manifest and reference replay report. Candidate error vectors were not supplied for this audit.",
    "groups": groups,
}, indent=2))
