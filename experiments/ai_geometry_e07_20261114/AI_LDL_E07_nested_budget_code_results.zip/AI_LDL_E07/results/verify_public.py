"""Recompute published aggregate arithmetic only, without private predictions."""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parent
m=json.loads((R/'MANIFEST.json').read_text())
for n,h in m.items():
 if hashlib.sha256((R/n).read_bytes()).hexdigest()!=h:raise ValueError('File mismatch '+n)
p=json.loads((R/'RESULTS_PUBLIC.json').read_text());s=json.loads((R/'SUMMARY.json').read_text());families=sorted({r['family'] for r in p['rows']});assert len(families)==16
lookup={}
for f,key in sorted({(r['family'],r['key']) for r in p['rows']}):
 rr=[r for r in p['rows'] if r['family']==f and r['key']==key];assert len(rr)==3
 n=sum(r['n_validation'] for r in rr);lookup[f,key]={'brier':sum(r['brier']*r['n_validation'] for r in rr)/n}
 if 'array_fraction' in rr[0]:
  for field in ['array_fraction','selected_percent']:lookup[f,key][field]=sum(r[field]*r['n_validation'] for r in rr)/n
for r in p['family_summary']:
 for k in ['brier','array_fraction','selected_percent']:
  if k in r:assert abs(r[k]-lookup[r['family'],r['key']][k])<=1e-12
pairs={'Information weighting':('G__geometric','U__geometric'),'Hierarchy versus Lloyd':('G__geometric','G__lloyd'),'Label priority secondary':('G__supervised','G__geometric')}
for r in s['fixed_budget_contrasts']:
 a,b=pairs[r['contrast']];mask=r['mask'];pct=r['budget_percent'];ds=[lookup[f,f'{mask}__{a}__{pct}']['brier']-lookup[f,f'{mask}__{b}__{pct}']['brier'] for f in families]
 assert abs(np.mean(ds)-r['equal_family_brier_difference'])<=1e-12
 assert (sum(d<-1e-12 for d in ds),sum(abs(d)<=1e-12 for d in ds),sum(d>1e-12 for d in ds))==(r['better'],r['tie'],r['worse'])
for r in s['selected_cap100_policies']:
 key=f"{r['mask']}__{r['geometry']}__{r['method']}";a=[lookup[f,key+'__cap100'] for f in families];b=[lookup[f,key+'__100'] for f in families];ds=[x['brier']-y['brier'] for x,y in zip(a,b)]
 for field,v in [('equal_family_brier',np.mean([x['brier'] for x in a])),('brier_difference_from_fixed100',np.mean(ds)),('mean_array_fraction',np.mean([x['array_fraction'] for x in a])),('mean_selected_percent',np.mean([x['selected_percent'] for x in a]))]:assert abs(r[field]-v)<=1e-12
 assert (sum(d<-1e-12 for d in ds),sum(abs(d)<=1e-12 for d in ds),sum(d>1e-12 for d in ds))==(r['better'],r['tie'],r['worse'])
print('PASS: manifest,4656 metric rows->1552 family summaries,24 fixed-budget contrasts,12 selected policies; aggregate replay only')
