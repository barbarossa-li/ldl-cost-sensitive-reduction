from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;p=json.loads((R/'RESULTS_PUBLIC.json').read_text());rows=p['family_summary'];families=sorted({r['family'] for r in rows});look={(r['family'],r['key']):r for r in rows}
fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
for ax,mask in zip(axes,['Full','cost40']):
 for geom,method,label,style in [('U','geometric','U geometry-only','--'),('G','geometric','G geometry-only','-'),('G','lloyd','G Lloyd',':'),('G','supervised','G label-priority','-.')]:
  x=[];y=[]
  for pct in [25,50,75,100]:
   a=[look[f,f'{mask}__{geom}__{method}__{pct}'] for f in families];x.append(100*np.mean([z['array_fraction'] for z in a]));y.append(np.mean([z['brier'] for z in a]))
  ax.plot(x,y,style,marker='o',label=label)
 ax.set_title(mask);ax.set_xlabel('Predictor numerical arrays (% of singleton)');ax.set_ylabel('Equal-family Brier error');ax.grid(alpha=.25)
axes[0].legend(fontsize=8);fig.suptitle('E0.7 fixed-budget replay: consulted training-pool validation');fig.savefig(R/'risk_capacity.png',dpi=180)
