"""Independent seven-metric audit, split checks and exact E10 reference replay."""
from pathlib import Path
import json,argparse,hashlib
import numpy as np
from scipy.special import rel_entr
from scipy.spatial import distance

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def recompute(y,v):
 delta=v-y;rat=np.divide(abs(delta),y+v,out=np.zeros_like(delta),where=y+v>0)
 return {'brier':float(np.einsum('ij,ij->i',delta,delta).mean()),'chebyshev':float(np.mean([distance.chebyshev(a,b) for a,b in zip(y,v)])),'clark':float(np.linalg.norm(rat,axis=1).mean()),'canberra':float(np.mean([distance.canberra(a,b) for a,b in zip(y,v)])),'kl':float(rel_entr(y,np.maximum(v,1e-12)).sum(1).mean()),'cosine':float(np.mean([1-distance.cosine(a,b) for a,b in zip(y,v)])),'intersection':float(((y+v-abs(delta))/2).sum(1).mean())}
def audit(run,known,novel,e10,protocol):
 answer={};global_test=set();global_fit=set();newX=np.load(novel/'Ren_Cecps_X.npy',mmap_mode='r');_,groups=np.unique(newX,axis=0,return_inverse=True)
 for stage,ncases,nfold in [('e11',48,3),('e12',5,5)]:
  out=run/stage;fr=json.loads((out/'ALL_PREDICTIONS_FROZEN.json').read_text());res=json.loads((out/'RESULTS_PUBLIC.json').read_text());assert len(fr['records'])==ncases
  lookup={(r['family'],r['fold'],r['key']):r for r in res['rows']};assert len(lookup)==len(res['rows']);maxerr={k:0. for k in ['brier','chebyshev','clark','canberra','kl','cosine','intersection']};count=replays=0;maxmass=0.;failcount=0;opt_nonconv=0
  for name,h in fr['records'].items():
   file=out/name;assert sha(file)==h;rec=json.loads(file.read_text());pf=file.parent/'predictions_PRIVATE.npz';assert sha(pf)==rec['predictions_sha256'];fit=set(rec['fit_indices']);held=set(rec['validation_indices']);excluded=set(rec['excluded_original_test_indices']);assert not fit&held and not (fit|held)&excluded
   family=rec['family'];folder=known if stage=='e11' else novel;targetpath=folder/(family+'_L.npy');source=next(f for f in protocol['stages']['e11']['families'] if f['family']==family) if stage=='e11' else protocol['stages']['e12']['family'];assert sha(targetpath)==source['L_sha256'];y=np.load(targetpath,mmap_mode='r')[rec['validation_indices']]
   if stage=='e12':
    fg=set(groups[rec['fit_indices']]);hg=set(groups[rec['validation_indices']]);assert not fg&hg and not (fg|hg)&(global_fit|global_test);global_fit|=fg;global_test|=hg;assert len(fit)==384 and len(held)==512
   else:
    oldfile=e10/family/f"fold_{rec['fold']}"/'record_PRIVATE.json';old=json.loads(oldfile.read_text())
    for field in ['fit_indices','validation_indices','excluded_original_test_indices']:assert old[field]==rec[field]
   with np.load(pf) as arr:
    assert len(arr.files)+len(rec['failures'])==27
    for key in arr.files:
     v=arr[key];assert v.shape==y.shape and np.isfinite(v).all() and np.all(v>=0);mass=float(abs(v.sum(1)-1).max());assert mass<=1e-5;maxmass=max(mass,maxmass);row=lookup[family,rec['fold'],key];values=recompute(y,v)
     for metric,value in values.items():
      error=abs(value-row[metric]);assert error<1e-11;maxerr[metric]=max(maxerr[metric],error)
     count+=1
     if stage=='e11' and (key=='plain_mean' or key.split('__')[1].startswith(('UU','GG'))):
      with np.load(e10/family/f"fold_{rec['fold']}"/'predictions_PRIVATE.npz') as prior:
       if key=='plain_mean':oldkey=key
       else:
        mask,method=key.split('__');g=method[0];b=method[2:];oldkey=f'{mask}__{g}__geometric__{b}__{g}__a0.5'
       assert np.array_equal(v,prior[oldkey]);replays+=1
   failcount+=len(rec['failures'])
   for info in rec['model_diagnostics'].values():
    for opt in info.get('optimizer',[]):opt_nonconv+=int(not opt['success'])
  assert count+failcount==ncases*27
  for s in res['family_summary']:
   rr=[r for r in res['rows'] if r['family']==s['family'] and r['key']==s['key']];n=sum(r['n_validation'] for r in rr);assert len(rr)==s['n_folds'] and s['complete']==(len(rr)==nfold)
   for metric in maxerr:assert abs(sum(r[metric]*r['n_validation'] for r in rr)/n-s[metric])<1e-13
  answer[stage]={'passed':True,'cases':ncases,'aggregate_prediction_rows':count,'metric_values_checked':count*7,'max_absolute_metric_error':maxerr,'maximum_raw_prediction_mass_error':maxmass,'explicit_failed_prediction_slots':failcount,'E10_exact_reference_arrays':replays,'SABFGS_nonconverged_terminations':opt_nonconv,'known_original_outer_test_scored':False}
 answer['new_corpus_group_verification']={'passed':True,'replicates':5,'fit_rows':5*384,'test_rows':5*512,'exact_feature_group_fit_test_and_replicate_disjoint':True,'document_author_disjoint_verified':False,'dataset_version':'PyLDL Ren_Cecps32420rows/100features/8labels'}
 return answer
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--known-data',type=Path,required=True);p.add_argument('--novel-data',type=Path,required=True);p.add_argument('--e10',type=Path,required=True);p.add_argument('--protocol',type=Path,required=True);a=p.parse_args();print(json.dumps(audit(a.run,a.known_data,a.novel_data,a.e10,json.loads(a.protocol.read_text())),indent=2))
