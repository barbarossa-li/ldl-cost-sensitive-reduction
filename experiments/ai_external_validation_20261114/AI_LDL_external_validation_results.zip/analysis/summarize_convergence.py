from pathlib import Path
import json,argparse,numpy as np
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--parent',type=Path,required=True);a=p.parse_args();res=json.loads((a.run/'RESULTS_PUBLIC.json').read_text());answer={}
for stage in ['e11','e12']:
 raw=json.loads((a.parent/stage/'RESULTS_PUBLIC.json').read_text());lookup={(r['family'],r['key']):r for r in raw['family_summary']};families=sorted({r['family'] for r in raw['family_summary']});pooled=[];means=[];contrasts=[]
 for family,key in sorted({(r['family'],r['key']) for r in res['rows'] if r['stage']==stage}):
  rr=[r for r in res['rows'] if r['stage']==stage and r['family']==family and r['key']==key];n=sum(r['n_validation'] for r in rr);pooled.append({'family':family,'key':key,'n_validation':n,**{m:sum(r[m]*r['n_validation'] for r in rr)/n for m in ['brier','chebyshev','clark','canberra','kl','cosine','intersection','array_bytes']}})
 for key in sorted({r['key'] for r in pooled}):
  rr=[r for r in pooled if r['key']==key];means.append({'key':key,**{m:float(np.mean([r[m] for r in rr])) for m in ['brier','array_bytes']}});mask=key.split('__')[0];diff={r['family']:lookup[r['family'],mask+'__GG50']['brier']-r['brier'] for r in rr};contrasts.append({'key':key,'GG50_minus_baseline_mean_brier':float(np.mean(list(diff.values()))),'negative':sum(d < -1e-12 for d in diff.values()),'tie':sum(abs(d)<=1e-12 for d in diff.values()),'positive':sum(d>1e-12 for d in diff.values()),'family_differences':diff})
 diag=[d for d in res['diagnostics'] if d['stage']==stage];answer[stage]={'scope':res['scope'],'family_risks':pooled,'equal_family_means':means,'primary_GG50_contrasts':contrasts,'converged':sum(d['success'] for d in diag),'fits':len(diag),'maximum_iterations':max(d['iterations'] for d in diag)}
print(json.dumps(answer,indent=2))
