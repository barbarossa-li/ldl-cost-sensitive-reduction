"""Report every prespecified prototype-vs-external contrast, with coverage."""
from pathlib import Path
import argparse,json,itertools
import numpy as np
EXTERNAL=['AAKNN5','AAKNN20','SABFGS','RKNN_native','RKNN_train_gamma']
METRICS=['brier','chebyshev','clark','canberra','kl','cosine','intersection']
def summary(run):
 result={}
 for stage in ['e11','e12']:
  res=json.loads((run/stage/'RESULTS_PUBLIC.json').read_text());lookup={(r['family'],r['key']):r for r in res['family_summary']};families=sorted({r['family'] for r in res['family_summary']});contrasts=[];means=[]
  for key in sorted({r['key'] for r in res['family_summary']}):
   rr=[r for r in res['family_summary'] if r['key']==key and r['complete']];means.append({'key':key,'complete_families':len(rr),'total_families':len(families),**{m:float(np.mean([r[m] for r in rr])) if rr else None for m in METRICS},**({'mean_array_fraction':float(np.mean([r['array_fraction'] for r in rr]))} if rr and 'array_fraction' in rr[0] else {})})
  for mask,g,b,base in itertools.product(['Full','cost40'],['UU','GG'],['25','50','75','100'],EXTERNAL):
   left=f'{mask}__{g}{b}';right=f'{mask}__{base}';fs=[f for f in families if (f,left) in lookup and (f,right) in lookup and lookup[f,left]['complete'] and lookup[f,right]['complete']];d={f:lookup[f,left]['brier']-lookup[f,right]['brier'] for f in fs}
   contrasts.append({'mask':mask,'prototype':g+b,'baseline':base,'complete_families':len(fs),'total_families':len(families),'mean_brier_difference':float(np.mean(list(d.values()))) if d else None,'negative':sum(v < -1e-12 for v in d.values()),'tie':sum(abs(v)<=1e-12 for v in d.values()),'positive':sum(v>1e-12 for v in d.values()),'family_differences':d})
  result[stage]={'scope':res['scope'],'aggregate_rows':len(res['rows']),'explicit_failures':res['failures'],'families':families,'equal_family_means':means,'all_prespecified_contrasts':contrasts,'primary':'GG50 Full versus allfive external prediction variants;cost40secondary;otherbudgets retained','direction':'Brier difference prototype minus baseline; negative favors prototype; higher cosine/intersection is better','tuned_comparison':False}
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);a=p.parse_args();print(json.dumps(summary(a.run),indent=2))
