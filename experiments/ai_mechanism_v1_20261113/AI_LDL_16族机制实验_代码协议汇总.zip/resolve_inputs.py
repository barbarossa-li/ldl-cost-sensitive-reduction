from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures,os,time
import numpy as np
from scipy.io import loadmat
R=Path(__file__).resolve().parent;D=Path('/workspace/work/asc_experiments/data');P=json.loads(Path('/workspace/work/ai_mechanism_v1_20261113/PROTOCOL.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(f):
 name=f['family'];paths=[D/f'{name}_{a}.npy' for a in ['X','L']]
 if all(p.exists() and sha(p)==f[a+'_sha256'] for a,p in zip(['X','L'],paths)):
  print('CACHE VERIFIED',name,flush=True);return {'family':name,'source':'verified_local_npy','downloaded':False}
 dest=D/f'{name}.mat';downloaded=False
 if not dest.exists():
  tmp=dest.with_suffix('.mat.partial')
  with urllib.request.urlopen(f['url'],timeout=60) as response,open(tmp,'wb') as out:
   while block:=response.read(1024*1024):out.write(block)
  assert sha(tmp)==f['mat_sha256'],('MAT hash mismatch',name);tmp.replace(dest);downloaded=True
 assert sha(dest)==f['mat_sha256'],('MAT cache mismatch',name)
 arrays=loadmat(dest);X=np.asarray(arrays['features'],float);L=np.asarray(arrays['labels'],float)
 assert X.shape==(f['N'],f['m']) and L.shape==(f['N'],f['q']);assert np.isfinite(X).all() and np.isfinite(L).all() and (L>=0).all() and (L.sum(1)>0).all();L=L/L.sum(1,keepdims=True)
 for a,values,path in zip(['X','L'],[X,L],paths):
  if path.exists():assert sha(path)==f[a+'_sha256'],('Existing array differs',name,a)
  else:
   temp=path.with_suffix('.partial.npy');np.save(temp,values);assert sha(temp)==f[a+'_sha256'],('Converted hash mismatch',name,a);temp.replace(path)
 row={'family':name,'source':f['url'],'downloaded':downloaded,'mat_sha256':sha(dest),'X_sha256':sha(paths[0]),'L_sha256':sha(paths[1])};print('INPUT VERIFIED',name,'new_download',downloaded,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(resolve,P['families']))
(R/'INPUT_RESOLUTION.json').write_text(json.dumps({'cache_search':'Local tree, private Drive cache folder and targeted Drive source-name search; no additional raw-array cache located. Existing three families reused.','protocol_sha256':hashlib.sha256(Path('/workspace/work/ai_mechanism_v1_20261113/PROTOCOL.json').read_bytes()).hexdigest(),'rows':rows},indent=2));print('ALL16 INPUTS VERIFIED',flush=True)
