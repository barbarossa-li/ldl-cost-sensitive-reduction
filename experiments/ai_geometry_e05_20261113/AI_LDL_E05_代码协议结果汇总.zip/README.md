# E0.5 direct prototype retrieval — development evidence

The candidate retrieves accepted-ball feature centroids/label prototypes and uncovered singleton points directly. It has a standalone selected-column inference state, exact singleton U/G 5NN replay, and capacity-matched same-covered random controls. Uniform and group-mass votes are both reported. This is 48 post-v1 training-internal folds on known datasets, not new outer-test evidence or an established novel method.

All prediction bundles were frozen before scoring; 1,776 Brier values were independently audited. Errors remain mixed; most families still favor simple mean shrinkage. The old strict accepted-leaf criterion compresses only a limited fraction of inference arrays. See REPORT.md and the complete family/control tables; no negative result or voting rule is omitted. Numeric array byte ratios exclude Python/scalar metadata, training work memory and source caches; feature acquisition cost is unchanged for the same P.

Reproduce from the authorized32-array cache without downloading data:
`python reproduce.py --data /cache --output /new/empty/directory`
This regenerates private split metadata from public frozen seeds, checks input identity, reruns48 folds and compares summary Brier values. Artifact replays do not add independent evidence. Python3.12/numpy2.3.5/scipy1.17.0; optional report generation uses python-docx. Frozen method dependencies are bundled; source/manifest hashes pin the recorded runs. Raw arrays, actual split/group members and per-query outputs remain private. The original78-page manuscript is unchanged.
