from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
os.environ.setdefault('KERAS_BACKEND','torch')
import sys,json,hashlib,time,traceback,concurrent.futures,multiprocessing,io
import numpy as np
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);t=path.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');t.replace(path)
def worker(job):
 base,parent,stage,task,fold=job;os.environ['LDL_PARENT_SOURCE']=parent
 from selection import select,state_bytes
 import learners as l,encoding,data
 base=Path(base);directory=base/'run'/stage/task/f'fold_{fold}';directory.mkdir(parents=True,exist_ok=True);recfile=directory/'record_PRIVATE.json'
 if recfile.exists():
  rec=json.loads(recfile.read_text());assert rec['execution_manifest_sha256']==sha(ROOT/'MANIFEST.json')
  for name,h in rec['artifact_sha256'].items():assert sha(directory/name)==h
  return str(recfile.relative_to(base/'run')),sha(recfile)
 start=time.perf_counter();meta={};details={};artifacts={}
 try:
  train,Y,query,parts,meta=data.case(base,task,fold,stage);result=select(train,Y,query,parts,data.TASKS.index(task),fold);values=result['outputs'];states=result['states'];encoder=result['encoder'];encjson,encnpz=encoding.dumps(encoder);(directory/'encoder_PRIVATE.json').write_bytes(encjson);(directory/'encoder_PRIVATE.npz').write_bytes(encnpz);encsize=len(encjson)+len(encnpz);numericencoder=encoder['idf'].nbytes+encoder['components'].nbytes
  np.savez_compressed(directory/'predictions_PRIVATE.npz',**values);np.savez_compressed(directory/'inner_predictions_PRIVATE.npz',**{m+'___'+key:v for m,vv in result['cv'].items() for key,v in vv.items()});flat={};statemeta={};resources={}
  for key,state in states.items():
   statemeta[key]={k:v for k,v in state.items() if not isinstance(v,np.ndarray)}
   for k,v in l.arrays(state).items():flat[key+'___'+k]=v
   mm,nn=state_bytes(state);needs=state['kind']!='Mean';resources[key]={'estimator_numeric_array_bytes':l.byte_count(state),'encoder_numeric_array_bytes':numericencoder if needs else 0,'encoder_serialized_bytes':encsize if needs else 0,'estimator_serialized_bytes':len(mm)+len(nn),'deployed_serialized_file_bytes':len(mm)+len(nn)+(encsize if needs else 0),'encoder_required':needs,'latent_query_features':len(state['P']) if needs else 0}
   replay=l.predict(state,encoding.transform(encoder,query)) if needs else l.predict(state,query);assert np.array_equal(replay,values[key])
  np.savez_compressed(directory/'estimator_states_PRIVATE.npz',**flat)
  details={'status':'complete' if not result['failures'] else 'partial_policy_failure','inner_folds':[x.tolist() for x in parts],'inner_encoders':result['inner_encoders'],'outer_fingerprint':result['outer_fingerprint'],'choices':result['choices'],'cv_scores':result['cv_scores'],'diagnostics':result['diagnostics'],'policy_failures':result['failures'],'state_metadata':statemeta,'resources':resources,'query_count':len(query),'fit_count':len(train)}
  for name in ['encoder_PRIVATE.json','encoder_PRIVATE.npz','predictions_PRIVATE.npz','inner_predictions_PRIVATE.npz','estimator_states_PRIVATE.npz']:artifacts[name]=sha(directory/name)
 except (AssertionError,SystemExit):raise
 except Exception as e:
  details={'status':'case_failure','type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'policy_failures':'all17 policies unavailable; no replacement'}
 save(recfile,{'task':task,'fold':fold,'stage':stage,'design_protocol_sha256':sha(Path(base)/'source/PROTOCOL.json'),'execution_manifest_sha256':sha(ROOT/'MANIFEST.json'),'metadata':meta,'details':details,'artifact_sha256':artifacts,'seconds':time.perf_counter()-start})
 return str(recfile.relative_to(base/'run')),sha(recfile)
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);ap.add_argument('--parent-source',type=Path,required=True);a=ap.parse_args();plan=json.loads((ROOT/'EXECUTION.json').read_text());assert sha(a.base/'source/PROTOCOL.json')==plan['design_protocol_sha256'];assert sha(a.parent_source/'MANIFEST.json')==plan['parent_manifest_sha256']
 for name,h in json.loads((ROOT/'MANIFEST.json').read_text()).items():assert sha(ROOT/name)==h
 for name,h in json.loads((a.parent_source/'MANIFEST.json').read_text()).items():assert sha(a.parent_source/name)==h
 output=a.base/'run';assert not (output/'ALL_PREDICTIONS_FROZEN.json').exists();jobs=[(str(a.base),str(a.parent_source),'primary',task,fold) for task in ['ChaosSNLI','ChaosMNLI','DICES990'] for fold in range(5)]+[(str(a.base),str(a.parent_source),'rater_disjoint','DICES990',fold) for fold in range(5)];records={};start=time.perf_counter()
 with concurrent.futures.ProcessPoolExecutor(max_workers=2,mp_context=multiprocessing.get_context('spawn')) as pool:
  for name,h in pool.map(worker,jobs):records[name]=h;print('FROZEN',name,flush=True)
 assert len(records)==20;save(output/'ALL_PREDICTIONS_FROZEN.json',{'records':records,'design_protocol_sha256':sha(a.base/'source/PROTOCOL.json'),'execution_manifest_sha256':sha(ROOT/'MANIFEST.json'),'seconds':time.perf_counter()-start,'gate':'All20 cases frozen, including explicit failures; no outer outcome scoring performed by runner'})
if __name__=='__main__':main()
