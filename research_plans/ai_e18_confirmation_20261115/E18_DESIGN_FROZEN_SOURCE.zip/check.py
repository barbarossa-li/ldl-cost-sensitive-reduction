import numpy as np,json
from design import *
g=connected_groups([['image:a','premise:x'],['image:a','premise:y'],['image:b','premise:y'],['image:c','premise:z'],['image:d'],['image:e'],['image:f'],['image:g'],['image:h']]);assert g[0].tolist()==[0,1,2];ff=folds(g,13,3)
for part in ff:
 ids=set(part.tolist())
 for group in g:assert not (ids&set(group.tolist())) or set(group.tolist())<=ids
assert sorted(np.concatenate(ff).tolist())==list(range(9));a,b=rater_cohorts([str(i) for i in range(30)]);assert len(a)==21 and len(b)==9 and not a&b
train=['shared word group'+str(i%12)+' feature'+str(i//2)+' other'+str(i%5) for i in range(70)];m=TextFeatures().fit(train);before=dict(m.vectorizer.vocabulary_);v=m.transform(['UNSEENQUERYTOKEN other']);assert m.vectorizer.vocabulary_==before and 'unseenquerytoken' not in before and np.isfinite(v).all();n=TextFeatures().fit(train);assert np.allclose(m.transform(train[:3]),n.transform(train[:3]),atol=1e-12,rtol=0)
large=connected_groups([[f'g:{i//3}'] for i in range(180)]);held=folds(large,83)[0];fit=capped_fit(large,held,87,cap=140);assert len(fit)<=140 and not set(fit)&set(held)
for grp in large:assert not set(fit)&set(grp) or set(grp)<=set(fit)
print(json.dumps({'passed':True,'checks':['Transitive source-ID/premise overlaps form one connected group','Outer folds keep all connected-group members together','Training cap retains complete groups with no query overlap','Annotator cohorts are exactly disjoint','Query text cannot expand fitted vocabulary','Text feature fitting is deterministic and does not consume target labels'],'scope':'Synthetic design checks only; no new-corpus predictive outcome evaluated'},indent=2))
