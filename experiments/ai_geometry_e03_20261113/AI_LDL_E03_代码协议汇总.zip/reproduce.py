from pathlib import Path
import argparse,os,shutil,json,hashlib,subprocess,sys
B=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=a.output.resolve();data=a.data.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Use a new empty output directory')
for path,h in json.loads((B/'records/PROTOCOL.json').read_text())['input_hashes'].items():
 if path.endswith('.npy'):assert hashlib.sha256((data/Path(path).name).read_bytes()).hexdigest()==h
out.mkdir(parents=True,exist_ok=True);dep=out/'dependencies';shutil.copytree(B/'dependencies',dep)
p=dep/'e0/run_pilot.py';p.write_text(p.read_text().replace('/workspace/work/asc_experiments/data',str(data)))
for name in ['run.py','controls.py','audit.py']:shutil.copy2(B/'recorded_source'/name,out/name)
env=os.environ.copy();env.update(AI_LDL_E0=str(dep/'e0'),AI_LDL_E02=str(dep/'e02'),AI_LDL_CORE=str(dep/'frozen_core'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
for action in ['prepare','run','score']:subprocess.run([sys.executable,str(out/'run.py'),action],env=env,check=True)
subprocess.run([sys.executable,str(out/'audit.py')],env=env,check=True)
ref=json.loads((B/'records/RESULTS.json').read_text())['summary'];actual=json.loads((out/'RESULTS.json').read_text())['summary'];key=lambda r:tuple(r[k] for k in ['dataset','policy','weight','mask','target']);lookup={key(r):r for r in actual};assert len(ref)==len(actual)
delta=max(abs(r['brier_mean']-lookup[key(r)]['brier_mean']) for r in ref);assert delta<=1e-12
(out/'PORTABLE_COMPARISON.json').write_text(json.dumps({'summary_rows':len(ref),'maximum_absolute_difference':delta,'scope':'Artifact reproduction, not additional independent data evidence'},indent=2));print('Portable rerun passed',delta)
