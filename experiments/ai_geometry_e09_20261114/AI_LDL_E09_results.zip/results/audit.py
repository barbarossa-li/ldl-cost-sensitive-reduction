"""Independent arithmetic and capacity audit of frozen E09 artifacts."""
import json,hashlib,argparse
from pathlib import Path
import numpy as np

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def audit(run,data):
 frozen=json.loads((run/'ALL_PREDICTIONS_FROZEN.json').read_text());results=json.loads((run/'RESULTS_PUBLIC.json').read_text())
 assert len(frozen['records'])==48
 lookup={(r['family'],r['fold'],r['key']):r for r in results['rows']};assert len(lookup)==15408
 maxerr=0.;count=0;endpoints=0;capacity=0;repairs=warnings=0
 for name,sha in frozen['records'].items():
  recordfile=run/name;assert digest(recordfile)==sha
  rec=json.loads(recordfile.read_text());predfile=recordfile.parent/'predictions_PRIVATE.npz';assert digest(predfile)==rec['predictions_sha256']
  fit=set(rec['fit_indices']);held=set(rec['validation_indices']);excluded=set(rec['excluded_original_test_indices']);assert not fit&held and not (fit|held)&excluded
  target=np.load(data/(rec['family']+'_L.npy'),mmap_mode='r')[rec['validation_indices']]
  stats={r['key']:r for r in rec['statistics']};assert len(stats)==320
  aligned={};unique={}
  with np.load(predfile) as arr:
   assert len(arr.files)==321
   for key in arr.files:
    pred=arr[key];assert pred.shape==target.shape and np.isfinite(pred).all() and (pred>=0).all() and np.max(abs(pred.sum(1)-1))<=1e-12
    delta=pred-target;value=float(np.einsum('ij,ij->i',delta,delta).mean());row=lookup[rec['family'],rec['fold'],key]
    maxerr=max(maxerr,abs(value-row['brier']));assert abs(value-row['brier'])<1e-12;count+=1
    if key=='plain_mean':continue
    mask,g,method,budget,readout,alpha=key.split('__');s=stats[key];assert s['K']<=s['nfit'] and s['K']>0
    group=(mask,g,budget,readout,alpha);val=(s['K'],s['array_bytes'],s['singleton_bytes_same_readout'])
    if group in aligned:assert aligned[group]==val;capacity+=1
    aligned[group]=val
    assert s['array_fraction']==s['array_bytes']/s['singleton_bytes_same_readout']
    unique[(mask,g,method,budget)]=(s['repair_count'],s['warning_count'])
    if budget=='100':
     base=arr[f'{mask}__{g}__geometric__100__{readout}__{alpha}'];assert np.array_equal(pred,base);endpoints+=1
  repairs+=sum(v[0] for v in unique.values());warnings+=sum(v[1] for v in unique.values())
 # Recompute pooled family risks, weighting observations rather than folds.
 for s in results['family_summary']:
  rows=[lookup[s['family'],i,s['key']] for i in range(3)];value=sum(r['brier']*r['n_validation'] for r in rows)/sum(r['n_validation'] for r in rows);assert abs(value-s['brier'])<1e-14
 return dict(passed=True,cases=48,brier_rows=count,max_absolute_brier_error=maxerr,matched_capacity_comparisons=capacity,singleton_exact_checks=endpoints,repair_events_counted_once_per_constructor_slot=repairs,warning_events_counted_once_per_constructor_slot=warnings,original_outer_test_scored=False,scope='Arithmetic/provenance audit; consulted-family development, not independent confirmation')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--data',type=Path,required=True);a=p.parse_args();result=audit(a.run,a.data);print(json.dumps(result,indent=2))
