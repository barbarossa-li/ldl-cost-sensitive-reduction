"""Independent E10 Brier/capacity/invariance audit and scoped E09 replay."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def audit(run,data,e09):
 freeze=json.loads((run/'ALL_PREDICTIONS_FROZEN.json').read_text());oldfreeze=json.loads((e09/'ALL_PREDICTIONS_FROZEN.json').read_text());results=json.loads((run/'RESULTS_PUBLIC.json').read_text());assert len(freeze['records'])==48
 lookup={(r['family'],r['fold'],r['key']):r for r in results['rows']};assert len(lookup)==15408
 count=replay=constructor_capacity=fourcell_capacity=endpoint=small=repairs=warnings=0;maxerr=maxquery=0.
 for name,h in freeze['records'].items():
  file=run/name;assert sha(file)==h;rec=json.loads(file.read_text());predfile=file.parent/'predictions_PRIVATE.npz';assert sha(predfile)==rec['predictions_sha256']
  oldfile=e09/name;assert sha(oldfile)==oldfreeze['records'][name];old=json.loads(oldfile.read_text());assert sha(oldfile.parent/'predictions_PRIVATE.npz')==old['predictions_sha256']
  for field in ['fit_indices','validation_indices','excluded_original_test_indices']:assert rec[field]==old[field]
  fit=set(rec['fit_indices']);held=set(rec['validation_indices']);exclude=set(rec['excluded_original_test_indices']);assert not fit&held and not (fit|held)&exclude
  target=np.load(data/(rec['family']+'_L.npy'),mmap_mode='r')[rec['validation_indices']];stats={s['key']:s for s in rec['statistics']};assert len(stats)==320
  ctor={};cells={};events={}
  with np.load(predfile) as arrays,np.load(oldfile.parent/'predictions_PRIVATE.npz') as prior:
   assert len(arrays.files)==321
   for key in arrays.files:
    pred=arrays[key];assert pred.shape==target.shape and np.isfinite(pred).all() and (pred>=0).all() and np.max(abs(pred.sum(1)-1))<=1e-12
    delta=pred-target;value=float(np.einsum('ij,ij->i',delta,delta).mean());expected=lookup[rec['family'],rec['fold'],key]['brier'];error=abs(value-expected);assert error<1e-12;maxerr=max(maxerr,error);count+=1
    if key=='plain_mean':assert np.array_equal(pred,prior[key]);replay+=1;continue
    mask,c,method,budget,q,a=key.split('__');s=stats[key];val=(s['K'],s['array_bytes'],s['singleton_bytes_same_readout']);assert s['array_fraction']==s['array_bytes']/s['singleton_bytes_same_readout']
    k=(mask,c,budget,q,a)
    if k in ctor:assert ctor[k]==val;constructor_capacity+=1
    ctor[k]=val;k=(mask,method,budget,a)
    if k in cells:assert cells[k]==val;fourcell_capacity+=1
    cells[k]=val;events[(mask,c,method,budget)]=(s['repair_count'],s['warning_count'])
    if budget=='100':
     assert np.array_equal(pred,arrays[f'{mask}__U__geometric__100__{q}__{a}']);endpoint+=1
    if s['K']<=5:
     qe=float(np.max(abs(pred-arrays[f'{mask}__{c}__{method}__{budget}__U__{a}'])));assert qe<=1e-15;maxquery=max(maxquery,qe);small+=1
    if c==q and (c=='U' or method in ['geometric','paper20']):
     oldkey=f'{mask}__{c}__{method}__{budget}__nn5__{a}';assert np.array_equal(pred,prior[oldkey]);replay+=1
  repairs+=sum(x[0] for x in events.values());warnings+=sum(x[1] for x in events.values())
 for row in results['family_summary']:
  rr=[lookup[row['family'],i,row['key']] for i in range(3)];v=sum(r['brier']*r['n_validation'] for r in rr)/sum(r['n_validation'] for r in rr);assert abs(v-row['brier'])<1e-14
 return dict(passed=True,cases=48,brier_rows=count,max_absolute_brier_error=maxerr,constructor_capacity_equality_checks=constructor_capacity,fourcell_capacity_equality_checks=fourcell_capacity,singleton_endpoint_exact_checks=endpoint,smallK_query_zero_checks=small,smallK_max_prediction_difference=maxquery,E09_scoped_exact_prediction_arrays=replay,E09_replay_scope='U diagonal all constructors; G diagonal geometric/paper20; plain mean; G stochastic constructors intentionally excluded because initialization seeds now coupled across construction geometry',construction_repair_events=repairs,construction_warning_events=warnings,original_outer_test_scored=False,scope='Consulted-family development; arithmetic, capacity and scoped replay audit, not independent confirmation')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--data',type=Path,required=True);p.add_argument('--e09',type=Path,required=True);a=p.parse_args();print(json.dumps(audit(a.run,a.data,a.e09),indent=2))
