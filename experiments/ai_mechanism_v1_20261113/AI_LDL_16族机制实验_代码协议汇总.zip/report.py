from pathlib import Path
import json,csv,statistics as st
from docx import Document
from docx.shared import Pt,Inches
from docx.oxml.ns import qn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;P=Path('/workspace/work/ai_mechanism_v1_private_20261113');S=json.loads((R/'SUMMARY.json').read_text());C=S['contrasts'];F=list(csv.DictReader(open(R/'family_summary.csv')))
resources=[json.loads(p.read_text()) for p in P.rglob('record_PRIVATE.json')];coverage=[]
for f in F:
 stats=[s for c in resources if c['family']==f['family'] for s in c['statistics'] if s['weight']=='L' and s['mask']!='Full'];train_n=len(json.loads((P/f['family']/'repeat_1/split_PRIVATE.json').read_text())['train_indices']);coverage.append({'family':f['family'],'coverage':st.mean(s['coverage'] for s in stats),'prototype_slot_fraction':st.mean(s['prototype_slots_residual']/train_n for s in stats),'accepted_leaves':st.mean(s['accepted_leaves'] for s in stats)})
with open(R/'representation_summary.csv','w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(coverage[0]));w.writeheader();w.writerows(coverage)
fig,axes=plt.subplots(1,2,figsize=(12,7),sharey=True)
for ax,key,title in zip(axes,['geometry','grouping'],['Local minus uniform geometry (raw readout)','Ball minus coverage-matched mean (local geometry)']):
 values=[float(f[key]) for f in F];ax.barh(range(len(F)),values,color=['#24795b' if v<0 else '#bc5b45' for v in values]);ax.axvline(0,color='black',lw=.7);ax.set_title(title,fontsize=10);ax.set_xlabel('Brier difference (negative favors first method)');ax.set_yticks(range(len(F)),[f['family'] for f in F]);ax.invert_yaxis();ax.grid(axis='x',alpha=.2)
fig.suptitle('Fixed mechanism study: 16 known feature families, 5 object-level splits\nReduced budgets 20/40/60/80%, 3 shared random mask banks',fontsize=11);fig.tight_layout();fig.savefig(R/'family_contrasts.png',dpi=180);fig.savefig(R/'family_contrasts.pdf');plt.close(fig)
lines=['# Applied Intelligence：16特征族固定机制实验报告','2026年11月13日。冻结协议AI-MECHANISM-v1-fixed-20261113；全部80组预测冻结后统一评分。已知对象级基准实验，不是从未咨询过的独立确认数据；未提供受试者分组泛化结论。','## 完成与完整性','16个特征族×5次划分全部完成，无按结果删除数据集。共1040个预算位置、12560行汇总指标。每个划分3套共享随机成本排序×20/40/60/80%预算，Full计算一次；固定校准zeta=.5、平滑alpha=.5。指标含Brier、TV、KL、JS，主要评价为Brier。','源代码、输入原始文件及转换数组、划分和预测均校验哈希。评分前检查所有预测的维度、非负性、概率和及训练均值回退；原始测试标签没有进入该完整性检查。统一评分后，另以独立写法复核1920个Brier，最大差值为'+f"{S['independent_brier_audit']['maximum_absolute_difference']:.3g}"+'。','## 主要结果','差值均为前者减后者，负数表示前者误差更小。每个特征族先合并5次重复、3套成本排序和4档缩减预算，再等权汇总16个族；Full单列。重复、预算和随机种子不是独立数据集。','| 比较 | 等族平均Brier差 | 前者更低的族 | 前者更高的族 |','|---|---:|---:|---:|']
for key,label in [('geometry','局部L几何 − 均匀U几何；raw读出'),('grouping','粒球 − 同覆盖均值；局部L几何'),('grouping_random','粒球 − 同覆盖随机分组；局部L几何'),('grouping_global','粒球 − 全局均值收缩；局部L几何'),('ball_raw','粒球收缩 − raw；局部L几何')]:
 c=C[key];lines.append(f"| {label} | {c['equal_family_mean']:+.8f} | {c['families_negative']}/16 | {c['families_positive']}/16 |")
lines+=['## 逐族结果','| 特征族 | 几何差L−U | 分组差粒球−同覆盖均值 | 粒球−同覆盖随机 |','|---|---:|---:|---:|']
for f in F:lines.append(f"| {f['family']} | {float(f['geometry']):+.8f} | {float(f['grouping']):+.8f} | {float(f['grouping_random']):+.8f} |")
geom=C['geometry'];group=C['grouping'];rand=C['grouping_random']
lines+=['## 如何解释','局部几何与分组效果需分开解读：几何改变或粒球相对raw的改善，均不能替代与同覆盖均值和同覆盖随机分组的比较。这里的粒球读出为新残差表示，未覆盖对象保留原标签；它与旧严格O1全局回退读出不同，不能套用旧O1的性能或可行性结果。']
if group['equal_family_mean']>=0:
 lines+=['固定设置下，粒球相对同覆盖均值的等族平均差未降低；当前结果不支持把接受球均值分组本身写成稳定精度优势。应完整呈现这一结果，再决定是否开发新的训练内表示，而不是在测试数据上改阈值后覆盖本次冻结记录。']
else:
 lines+=['固定设置下，粒球相对同覆盖均值的等族平均差降低，但应同时呈现逐族方向和随机分组结果；已知基准上的平均改善不能直接视为普遍优势或原创性证明。']
if geom['equal_family_mean']>=0:lines+=['局部几何相对均匀几何的等族平均差也未降低；当前固定几何方案的跨族优势尚不足以支持整体优越性表述。']
else:lines+=['局部几何相对均匀几何的等族平均差降低，但族间方向需保留。要将收益归因于信息对齐，还需单独冻结并执行更广的权重错配及相关方法对照。']
lines+=['## 表示与资源','表示汇总另见representation_summary.csv：覆盖比例和原型槽数仅描述平滑表示，源特征和源权重仍需存储。它们不能当作端到端模型字节或特征获取成本节省。',f"两进程并发下各组wall时间合计{S['total_case_wall_seconds_including_two_worker_contention']:.1f}秒，单进程最高观测RSS为{S['maximum_worker_peak_rss_bytes']/1024**2:.1f}MiB。该时间含共享CPU竞争，不是方法间速度比较。",'## 数据与复现','3族数据复用原私有缓存；新增13族原始MAT已存私有Drive的两个缓存包。转换规则与SHA清单可从原始缓存重建冻结NPY，不重复存大体积转换数组。GitHub只发布代码、协议、来源、校验和汇总；行号、个体预测和第三方原始数据留私有缓存。','78页含Declarations稿件本轮不改。当前结果用于决定研究路线；还未完成外部特征选择器比较、受试者分组验证及完整新稿改写。固定随机子集上的机制结果不等于特征选择性能优越。','## 后续修改原则','先据本次逐族结果确定可支持的贡献，再单独冻结后续表示开发和外部比较方案。若继续开发粒球读出，只在训练内调整并记录新版本，保留v1作为公开基线；不能根据本轮外层测试结果挑选设置后称为未经查看的验证。']
md='\n\n'.join(lines).replace('|\n\n|','|\n|')+'\n';(R/'REPORT.md').write_text(md)
doc=Document();style=doc.styles['Normal'];style.font.name='Calibri';style.font.size=Pt(10);style.element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei');i=0
while i<len(lines):
 l=lines[i]
 if l.startswith('|'):
  block=[]
  while i<len(lines) and lines[i].startswith('|'):
   vals=[x.strip() for x in lines[i].strip('|').split('|')]
   if not all(set(v)<=set('-: ') for v in vals):block.append(vals)
   i+=1
  t=doc.add_table(rows=0,cols=len(block[0]));t.style='Light Shading Accent 1'
  for row in block:
   for c,v in zip(t.add_row().cells,row):c.text=v
  continue
 if l.startswith('# '):doc.add_heading(l[2:],0)
 elif l.startswith('## '):doc.add_heading(l[3:],1)
 else:doc.add_paragraph(l)
 i+=1
doc.add_page_break();doc.add_heading('逐族机制差值图',1);doc.add_picture(str(R/'family_contrasts.png'),width=Inches(6.2));doc.save(R/'AI_LDL_16族跨数据集机制实验报告_20261113.docx')
(R/'DECISION.json').write_text(json.dumps({'completed_cases':80,'outer_test_scored':True,'protocol_changed_during_scoring':False,'geometry_equal_family_brier_difference':geom['equal_family_mean'],'grouping_equal_family_brier_difference':group['equal_family_mean'],'grouping_random_equal_family_brier_difference':rand['equal_family_mean'],'geometry_families_better':geom['families_negative'],'grouping_families_better':group['families_negative'],'claim_scope':'Fixed known-benchmark mechanism evidence; no automatic novelty or submission-readiness claim','manuscript_changed':False,'next':'Use these preserved cross-family results to decide defensible contribution; any new representation or external-selector study needs its own pre-score freeze.'},indent=2));print('Report generated')
