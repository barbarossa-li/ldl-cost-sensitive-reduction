from pathlib import Path
import os,json,shutil,subprocess,sys,argparse
B=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=a.output.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Use a new empty output directory')
out.mkdir(parents=True,exist_ok=True);shutil.copytree(B/'frozen_main',out/'method')
for p in (B/'recorded_source').glob('*.py'):shutil.copy2(p,out/p.name)
method=out/'method';env=os.environ.copy();env.update(AI_LDL_MAIN=str(method),AI_LDL_E02=str(method/'dependencies/e02'),AI_LDL_E0=str(method/'dependencies/e0'),AI_LDL_E03=str(method/'dependencies/e03'),AI_LDL_CORE=str(method/'dependencies/frozen_core'),AI_LDL_DATA=str(a.data.resolve()),AI_LDL_MAIN_PRIVATE=str(out/'generated_main_splits'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
subprocess.run([sys.executable,str(method/'runner.py'),'prepare','--data',str(a.data.resolve()),'--output',env['AI_LDL_MAIN_PRIVATE']],env=env,check=True)
subprocess.run([sys.executable,str(out/'check.py')],env=env,check=True)
for action in ['prepare','run','score']:subprocess.run([sys.executable,str(out/'run.py'),action],env=env,check=True)
subprocess.run([sys.executable,str(out/'audit.py')],env=env,check=True)
ref=json.loads((B/'records/RESULTS.json').read_text())['summary'];actual=json.loads((out/'RESULTS.json').read_text())['summary'];key=lambda r:tuple(r[k] for k in ['family','mask','mode','target']);look={key(r):r for r in actual};assert len(ref)==len(actual);delta=max(abs(r['brier']-look[key(r)]['brier']) for r in ref);assert delta<=1e-12
(out/'PORTABLE_COMPARISON.json').write_text(json.dumps({'summary_rows':len(ref),'maximum_absolute_difference':delta,'scope':'Artifact replay, not new independent data evidence'},indent=2));print('Portable replay PASS',delta)
