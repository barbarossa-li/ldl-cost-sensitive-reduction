"""Rebind preserved sources to local, authorized cached inputs in a new run."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys
B=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--core',type=Path,required=True);p.add_argument('--image-cache',type=Path,required=True);p.add_argument('--fit-cache',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--run',action='store_true');a=p.parse_args();out=a.output.resolve();core=a.core.resolve();image=a.image_cache.resolve();fit=a.fit_cache.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Use a new empty output directory; a completed run is immutable.')
out.mkdir(parents=True,exist_ok=True)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
expected=json.loads((B/'records/SELECTION_PROTOCOL.json').read_text())['input_sha256']
checks=[image/'data/official_labels_split.npz',image/'data/official_resnet18_features.npy',fit/'fitted.npz']
for path in checks:
 hashes=[v for k,v in expected.items() if Path(k).name==path.name]
 if len(hashes)!=1 or digest(path)!=hashes[0]:raise SystemExit('Cached input hash mismatch: '+str(path))
for path in (B/'recorded_source').glob('*'):
 text=path.read_text().replace('/workspace/work/asc_review/code_bundle',str(core)).replace('/workspace/work/asc_experiments',str(image))
 (out/path.name).write_text(text)
for name in ['fitted.npz','reference.npy']:
 src=fit/name
 if not src.exists():raise SystemExit('Missing private cached fit: '+str(src))
 shutil.copy2(src,out/name)
# Prior full-size matrix need not be distributed: validate recomputation against
# the reference vector and the historical aggregate validation checks.
shutil.copy2(B/'records/optimization_validation.json',out/'optimization_validation.json')
if not a.run:print('Prepared',out);raise SystemExit(0)
subprocess.run(['g++','-O3','-march=native','-fopenmp','-ffp-contract=off','-fno-fast-math','-shared','-fPIC',str(out/'distance.cpp'),'-o',str(out/'distance.so')],check=True)
subprocess.run([sys.executable,str(out/'run_selection.py')],cwd=out,check=True)
result=json.loads((out/'SELECTION_FROZEN.json').read_text())
if not result['reference_matches_pilot_exactly']:raise SystemExit('Cache/reference mismatch')
subprocess.run([sys.executable,str(out/'postprocess.py')],cwd=out,check=True)
