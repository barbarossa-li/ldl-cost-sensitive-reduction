# Additional experiments — 13 November 2026

27 actual training-selection runs on three families and three known splits; all selections were frozen before new test scoring. Six pre-existing image-pool endpoints were also re-evaluated from official original images and 60-rater labels.

Read REPORT.md and records/FINAL_SUMMARY.json. These are exploratory checks on known data, not independent confirmatory samples or a full 25-task grid rerun. Raw images, labels, per-query vectors, model weights and image features are excluded from this public packet. Full per-query SQLite stores and image caches are preserved privately by the author.

## Reproduce

Use Python 3.12 with requirements.txt. `python reproduce.py --output /path/to/new_run --run` obtains the three public upstream descriptor datasets at their fixed versions, validates the exact original array hashes and runs the same 27 selections before test scoring. Expect about 20 minutes on the recorded host; other machines vary. Omit --run to prepare a new workspace only.

For image replay, also provide --images /path/to/SCUT-FBP5500_v2.1.zip and install the declared image dependencies. First retrieve the already verified local/private Drive cache according to datasets/SCUT_FBP5500 in the main repository; do not download the same official image archive again unnecessarily.

recorded_source/ and records/ preserve the exact script hashes/paths of the actual run. reproduce.py changes only environment-specific path bindings in fresh copies and creates a new protocol in the new output directory. It never overwrites the recorded results. The portable replay compares its own vector hashes with the nine published expected full_max hashes; raw older object vectors are not duplicated in this packet. Original held-out summaries and subsets are also compared.

The three geometries form nested contrasts, not a 2x2 factorial. All modes use the same TrainingGeometry cache for control; raw-mode RSS must not be presented as an optimized raw-distance implementation's memory cost. CPU time and process RSS are measured on a shared Linux host, not old Windows inference timings. Exact image-byte nonoverlap is not proof of subject-disjoint identity.

No original archive is publicly redistributed. Code licensing does not replace upstream dataset terms. Raw-data private caching and public code/summary publication follow the project cache policy.
