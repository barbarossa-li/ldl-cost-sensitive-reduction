from pathlib import Path
import json,csv,statistics as st
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
R=Path(__file__).resolve().parent;d=json.loads((R/'RESULTS.json').read_text());s=d['summary'];families=sorted(set(r['family'] for r in s));records=[json.loads(p.read_text()) for p in (R/'cases').rglob('record_PRIVATE.json')];contrasts=[];familyrows=[];capacity=[]
for mask in ['Full','cost40']:
 for geometry in ['U','G']:
  value=lambda f,m:next(r['brier'] for r in s if (r['family'],r['mask'],r['geometry'],r['method'])==(f,mask,geometry,m))
  for vote in ['uniform','mass']:
   for control in ['raw','direct_random_'+vote,'direct_mean_'+vote,'source_mean_half','source_ball_half']:
    delta=[value(f,'direct_ball_'+vote)-value(f,control) for f in families];contrasts.append({'mask':mask,'geometry':geometry,'vote':vote,'control':control,'equal_family_brier_difference':st.mean(delta),'families_better':sum(x<0 for x in delta),'families_worse':sum(x>0 for x in delta),'families_tied':sum(x==0 for x in delta)})
  for f in families:familyrows.append({'family':f,'mask':mask,'geometry':geometry,**{m:value(f,m) for m in ['raw','source_ball_half','source_mean_half','direct_ball_uniform','direct_ball_mass','direct_random_uniform','direct_random_mass','direct_mean_uniform','direct_mean_mass']}})
  a=[r for c in records for r in c['statistics'] if r['mask']==mask and r['geometry']==geometry];capacity.append({'mask':mask,'geometry':geometry,'coverage_mean':st.mean(r['coverage'] for r in a),'prototype_slot_fraction_mean':st.mean(r['prototype_slots']/r['source_objects'] for r in a),'numeric_array_byte_fraction_mean':st.mean(r['array_byte_fraction'] for r in a),'numeric_array_byte_fraction_total_weighted':sum(r['prototype_numeric_array_bytes'] for r in a)/sum(r['raw_numeric_array_bytes'] for r in a)})
for name,rows in [('contrasts.csv',contrasts),('family_summary.csv',familyrows),('capacity_summary.csv',capacity)]:
 with open(R/name,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'stage':'E0.5 direct prototype development','cases':48,'families':16,'metric_rows':len(d['rows']),'new_outer_test_scored':False,'contrasts':contrasts,'capacity':capacity,'decision':'Interface/capacity checks pass; fixed direct prototypes show mixed errors and limited compression. Current grouping does not establish broad superiority vs capacity-matched random groups or simple global shrinkage. Do not promote as validated contribution.','next':'Before broader evaluation, redesign the granulation objective around explicit prototype budgets and training-internal risk/storage curves. Preserve the strict accepted-leaf method as a baseline; do not silently loosen its constraints.'};(R/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
lines=['# E0.5：直接粒球原型检索的训练内开发报告','2026年11月13日。16个已咨询特征族×3训练内折，共48折；使用v1重复1训练池前min(192,ntrain)对象，与E0.4相同。通常128拟合/64验证，SJAFFE约99/50。全部预测冻结后评分，共1776行指标。本轮没有新外层测试评分。','## 实现了什么','接受球以训练缩放空间中的特征均值与标签均值表示，未覆盖样本保留单点。查询直接检索这些原型，而不是先检索全部源样本再平滑标签。固定k=5；不足5个原型时使用全部原型。均匀原型投票和按组内样本数投票两个规则均事先固定并完整报告。','使用U均匀和G特征级全局信息权重：G为拟合训练局部KL权重在源样本上的均值。查询不使用源对象局部权重，也不使用查询标签；仅需选定特征，保留训练Full校准与原始m。参数固定zeta=.5、kappa=.1等，不从内部结果选择投票规则或参数。','预测器独立存储所需特征中心、标签、组大小、所选列、缩放参数与G权重；状态复制后可脱离训练源模型推理。原始单点分支与旧U/G源样本5NN距离及预测精确一致。','## 对照如何匹配','随机分组只打乱被覆盖对象的组归属，保留相同被覆盖对象、残差点、组大小序列、原型槽位键和数值数组字节数；重新计算特征中心与标签均值，使用5个种子。报告每个种子损失的均值，不用平均预测集成或挑最好种子。','另有同一真实球特征中心、但将接受组标签替换为训练全局均值的对照，几何和容量完全相同；还有原始5NN、原源样本半强度粒球平滑、普通半强度全局均值收缩与纯全局均值。','## 开发结果','下表是前者direct_ball减各对照的等族平均Brier差；负数表示粒球误差较低。括号内为粒球误差更低的族数。各族先按验证对象数合并3折，Full和cost40分开报告。','| 掩码 | 几何 | 投票 | 对raw | 对同容量随机 | 对同中心全局均值标签 | 对普通半强度均值收缩 |','|---|---|---|---:|---:|---:|---:|']
for mask in ['Full','cost40']:
 for g in ['U','G']:
  for vote in ['uniform','mass']:
   rr=[r for r in contrasts if (r['mask'],r['geometry'],r['vote'])==(mask,g,vote)];get=lambda ctrl:next(r for r in rr if r['control']==ctrl);cells=[]
   for ctrl in ['raw','direct_random_'+vote,'direct_mean_'+vote,'source_mean_half']:
    r=get(ctrl);cells.append(f"{r['equal_family_brier_difference']:+.7f} ({r['families_better']}/16)")
   lines.append('| '+mask+' | '+g+' | '+vote+' | '+' | '.join(cells)+' |')
lines+=['G均匀投票相对raw的平均误差在Full和cost40均有小幅降低，但分别只有7/16和10/16族更低；对随机分组在两种掩码均只有7/16族更低，cost40平均差还为正。普通均值收缩在多数族仍更好。因此不能仅凭某个平均值改善就宣称分组独立有效；两个投票规则及全部阴性结果都保留。','## 原型容量与推理数组','| 掩码 | 几何 | 覆盖比例均值 | 槽数/源数均值 | 原型数组字节/单点数组字节均值 |','|---|---|---:|---:|---:|']
for r in capacity:lines.append(f"| {r['mask']} | {r['geometry']} | {r['coverage_mean']:.3f} | {r['prototype_slot_fraction_mean']:.3f} | {r['numeric_array_byte_fraction_mean']:.3f} |")
lines+=['上述只计独立预测器数值数组：选定特征中心、标签、组大小、所选列、缩放、权重与训练标签均值；不包含Python容器、标量元数据、训练数据、训练工作内存或私有缓存。字节分数既记录逐折均值，也在CSV提供总字节加权比例，不把均值冒充总存储节省。','G下逐折数组字节占比平均约0.920，原型槽数占比约0.918；说明接口实现了有限的推理表示压缩，但不是端到端内存节省，也没有降低同一特征预算下的查询特征获取成本。','## 为什么压缩幅度仍偏小','目前仍使用旧的严格接受球规则，未覆盖对象均保留单点，覆盖比例只有约13%–14%。这套低标签离散度准入主要服务于保守重构；直接改成原型检索后，仍不会自动产生较强压缩。该现象支持下一步明确调整研究目标，但没有证明所有粒球表示都无效。','## 验证','概率、维度、输入/预测哈希、训练与外层测试隔离、分组覆盖及空覆盖回退检查通过。1776个Brier按独立求和式复算，最大差约1.1e-16。全单点、相同容量随机、投票、常量特征与零信息、脱离训练源模型的状态推理均有技术检查。','## 下一版设计边界','下一阶段应单独冻结“目标原型预算优先”的粒球构造：在训练内比较固定容量下的风险与存储曲线，与同容量随机分组和可复现的普通原型方法对照。严格接受球方案保留为基线，不能悄悄调松原O1条件后继续沿用其保证。新预算构造尚未实现，也不代表已经建立新的贡献。','直接原型预测不同于旧的训练重构映射，不能自动沿用旧O1可行性或误差保证；本轮只检验训练内预测与表示容量。','本轮是已咨询数据上的开发，不是独立确认或新外部数据集结果；尚未完成新方法原创性核查、外部特征选择器比较及完整投稿稿改写。78页论文、已有v1结果和数据缓存保持不变。公开代码、协议、汇总与校验；实际行号、分组和逐样本预测存私有缓存。']
md='\n\n'.join(lines).replace('|\n\n|','|\n|')+'\n';(R/'REPORT.md').write_text(md)
doc=Document();style=doc.styles['Normal'];style.font.name='Calibri';style.font.size=Pt(9);style.element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei');i=0
while i<len(lines):
 l=lines[i]
 if l.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].startswith('|'):
   values=[v.strip() for v in lines[i].strip('|').split('|')]
   if not all(set(v)<=set('-: ') for v in values):rows.append(values)
   i+=1
  t=doc.add_table(rows=0,cols=len(rows[0]));t.style='Light Shading Accent 1'
  for row in rows:
   for c,v in zip(t.add_row().cells,row):c.text=v
  continue
 if l.startswith('# '):doc.add_heading(l[2:],0)
 elif l.startswith('## '):doc.add_heading(l[3:],1)
 else:doc.add_paragraph(l)
 i+=1
doc.save(R/'AI_LDL_E05_直接原型检索开发报告_20261113.docx');print('Report generated')
