# E0.6 budget-first prototype hierarchy — development evidence

48 training-internal folds, 16 consulted feature families. Fixed prototype budgets25/50/75/100%, U/G geometry, two votes and two prior strengths, with geometry-only bisection, deterministic Lloyd reference and size-matched random partitions. All12,720 metrics and negative outcomes are retained. Exact full-budget endpoint checks recover singleton/source5NN, including random seed/tie cases.

At the predeclared25% budget, G/uniform/half-prior candidate improves over same-capacity Lloyd in13/16 Full families and12/16 cost40 families. Label-priority gains over geometry-only remain inconsistent. Compression incurs a mean risk cost relative to the full same-prior model; this is a risk/capacity trade-off, not blanket superiority or established novelty.

Independent numeric arrays have exact byte count8*[K*(d+q+1)+4d+q]; Python/scalar metadata, training memory and caches are excluded. Feature acquisition remains the same selected P. This new fully covering budget method has no old O1 eligibility/guarantee. Known consulted-data development is not untouched confirmation.

Portable reproduction from the owner's authorized verified32-array cache:
`python reproduce.py --data /cache --output /new/empty/directory`
The launcher regenerates private split metadata, checks inputs, reruns48 folds, audits all metrics and compares summaries. No downloads or private data uploads occur. Python3.12/numpy2.3.5/scipy1.17.0; optional reports use python-docx/matplotlib. Individual arrays, group memberships and actual split indices are excluded. Raw data and all individual artifacts stay in private Drive caches. Original78-page manuscript and frozen v1 results remain unchanged.
