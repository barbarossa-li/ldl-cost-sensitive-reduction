from pathlib import Path
import json,csv,statistics as st
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
R=Path(__file__).resolve().parent;d=json.loads((R/'RESULTS.json').read_text());S=d['summary'];records=[json.loads(p.read_text()) for p in (R/'cases').rglob('record_PRIVATE.json')];families=sorted(set(r['family'] for r in S));comp=[];contrasts=[]
def value(f,mask,mode,target='raw'):return next(r['brier'] for r in S if (r['family'],r['mask'],r['mode'],r['target'])==(f,mask,mode,target))
for f in families:
 for mask in ['Full','cost40']:
  row={'family':f,'mask':mask,**{w:value(f,mask,w) for w in ['U','L','N','G']},'T_mean':st.mean(value(f,mask,'T'+str(i)) for i in range(5)),'N_ball':value(f,mask,'N','ball'),'N_covered_mean':value(f,mask,'N','covered_mean'),'N_random':value(f,mask,'N','random')};comp.append(row)
for mask in ['Full','cost40']:
 rows=[r for r in comp if r['mask']==mask]
 for key,a,b in [('N-L','N','L'),('N-U','N','U'),('N-G','N','G'),('N-T','N','T_mean'),('Nball-mean','N_ball','N_covered_mean'),('Nball-random','N_ball','N_random')]:
  v=[r[a]-r[b] for r in rows];contrasts.append({'mask':mask,'contrast':key,'equal_family_brier_difference':st.mean(v),'families_lower':sum(x<0 for x in v),'families_higher':sum(x>0 for x in v)})
hub=[]
for mode in ['U','L','N','G']:
 a=[r for c in records for r in c['diagnostics'] if r['mode']==mode];hub.append({'mode':mode,'mass_frequency_spearman_mean':st.mean(r['mass_frequency_spearman'] for r in a if r['mass_frequency_spearman'] is not None),'selection_weighted_mass_ratio_mean':st.mean(r['selected_mass_ratio'] for r in a if r['selected_mass_ratio'] is not None),'neighbor_gini_mean':st.mean(r['neighbor_count_gini'] for r in a),'effective_source_fraction_mean':st.mean(r['effective_source_fraction'] for r in a)})
energy=[]
for mode in ['L','N']:
 for target in ['ball','covered_mean','global_mean','random']:
  a=[r for r in d['decomposition'] if r['mode']==mode and r['target']==target];energy.append({'mode':mode,'target':target,'shift_energy':st.mean(r['prediction_shift_energy'] for r in a),'alignment_term':st.mean(r['residual_alignment_term'] for r in a),'brier_change':st.mean(r['brier_change'] for r in a)})
for name,rows in [('family_diagnostics.csv',comp),('contrasts.csv',contrasts),('hubness_summary.csv',hub),('shift_energy.csv',energy)]:
 with open(R/name,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'cases':48,'metric_rows':len(d['rows']),'families':16,'scope':'Post-v1 training-internal development only','contrasts':contrasts,'hubness':hub,'shift_energy':energy,'weight_rank1_energy_fraction_mean':st.mean(c['weight_rank1_energy_fraction'] for c in records),'source_weight_mass_cv_mean':st.mean(c['weight_row_mass_cv'] for c in records),'maximum_exact_decomposition_error':d['maximum_decomposition_error'],'new_outer_test_scored':False,'decision':'Row-amplitude bias supported as partial mechanism; normalization helps old L but does not establish local shape advantage vs G/T. Do not promote N to a validated main method. Redesign query-to-prototype representation and independently examine global information geometry.'};(R/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
lines=['# 训练内机制诊断：权重幅值与粒球读出','2026年11月13日。48折均已完成：16个已咨询特征族，使用v1重复1的训练池前min(192,ntrain)对象做3折。通常128拟合/64验证，SJAFFE约99/50。未读取新外层测试标签；这些仍是开发数据，不是独立确认。','## 找到的问题','原权重W的整行平均值在样本间不同，使源样本的全部距离被共同放大或缩小。即使相对特征形状相同，低整行幅值的源样本也可能更容易成为邻居。N候选把每行W除以其训练Full行均值；零权重行退回全1，子集与查询使用固定训练归一化，不访问查询标签。','这是诊断性干预，不是已验证的新主方法。对照包括U均匀、L旧局部、G训练样本平均后的全局特征权重，以及T：归一化N的5个整行错配排列。全部设置固定zeta=.5，不从验证结果挑zeta或阈值。','## 邻居集中现象','下表为48折×2掩码的描述性均值。相关系数比较原始W行幅值与邻居出现次数；负值表示低幅值源更常被选。Gini越高表示越集中，选中幅值比是按邻居频次加权后的原始幅值/未加权平均幅值。','| 几何 | 幅值与频次Spearman | 选中幅值比 | 邻居Gini |','|---|---:|---:|---:|']
for r in hub:lines.append(f"| {r['mode']} | {r['mass_frequency_spearman_mean']:.3f} | {r['selection_weighted_mass_ratio_mean']:.3f} | {r['neighbor_gini_mean']:.3f} |")
lines+=['归一化减轻了旧L相对U额外出现的低幅值源吸引和邻居集中，支持它是部分问题来源。U也有相关性，因此不能把所有相关性都解释为权重导致的因果效应。W的第一奇异分量能量比例均值约'+f"{summary['weight_rank1_energy_fraction_mean']:.1%}"+'，并非普遍接近秩一，不能用“全部权重秩一塌缩”概括结果。','## 候选修正的开发结果','Brier差为前者减后者；负数更好。每族内部按验证对象数合并三个折，再等权汇总16族；Full和cost40分开报告。','| 掩码 | 比较 | 平均Brier差 | 前者更低的族 |','|---|---|---:|---:|']
for r in contrasts:lines.append(f"| {r['mask']} | {r['contrast']} | {r['equal_family_brier_difference']:+.8f} | {r['families_lower']}/16 |")
lines+=['N多数情况下优于旧L，但对U、G和T没有稳定优势：N对G仅在Full和cost40各3/16族更低，对T的等族平均差均为正。修正一个偏差不等于建立有效的局部信息形状信号；本轮不把N替换进稿件后宣称优势。','## 粒球为什么看起来影响很小','当前表示先找源样本邻居，再将每个被接受叶内的标签替换为该叶均值；查询仍通过原源样本检索，粒球不是直接检索单位。低离散度准入又保证叶内标签彼此接近，因此均值替换往往只造成微小移动。','| 几何 | 读出 | 预测移动能量 | 相对raw的Brier变化 |','|---|---|---:|---:|']
for r in energy:lines.append(f"| {r['mode']} | {r['target']} | {r['shift_energy']:.8g} | {r['brier_change']:+.8f} |")
lines+=['L下粒球预测移动能量约为同覆盖均值的4.2%；N下约为2.7%。误差分解ΔBrier=2·mean〈raw−y,δ〉+mean||δ||²在全部记录中通过数值校验；并非移动越大越好，必须同时看移动与残差的对齐项。','对训练表示有精确恒等式：mean_i||R_i−L_i||²=(1/n)Σ_B |B|V(B)。若接受叶满足V(B)≤κV0，则该平均移动≤κV0×coverage。六个实际拟合表示已核验该等式与界。它解释训练平均移动的限制，不单独保证查询风险或泛化误差。','## 验证与边界','2064行开发指标已按另一种求和实现独立复算；预测文件、输入缓存及数据隔离检查通过。零信息回退、行尺度不变性、源方向、仅选定查询列、子集单调性和错配行结构检查均通过。N的分母依赖训练标签，不能自动继承旧几何在重新拟合或标签扰动下的稳定性结果；它也不同于旧严格O1记录。','## 下一版应改什么','先保留G作为必须战胜的特征级信息加权基线，不继续把源样本幅值当作局部有效性。若保留局部信息，需证明相对G与错配控制存在可重复的增益；当前N未达到这一点。','粒球应从事后标签平滑改为可独立检验的查询到原型表示：接受球用特征原型和标签原型表示，未覆盖对象保留残差点。下一阶段应固定同样的特征预算、相同原型容量、同覆盖随机分组及全局收缩对照；只在训练内选择预测规则，另立新版本后再评价。该设计尚未实现，不能提前写成本文已证实的贡献。','本轮未修改78页稿件、v1冻结协议或其负结果，也未重新运行外层测试。无需新数据下载；原始输入仍复用已验证的私有缓存。']
md='\n\n'.join(lines).replace('|\n\n|','|\n|')+'\n';(R/'REPORT.md').write_text(md)
doc=Document();stl=doc.styles['Normal'];stl.font.name='Calibri';stl.font.size=Pt(10);stl.element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft YaHei');i=0
while i<len(lines):
 l=lines[i]
 if l.startswith('|'):
  block=[]
  while i<len(lines) and lines[i].startswith('|'):
   vals=[x.strip() for x in lines[i].strip('|').split('|')]
   if not all(set(v)<=set('-: ') for v in vals):block.append(vals)
   i+=1
  t=doc.add_table(rows=0,cols=len(block[0]));t.style='Light Shading Accent 1'
  for row in block:
   for c,v in zip(t.add_row().cells,row):c.text=v
  continue
 if l.startswith('# '):doc.add_heading(l[2:],0)
 elif l.startswith('## '):doc.add_heading(l[3:],1)
 else:doc.add_paragraph(l)
 i+=1
doc.save(R/'AI_LDL_E04_训练内机制诊断报告_20261113.docx');print('Report generated')
