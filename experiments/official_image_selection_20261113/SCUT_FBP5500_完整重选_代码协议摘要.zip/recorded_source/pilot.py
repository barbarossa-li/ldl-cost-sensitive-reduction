from pathlib import Path
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np,time,json,resource,sys,hashlib
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/asc_experiments')
sys.path.insert(0,'/workspace/work/asc_review/code_bundle')
from information_reduction.safe_extension import granulate
s=np.load(BASE/'data/official_labels_split.npz');indices=s['train'];X=np.asarray(np.load(BASE/'data/official_resnet18_features.npy')[indices],float);L=np.asarray(s['labels'][indices],float)
n,m=X.shape;p=L.mean(0);active=p>0;norm=np.log2(1/p[active].min()) if active.sum()>1 else 0.
Z=np.empty_like(X);W=np.empty_like(X);band=np.empty(m);start=time.perf_counter()
if (ROOT/'fitted.npz').exists():
 f=np.load(ROOT/'fitted.npz');Z=f['Z'];W=f['W'];band=f['band']
else:
 for a in range(m):
  v=X[:,a];z=(v-v.min())/(v.max()-v.min()) if v.max()>v.min() else np.zeros(n);Z[:,a]=z
  raw=np.abs(z[:,None]-z[None,:]);positive=raw[np.triu_indices(n,1)];positive=positive[positive>0];tau=float(np.median(positive)) if len(positive) else 1.
  K=np.exp(-raw**2/(2*tau**2));support=K.sum(1);other=support-1.;u=K@L/support[:,None];eta=other/(other+1.);regular=eta[:,None]*u+(1-eta[:,None])*p
  w=np.sum(regular[:,active]*np.log2(regular[:,active]/p[active]),axis=1)/norm if norm else np.zeros(n);W[:,a]=np.clip(w,0.,1.);band[a]=tau
  if a%32==0:print('FIT',a,'elapsed',time.perf_counter()-start,flush=True)
 np.savez(ROOT/'fitted.npz',Z=Z,W=W,band=band)
print('FIT DONE',time.perf_counter()-start,flush=True)
D=np.zeros((n,n));start=time.perf_counter()
for a in range(m):
 raw=np.abs(Z[:,a,None]-Z[None,:,a]);information=W[:,a,None]*raw/m;geometry=raw/m
 D+=(1-.1)*information+.1*geometry
D=np.maximum(D,D.T)
np.save(ROOT/'full_D.npy',D)
print('DISTANCE DONE',time.perf_counter()-start,flush=True)
start=time.perf_counter();result=granulate(D,L,[tuple(row) for row in X]);rec=np.tile(p,(n,1))
for B in result[1]:rec[B]=L[B].mean(0)
e=np.sum((L-rec)**2,axis=1);np.save(ROOT/'reference.npy',e)
record={'scope':'feasibility pilot only; not a completed deletion search','training_n':n,'m':m,'granulate_seconds':time.perf_counter()-start,'eligible_leaves':len(result[1]),'reference_mean_error':float(e.mean()),'reference_sha256':hashlib.sha256(e.astype('<f8').tobytes()).hexdigest(),'rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
(ROOT/'pilot.json').write_text(json.dumps(record,indent=2));print(record,flush=True)
