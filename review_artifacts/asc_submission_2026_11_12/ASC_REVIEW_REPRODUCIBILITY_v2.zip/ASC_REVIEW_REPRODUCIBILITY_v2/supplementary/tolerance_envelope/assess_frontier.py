"""Reconstruct only the training-defined storage-frontier endpoints."""
import os
os.environ.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
from pathlib import Path
from hashlib import sha256
from io import BytesIO
import json
import sqlite3
import sys
import time
from zipfile import ZipFile
import numpy as np

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--original-run", type=Path, required=True)
parser.add_argument("--original-return", type=Path, required=True)
parser.add_argument("--original-cache", type=Path, required=True)
parser.add_argument("--joint-results", type=Path, required=True)
parser.add_argument("--joint-protocol", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
ROOT = args.output.resolve()
(ROOT / "results").mkdir(parents=True, exist_ok=True)
RUN = args.original_run.resolve()
sys.path.insert(0, str(RUN))
import run_application as app

archive_path = args.original_return.resolve()
joint_path = args.joint_results.resolve()
plan_path = args.joint_protocol.resolve()
database_path = args.original_cache.resolve()
protocol = json.loads((RUN / "protocol.json").read_text())
identity = app.identity(protocol)
assert sha256(database_path.read_bytes()).hexdigest() == "fd5e4667c5a185cc418ac7c71047e1a45abc1ee04301f80523bf5cf1c9a95ada"
joint = json.loads(joint_path.read_text())
plan = json.loads(plan_path.read_text())
assert sha256(plan_path.read_bytes()).hexdigest() == joint["identity"]["joint_protocol_sha256"]
assert joint["complete"] and joint["tested"] == 512

with sqlite3.connect(database_path.resolve().as_uri() + "?mode=ro", uri=True) as database:
    assert database.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
    old = {
        tuple(map(int, key.split(","))) if key else (): blob
        for key, blob in database.execute("SELECT subset, values_blob FROM errors")
    }
full_key = tuple(range(512))
reference = np.frombuffer(old[full_key], dtype="<f8")
assert reference.shape == (3300,)

with ZipFile(archive_path) as archive:
    frozen = json.loads(archive.read("results/selection_frozen.json"))
    original_identity = frozen["identity"]
    assert identity["protocol_sha256"] == original_identity["protocol_sha256"]
    assert np.array_equal(reference, np.load(BytesIO(archive.read("results/Full_training_errors.npy"))))
    manifest = {int(r["mask_hex"], 16): r for r in json.loads(archive.read("results/oracle_audit.json"))["rows"]}
    for key, blob in old.items():
        saved = manifest[sum(1 << i for i in key)]
        assert saved["errors_sha256"] == sha256(blob).hexdigest()
    full_prediction = np.load(BytesIO(archive.read("results/Full_test_predictions.npy")))

candidates = []
for key, blob in old.items():
    error = np.frombuffer(blob, dtype="<f8")
    candidates.append(dict(selected=list(key), attributes=len(key),
                           maximum_increase=max(0.0, float((error-reference).max())),
                           errors_sha256=sha256(blob).hexdigest(), origin="original"))
seen = set(old)
for row, trial in zip(joint["rows"], plan["candidates"]):
    selected = tuple(sorted(set(range(512)) - set(trial["deleted"])))
    assert selected not in seen
    seen.add(selected)
    candidates.append(dict(selected=list(selected), attributes=len(selected),
                           maximum_increase=row["maximum_increase"],
                           errors_sha256=row["errors_sha256"], origin="independent"))
assert len(candidates) == len(seen) == 2043
frontier = []
best_dimensions = 513
for row in sorted(candidates, key=lambda r:(r["maximum_increase"], r["attributes"], r["selected"])):
    if row["attributes"] < best_dimensions:
        frontier.append(row)
        best_dimensions = row["attributes"]
assert len(frontier) == 6
(ROOT / "results/candidate_summaries.json").write_text(json.dumps(candidates, indent=2) + "\n")
(ROOT / "results/frontier_plan.json").write_text(json.dumps({
    "selection": "Minimize training-feature storage within the recorded candidate pool, at each recorded maximum-error threshold. Ties use sorted feature-index lexicographic order.",
    "subsets": 2043, "frontier": frontier, "test_outcomes_used_for_endpoint_selection": False,
}, indent=2) + "\n")

features = np.load(RUN / "data/RESNET18_FEATURES.npy")
with np.load(RUN / "data/LABELS60_AND_SPLIT.npz") as data:
    train_indices, test_indices, all_labels = (data[k] for k in ("train_indices","test_indices","labels60"))
assert train_indices.tolist() == frozen["train_indices"]
labels, test_truth = all_labels[train_indices], all_labels[test_indices]
tolerance = 1e-12
truth_max = labels.max(1, keepdims=True)
truth_top = labels >= truth_max - tolerance
truth_unique = truth_top.sum(1) == 1
truth_id = labels.argmax(1)
sorted_truth = np.sort(labels, axis=1)
margin = sorted_truth[:, -1] - sorted_truth[:, -2]

certificate_upper = margin**2/2
unique_cutoffs = np.unique((certificate_upper-reference-tolerance)[truth_unique])
certificate_knots = sorted({0.0, 0.6, *unique_cutoffs[(unique_cutoffs>0)&(unique_cutoffs<0.6)].tolist()})
(ROOT/"results/margin_certificate_profile.json").write_text(json.dumps({
    "unique_target_objects": int(truth_unique.sum()),
    "rows": [
        {"tolerance": tau, "certified": int(np.count_nonzero(truth_unique & (reference+tau+tolerance < certificate_upper)))}
        for tau in certificate_knots
    ],
}, indent=2)+"\n")

truth_top2_order = np.argsort(-labels, axis=1, kind="stable")
truth_top2 = np.zeros_like(labels, dtype=bool)
np.put_along_axis(truth_top2, truth_top2_order[:, :2], True, axis=1)
truth_top2_unique = sorted_truth[:, -2] - sorted_truth[:, -3] > tolerance


def rankloss(reconstruction):
    a, b = np.triu_indices(labels.shape[1], 1)
    gaps = labels[:, a] - labels[:, b]
    comparable = np.abs(gaps) > tolerance
    signed = (reconstruction[:, a] - reconstruction[:, b]) * np.sign(gaps)
    losses = (signed < -tolerance) + .5*(np.abs(signed) <= tolerance)
    denominators = comparable.sum(1)
    return np.divide((losses*comparable).sum(1), denominators,
                     out=np.zeros(len(labels)), where=denominators > 0), denominators > 0


def top2(values):
    order = np.argsort(-values, axis=1, kind="stable")
    top = np.zeros_like(values, dtype=bool)
    np.put_along_axis(top, order[:, :2], True, axis=1)
    sorted_values = np.sort(values, axis=1)
    unique = sorted_values[:, -2] - sorted_values[:, -3] > tolerance
    return top, unique

model = None
results = []
full_rec = None
for number, point in enumerate(frontier):
    selected = point["selected"]
    target = ROOT / "results" / f"endpoint_{number}.npz"
    if target.exists():
        with np.load(target) as saved:
            assert saved["selected"].tolist() == selected
            reconstruction, prediction = saved["reconstruction"], saved["prediction"]
        print("REUSE", number, len(selected), flush=True)
    else:
        if selected:
            if model is None:
                print("FIT ORIGINAL TRAINING GEOMETRY", flush=True)
                model = app.LowMemoryTrainingGeometry(features[train_indices].astype(float), labels,
                                                       kinds=["numerical"]*512)
            started = time.perf_counter()
            distance, keys = model.subset(selected)
            eligible = app.granulate(distance, labels, keys)[1]
            reconstruction = np.tile(labels.mean(0), (len(labels), 1))
            for ball in eligible:
                reconstruction[ball] = labels[ball].mean(0)
            del distance, keys, eligible
            print("RECONSTRUCTED", number, len(selected), round(time.perf_counter()-started, 2), flush=True)
        else:
            reconstruction = np.tile(labels.mean(0), (len(labels), 1))
        prediction = app.predict_five_neighbors(features[train_indices], labels, features[test_indices], selected)
        np.savez_compressed(target, selected=selected, reconstruction=reconstruction, prediction=prediction)
    error = np.sum((labels-reconstruction)**2, axis=1)
    error_digest = sha256(error.astype("<f8").tobytes()).hexdigest()
    if tuple(selected) in old:
        original_error = np.frombuffer(old[tuple(selected)], dtype="<f8")
        discrepancy = float(np.max(np.abs(error-original_error)))
        assert discrepancy <= tolerance
    else:
        discrepancy = None
        assert abs(max(0.0, float((error-reference).max()))-point["maximum_increase"]) <= tolerance
    assert error_digest == point["errors_sha256"], (number, "Error-vector digest mismatch")
    if number == 0:
        full_rec = reconstruction
        assert np.array_equal(prediction, full_prediction)
        full_top = full_rec >= full_rec.max(1, keepdims=True)-tolerance
        reference_correct = truth_unique & (full_top.sum(1)==1) & (full_rec.argmax(1)==truth_id)
        full_rank, valid_rank = rankloss(full_rec)
        full_top2, full_top2_unique = top2(full_rec)
        reference_top2_correct = truth_top2_unique & full_top2_unique & np.all(full_top2==truth_top2, axis=1)
    pred_top = reconstruction >= reconstruction.max(1, keepdims=True)-tolerance
    correct = truth_unique & (pred_top.sum(1)==1) & (reconstruction.argmax(1)==truth_id)
    rank, _ = rankloss(reconstruction)
    this_top2, this_top2_unique = top2(reconstruction)
    top2_correct = truth_top2_unique & this_top2_unique & np.all(this_top2==truth_top2, axis=1)
    tau = point["maximum_increase"]
    certified = truth_unique & (reference+tau+tolerance < margin**2/2)
    assert not np.any(certified & ~correct)
    stats = dict(
        endpoint=number, attributes=len(selected), stored_training_bytes=3300*4*len(selected),
        maximum_increase=tau, digest_reproduced=True, cached_error_replay_max_abs_diff=discrepancy,
        original_O1_violations=int(np.count_nonzero(error>reference+tolerance)),
        reference_top_set_changed=int(np.count_nonzero(np.any(pred_top!=full_top, axis=1))),
        reference_correct_unique=int(reference_correct.sum()),
        reference_correct_lost=int(np.count_nonzero(reference_correct & ~correct)),
        top1_wrong_to_correct=int(np.count_nonzero(truth_unique & (full_top.sum(1)==1) & ~reference_correct & correct)),
        top1_reference_tie_to_correct=int(np.count_nonzero(truth_unique & (full_top.sum(1)>1) & correct)),
        top2_wrong_to_correct=int(np.count_nonzero(truth_top2_unique & full_top2_unique & ~reference_top2_correct & top2_correct)),
        pairwise_rank_better=int(np.count_nonzero(valid_rank & (rank<full_rank-tolerance))),
        mean_training_error=float(error.mean()),
        top2_reference_correct=int(reference_top2_correct.sum()),
        top2_reference_correct_lost=int(np.count_nonzero(reference_top2_correct & ~top2_correct)),
        pairwise_rank_eligible_objects=int(valid_rank.sum()),
        pairwise_rank_worse=int(np.count_nonzero(valid_rank & (rank>full_rank+tolerance))),
        target_unique_max_objects=int(truth_unique.sum()), margin_certified_correct=int(certified.sum()),
        test=app.metrics(test_truth, prediction), source=point["origin"],
    )
    results.append(stats)
    temporary = ROOT / "results/endpoint_assessment.pending"
    temporary.write_text(json.dumps({"complete":len(results)==len(frontier), "rows":results},indent=2)+"\n")
    temporary.replace(ROOT / "results/endpoint_assessment.json")
    print("ASSESSED", number, len(selected), "Brier", stats["test"]["brier"], flush=True)
print("ALL FRONTIER ENDPOINTS ASSESSED", flush=True)
