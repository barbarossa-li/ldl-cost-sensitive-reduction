from pathlib import Path
import json
p=Path(__file__).resolve().parent;s=json.loads((p/'SUMMARY.json').read_text());u=json.loads((p/'SUPPLEMENT_SUMMARY.json').read_text());c=json.loads((p/'CONVERGENCE_SUMMARY.json').read_text());a=json.loads((p/'EVIDENCE_AUDIT.json').read_text());b=json.loads((p/'SUPPLEMENT_AUDIT.json').read_text());d=json.loads((p/'CONVERGENCE_AUDIT.json').read_text())
def original(stage,key):return next(r for r in s[stage]['equal_family_means'] if r['key']==key)
def half(stage,mask,method):return next(r['baseline_half_prior_mean_brier'] for r in u[stage]['common_prior_primary_GG50_contrasts'] if r['mask']==mask and r['baseline']==method)
def diagnostic(stage,key):return next(r for r in c[stage]['equal_family_means'] if r['key']==key)
lines=['# LDL 论文：外部基线、跨领域评估与阴性对照复核报告','','## 本轮结论','','机制证据变得更清楚，但尚未形成跨领域准确率普遍领先的结果。16个已咨询特征族上，预设GG50几何原型优于本轮固定默认外部输出；在新的Ren_Cecps打包版本上，预设Full/GG50的Brier为0.590613，高于AA-kNN20的0.587933和原生工具库RkNN-LDL的0.581965。原定主配置保持不变，未用较有利的25%次要点替换。','','真实关联权重优于五次标签打乱和五次轴对应打乱的平均个体风险，支持该权重在本轮管线内包含有用的关联结构；它仍不保证优于均匀几何，例如新语料cost40下GG50略差于UU50。','','新语料Full/GG50保留同布局单点原型模型50.48%的数值状态字节，Brier从单点端点0.600159降为0.590613。这是相对于同类原型读出的压缩改善，不是所有预测模型中的最小存储或最好误差。','','## 协议与审计','','E11默认基线与E12新语料的代码/协议先冻结于 b03a0d8e7fdf578ab0fc6f39669501784c057bb5，随后53组预测全部冻结再评分。E13/E14是父研究预测已生成、结果尚未评分/查看时追加并冻结的次要机制核查；E15则是看过初轮结果后明确标记的数值收敛诊断，不能改称新的独立确认。','','合计3445条聚合预测记录、7项指标共24115个数值通过独立复算；最大指标差约8.9e-16。复用相同对象/划分的记录不计作独立重复实验。E11的816份原型／均值参照逐位重放E0.10；E13的212份正/均匀参照与父研究逐位一致，并核对530个预先指定的排列。E14的530份半先验输出及E15的212份独立推理状态输出逐位核对通过。','','## 外部默认基线与共同先验','','原生指固定工具库输出，不代表已核实原作者实现。每种输出都另列与本方法相同的半权重训练均值混合，避免把一般先验收缩归为几何效果。RkNN训练带宽适配明确单列，与原生输出共用同一次拟合。下表为Brier，越低越好。','','|数据范围/特征|输出|原始输出|半先验输出|','|---|---|---:|---:|']
for stage,label in [('e11','已咨询16族'),('e12','新Ren版本')]:
 for mask in ['Full','cost40']:
  lines.append(f"|{label}/{mask}|GG50固定主方法|—|{original(stage,mask+'__GG50')['brier']:.6f}|")
  for method in ['AAKNN5','AAKNN20','SABFGS','RKNN_native','RKNN_train_gamma']:lines.append(f"|{label}/{mask}|{method}|{original(stage,mask+'__'+method)['brier']:.6f}|{half(stage,mask,method):.6f}|")
lines+=['','SA-BFGS最初106次拟合有94次到达500次迭代上限。其差结果不能作为方法优越性的充分证据。数值复核仅提高上限至20000，保留原目标、种子和划分，66/106满足停止判据、40仍到上限；训练目标不增，但测试误差常变差。以下结果是后验数值诊断，原500轮结果完整保留。','','|范围/特征|SA20000原始Brier|SA20000半先验Brier|半先验数值状态字节|','|---|---:|---:|---:|']
for stage,label in [('e11','已咨询16族等权'),('e12','新Ren版本')]:
 for mask in ['Full','cost40']:
  raw=diagnostic(stage,mask+'__SABFGS20000__native');hh=diagnostic(stage,mask+'__SABFGS20000__half_prior');lines.append(f"|{label}/{mask}|{raw['brier']:.6f}|{hh['brier']:.6f}|{hh['array_bytes']:.0f}|")
lines+=['','线性参照的独立推理状态可以远小于原型状态。例如新语料Full半先验SA为8864字节、GG50为170688字节。这里比较的是各自明确导出的数值状态，不是匹配容量，也不含训练缓存、Python对象或硬件峰值内存；不能宣称原型对所有模型都更省存储。','','## 新语料版本与全部原型预算','','采用PyLDL固定提交中的Ren_Cecps：32420行、100特征、8标签；文献常见35096行，差异来源未核实，因此只称该打包版本。未发现其出现在已检查的既有26任务结果清单及公共路径中。','','五组各384行拟合、512行测试；共2560个测试对象。32203个完整特征组中的重复特征对象不跨训练、测试及五组分配。文档/博客/作者ID缺失，仍不是文档/作者分组验证。测试只覆盖固定子集和有限训练规模，不等同完整语料训练或多个独立新数据集。','','下表保留全部预设比例点（均为半先验），数值状态比例相对本方法同掩码的100%端点。50%是预先指定主点，其余均为次要曲线。','','|几何|预算%|Full Brier|Full字节占比|cost40 Brier|cost40字节占比|','|---|---:|---:|---:|---:|---:|']
for g in ['GG','UU']:
 for budget in ['25','50','75','100']:
  full=original('e12','Full__'+g+budget);co=original('e12','cost40__'+g+budget);lines.append(f"|{g}|{budget}|{full['brier']:.6f}|{full['mean_array_fraction']:.4f}|{co['brier']:.6f}|{co['mean_array_fraction']:.4f}|")
lines+=['','## 标签关联与轴对应阴性对照','','LP只在学习G时打乱拟合标签，原型标签与训练先验仍使用真实拟合标签；AX只打乱G与特征轴的对应，保持权重直方图。每类五个种子分别计算风险再平均，没有使用预测集成。所有模型匹配原型数和实际数组字节。下表为GG50减对照的平均Brier，负值有利于真实关联权重。','','|范围/特征|减LP平均风险|减AX平均风险|减均匀UU50风险|','|---|---:|---:|---:|']
for stage,label in [('e11','已咨询16族等权'),('e12','新Ren版本')]:
 for mask in ['Full','cost40']:
  vals=[next(r['mean_brier_difference'] for r in u[stage]['negative_control_contrasts'] if r['mask']==mask and r['control']==control) for control in ['label_permutation','axis_permutation','uniform']];lines.append('|'+label+'/'+mask+'|'+'|'.join(f'{v:+.7f}' for v in vals)+'|')
lines+=['','## 稿件修改与下一步','','Applied Intelligence方向的叙事可围绕信息加权构造、加权检索、精确预算和独立数值状态组织，Declarations应保留于文内。原78页稿及旧理论、表格继续存档；新路线需要重新组织稿件，不能把实质重写称为仅换双栏的等内容压缩。旧的未发布80例分支不能与当前协议混用。','','主张可收紧为：在可复现的同容量原型管线中，区分并量化标签关联几何在构造和检索中的作用，报告同类原型表示的风险—容量关系。当前证据不支持普遍优于外部LDL方法、普遍协同或完整资源最优。','','接下来优先做公平训练内调参及直接原型压缩参照（尤其ProLSFEO-LDL）的可核实实现，之后再固定配置寻找更多未咨询的原生LDL域。受试者/文档分组与完整训练/硬件资源比较仍待完成。新增同样划分上的内部表格不能替代这些证据。','','## 文件与来源','','公开包仅含汇总风险、完整预算/种子汇总、审计脚本和协议链接。原始矩阵及逐对象记录按私有缓存策略管理；公共包不包含实际划分、排列、推理权重或缓存定位信息。','', '- PyLDL固定源码：https://github.com/SpriteMisaka/PyLDL/tree/80b2d188c11b640bce7accbc9a88dac89c48a56f','- RkNN-LDL原论文：https://doi.org/10.1016/j.patcog.2024.111006','- LDL/AA/SA来源：https://doi.org/10.1109/TKDE.2016.2545658','- Ren版本对照文献：https://www.ijcai.org/proceedings/2019/0518.pdf','- 直接原型约简相关工作：https://doi.org/10.3390/app10093089','']
(p/'REPORT.md').write_text('\n'.join(lines))
