from pathlib import Path
import os,sys,json,csv
import numpy as np
BASE=Path('/workspace/work/ai_e17_prolsfeo_20261115');sys.path.insert(0,str(BASE/'source'));from reconstruction import *
sys.path.insert(0,'/workspace/work/ai_external_v1_20261114/source');import runner as r

def main():
 assert Path('/workspace/work/ai_e16_20261115/run/ALL_PREDICTIONS_FROZEN.json').exists(), 'Wait for E16 global freeze too'
 freeze=json.loads((BASE/'run/ALL_PREDICTIONS_FROZEN.json').read_text());assert len(freeze['records'])==3;protocol=json.loads((BASE/'source/PROTOCOL.json').read_text());parent=r.verify();rows=[];audit={'passed':True,'records':3,'states_checked':0,'fitness_checked':0,'max_state_error':0.,'incomplete_cases':[]};OUT=BASE/'public';OUT.mkdir(exist_ok=True)
 for name,h in freeze['records'].items():
  path=BASE/'run'/name;assert sha(path)==h;rec=json.loads(path.read_text());case=path.parent;assert rec['protocol_sha256']==sha(BASE/'source/PROTOCOL.json') and rec['source_manifest_sha256']==sha(BASE/'source/MANIFEST.json')
  for k,fname in [('predictions_sha256','predictions_PRIVATE.npz'),('states_sha256','inference_state_PRIVATE.npz'),('genome_sha256','genome_PRIVATE.npz')]:assert sha(case/fname)==rec[k]
  f=next(x for x in parent['stages']['e11']['families'] if x['family']==rec['family']);X,Y=r.checked_data(Path('/workspace/work/asc_experiments/data'),f);fit=np.array(rec['fit_indices']);held=np.array(rec['validation_indices']);pred=dict(np.load(case/'predictions_PRIVATE.npz'));st=dict(np.load(case/'inference_state_PRIVATE.npz'));bits=np.load(case/'genome_PRIVATE.npz')['bits'];parts=[np.array(z) for z in rec['inner_folds']]
  _,group=np.unique(X[fit],axis=0,return_inverse=True)
  for i in range(10):
   for j in range(i):assert not set(group[parts[i]])&set(group[parts[j]])
  assert sorted(np.concatenate(parts).tolist())==list(range(len(fit)))
  status=rec['details']['status'];assert (status=='complete')==(rec['details']['generations_completed']==500)
  if status!='complete':audit['incomplete_cases'].append(rec['family'])
  if st:
   assert sum(v.nbytes for v in st.values())==rec['numeric_array_bytes'];v=predict(st,X[held]);err=float(abs(v-pred['ProLSFEO_reconstruction']).max());assert err<1e-12;audit['max_state_error']=max(audit['max_state_error'],err);audit['states_checked']+=1;best=Fitness(X[fit],Y[fit],parts)(bits);assert abs(best-rec['details']['best_inner_kl'])<1e-12;audit['fitness_checked']+=1
   assert np.array_equal(pred['ProLSFEO_reconstruction_halfprior'],.5*v+.5*Y[fit].mean(0))
  assert np.array_equal(pred['AA4_stable_halfprior'],.5*pred['AA4_stable']+.5*Y[fit].mean(0))
  old=np.load(Path('/workspace/work/ai_external_v1_20261114/run/e11')/rec['family']/'fold_0/predictions_PRIVATE.npz')
  for key in ['Full__GG50','Full__UU50','Full__GG25','Full__UU25','Full__GG100','Full__UU100','plain_mean']:pred['parent_'+key]=old[key]
  for key,v in pred.items():
   r.valid(v,len(held),Y.shape[1]);rows.append({'family':rec['family'],'fold':0,'model':key,'search_status':status if key.startswith('ProLSFEO') else 'reference','generations_completed':rec['details']['generations_completed'] if key.startswith('ProLSFEO') else '', 'selected_prototypes':rec['selected_prototype_count'] if key.startswith('ProLSFEO') else '', 'union_features':rec['union_feature_count'] if key.startswith('ProLSFEO') else '', 'numeric_array_bytes':rec['numeric_array_bytes'] if key.startswith('ProLSFEO') else '', 'search_seconds':rec['details']['seconds'] if key.startswith('ProLSFEO') else '',**r.metrics(Y[held],v)})
 with (OUT/'CASE_METRICS.csv').open('w',newline='') as file:w=csv.DictWriter(file,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 save(OUT/'AUDIT.json',audit);print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
