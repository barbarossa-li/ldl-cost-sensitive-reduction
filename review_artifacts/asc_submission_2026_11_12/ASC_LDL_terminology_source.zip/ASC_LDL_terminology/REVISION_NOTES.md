# Review-aligned manuscript revision — 13 November 2026

This source revises the 12 November terminology manuscript against the paragraph-level report and its GitHub-code addendum. It does not modify frozen experiment implementations or replace experiment outputs.

## Corrected
- Independent node eligibility in base pseudocode; fixed geometry inputs and FIFO processing.
- Complete anchored-oracle specification, distance-ordered seed pairs, budget counting, whole-leaf safety and explicit anchored dependency.
- Zero-reference exclusion described as the frozen implementation policy rather than mathematical infeasibility; original missing-run statuses retained.
- Bandwidth, gain thresholds, safe-leaf numerical slack, radius-default inactivity and distinct mathematical symbols.
- Dominant-label margin result moved to a proposition in the method section, with domain and strict-inequality limits.
- Base/anchored complexity, including seed-pair sorting; relation memory distinguished from measured peak memory and feature acquisition budgets.
- Training/test/development, source/identity, CV, predictor and metric conventions; baseline fidelity and different missing-output causes.
- Precise archive file map and frozen-record versus original-data reproduction scope.
- Existing M2B result summarized, recorded hardware identifiers and timing ranges disclosed, rounded tolerance knots distinguished from exact thresholds.
- KL attribution changed from Shannon 1948 to Kullback and Leibler 1951; notation, capitalization, quotes and figure captions cleaned.

## Preserved evidence
All pre-existing numeric table rows and plotted result files are preserved. Added M2B means and timing ranges are calculated from already-frozen CSV/JSON records, not new experimental runs. Synthetic eight-object data are regenerated from the frozen seed and verified against the existing figure's dependencies.

## Remaining evidence limits
No new full original-data selection, image inference or hardware timing is claimed. The published light records do not contain the full raw return archive, image-pipeline SQLite vectors, all query-pool disjointness inputs, measured selection peak memory or a verified subject-disjoint evaluation. The manuscript now states these limits; extra experiments are not fabricated. Bibliographic correction targets KL attribution; a fresh full-text verification of every related-work paper is outside this revision.

## Report-item disposition

| Report items | Disposition in this revision |
| --- | --- |
| A1–A3 | Node predicate and oracle pseudocode corrected; code order and anchored dependency specified. |
| A4 | Actual zero-reference implementation policy disclosed with an analytic counterexample; frozen exclusions unchanged. |
| A5–A8 | Missing values/rules supplied, loss guarantee narrowed, inactive default radius stated and singleton/generalization claim corrected. |
| B1–B4 | Complexity and sorting work corrected, projection-class justification added, domains/FIFO specified and symbol collisions removed. |
| B5–B6 | Seeds, cost rule, normalization and source files specified; unverified row mapping and subject-disjointness remain disclosed limitations. |
| B7–B10 | Baseline fidelity, prediction/metric rules, distinct missing statuses, signed-rank ties and permutation/Holm conventions documented. |
| B11–B13 | Prefix enumeration clarified; joint geometry and nonmonotone search/tolerance interpretations retained; no new independent-ablation claims. |
| B14–B15 | Object-level ordering loss defined; sufficient margin result moved into theory and its empirical coverage kept separate. |
| B16–B18 | Coordinate budgets distinguished from acquisition/extraction, training selection resource limits stated, available hardware and timing ranges reported. |
| B19 | Exact knot file located; rounded knots and stored hash flags distinguished from independent replay. |
| B20 | Captions expanded; synthetic data/check restored; existing M2B results summarized. |
| B21 and C | KL source checked against DOI metadata; neutral related-work wording, sentence case, quotes, entry file and notation corrected. |

The suggestions to add independent geometry-factor ablations, measured selection peak memory, subject-aware experiments and full original-data reruns require new evidence. They are addressed as limits of the current study rather than presented as completed experiments.


## Additional evidence integrated — 13 November 2026

The subsequent supplement adds 27 actual selection runs across three known feature families, nine exact original-method replays, 81 cross-evaluator endpoint checks, measured n=192 process resources and an official 5,500-image extraction/prediction replay at six frozen endpoints. Earlier numeric tables and plotted figures are retained. New tables are explicitly separate. These exploratory contrasts are not a complete factorial ablation or unseen-data confirmation. Subject-disjoint evaluation and full 3,300-object selection remain uncompleted; the streaming pilot is not counted as a completed experiment. Original raw data and individual vectors remain private. Public code/protocol/results: experiments/additional_20261113 in the companion repository.
