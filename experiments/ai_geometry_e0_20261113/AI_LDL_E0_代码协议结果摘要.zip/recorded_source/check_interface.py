"""Independent frozen-reference and behavioral tests for candidate E0 API."""
from pathlib import Path
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import sys,json,hashlib,inspect,numpy as np
from model import NumericalPrototypeModel,CORE
sys.path.insert(0,str(CORE/'prediction_interface'))
from directed_predictor import DirectedNeighborPredictor
from information_reduction.safe_extension import granulate as reference_granulate
R=Path(__file__).resolve().parent
checks=[]
def passed(name,**details):checks.append({'check':name,'passed':True,**details})
def invalid(fn):
 try:fn()
 except (ValueError,TypeError,IndexError):return
 raise AssertionError('Invalid input unexpectedly accepted')
rng=np.random.default_rng(20261113)
for n,m,q in [(8,3,3),(12,4,2)]:
 X=rng.normal(size=(n,m));X[:,-1]=4.;L=rng.dirichlet(np.ones(q),n)
 if q==3:L[:,2]=0;L/=L.sum(1,keepdims=True)
 model=NumericalPrototypeModel(X,L,k=2);old=DirectedNeighborPredictor(X,L,kinds=['numerical']*m,k=2)
 assert np.array_equal(model.W,np.asarray(old.geometry.weights).T)
 assert np.array_equal(model.bandwidth,np.asarray(old.geometry.bandwidths))
 largest=0.
 for mask in range(2**m):
  P=tuple(a for a in range(m) if mask>>a&1);expected,keys=old.geometry.subset(P);actual=model.training_distances(P)
  assert np.array_equal(expected,actual)
  incoming=model.incoming_selected(X[:,P],P);largest=max(largest,float(np.max(np.abs(incoming.T-old.geometry.directed(P)))))
  assert np.array_equal(incoming,old.incoming(X,P))
  assert np.array_equal(model.predict_selected(X[:,P],P,readout='raw'),old.predict(X,P))
  part=model.representation(P);ref=reference_granulate(expected,L,keys);legacy=np.tile(L.mean(0),(n,1))
  for leaf in ref[1]:legacy[leaf]=L[leaf].mean(0)
  assert part['leaves']==tuple(map(tuple,ref[0])) and part['accepted']==tuple(map(tuple,ref[1]))
  assert np.array_equal(legacy,part['ball_global_legacy'])
  for mode in ['U','G']:
   assert np.array_equal(model.training_distances(P,mode,'max'),model.training_distances(P,mode,'mean'))
  for readout in ['raw','ball_residual','ball_global_legacy']:
   pred,ids=model.predict_selected(X[:,P],P,readout=readout,return_neighbors=True)
   assert np.isfinite(pred).all() and np.min(pred)>=0 and np.allclose(pred.sum(1),1,rtol=0,atol=1e-12)
   assert np.array_equal(ids,model.neighbors(X[:,P],P))
 assert largest<1e-12
 passed('Frozen reference: weights, bandwidths, exact train distances, source orientation, raw predictions and legacy oracle',n=n,m=m,subsets=2**m,orientation_max_abs_error=largest)
# Deliberately asymmetric geometry catches accidental query->source orientation.
X=np.array([[0.,0.],[.3,2.],[1.2,1.],[4.,.2]]);L=np.array([[.95,.05],[.6,.4],[.4,.6],[.3,.7]])
model=NumericalPrototypeModel(X,L,k=2);P=(0,1);d=model.directed_training(P);assert np.max(np.abs(d-d.T))>1e-5
manual=np.zeros_like(d)
for i in range(4):
 for j in range(4):
  for a in P:
   raw=abs(model.Z[i,a]-model.Z[j,a]);manual[i,j]+=((1-model.zeta)*model.W[i,a]*raw+model.zeta*raw)/model.m
assert np.allclose(model.incoming_selected(X,P).T,manual,rtol=0,atol=1e-15)
passed('Nontrivial asymmetric source orientation independently checked',maximum_asymmetry=float(np.max(np.abs(d-d.T))))
# Partial coverage distinguishes residual retention from global fallback.
X=np.array([[0.]]*4+[[1.]]*4);L=np.array([[.9,.1]]*4+[[.1,.9],[.9,.1],[.1,.9],[.9,.1]])
model=NumericalPrototypeModel(X,L,k=2);rep=model.representation((0,));covered=rep['covered'];assert covered.sum()==4
assert np.array_equal(rep['ball_residual'][~covered],L[~covered]);assert np.array_equal(rep['ball_global_legacy'][~covered],np.tile(L.mean(0),(4,1)))
assert not np.array_equal(rep['ball_residual'],rep['ball_global_legacy'])
for seed in range(10):
 rnd=model.randomized_representation((0,),seed)
 assert sorted(map(len,rnd['groups']))==sorted(map(len,rep['leaves']))
 assert sum(len(c) for c,f in zip(rnd['groups'],rnd['accepted_flags']) if f)==int(covered.sum())
 assert len({i for c in rnd['groups'] for i in c})==8
 for c,f in zip(rnd['groups'],rnd['accepted_flags']):
  if not f:assert np.array_equal(rnd['readout'][list(c)],L[list(c)])
passed('Partial coverage, unchanged residual labels, distinct legacy readout and 10 capacity-matched random partitions',covered=int(covered.sum()),residual=int((~covered).sum()))
# Coherent noisy groups: nontrivial prototype aggregation, all-covered branch.
X=np.array([[0.]]*4+[[1.]]*4);L=np.array([[.85,.15],[.9,.1],[.95,.05],[.9,.1],[.1,.9],[.15,.85],[.05,.95],[.1,.9]])
model=NumericalPrototypeModel(X,L,k=2);rep=model.representation((0,));assert rep['covered'].all();assert not np.array_equal(rep['raw'],rep['ball_residual']);assert np.array_equal(rep['ball_residual'],rep['ball_global_legacy'])
passed('All-covered nontrivial aggregation')
# All constant attributes: no coverage for heterogeneous labels, empty prediction.
X=np.ones((6,3));L=np.array([[.9,.1],[.8,.2],[.6,.4],[.3,.7],[.2,.8],[.1,.9]])
model=NumericalPrototypeModel(X,L,k=2);rep=model.representation((0,1));assert not rep['covered'].any();assert np.array_equal(rep['ball_residual'],L)
for readout in ['raw','ball_residual','ball_global_legacy']:
 pred=model.predict_selected(np.empty((3,0)),(),readout=readout);assert np.array_equal(pred,np.tile(L.mean(0),(3,1)))
assert np.array_equal(model.neighbors(np.array([[7.,8.]]),(0,1)),np.array([[0,1]]))
passed('All-uncovered, empty subset, constant columns and stable index ties')
# Interface invariance, irrelevant columns including NaNs, and source immutability.
X=rng.normal(size=(12,4));L=rng.dirichlet([1,1,1],12);Q=rng.normal(size=(7,4));model=NumericalPrototypeModel(X,L,k=3);P=(0,2);savedW=model.W.copy();pred=model.predict_full(Q,P)
assert np.array_equal(pred,model.predict_selected(Q[:,P],P));changed=Q.copy();changed[:,1]=np.nan;changed[:,3]=1e100;assert np.array_equal(pred,model.predict_full(changed,P))
batched=np.vstack([model.predict_selected(Q[i:i+1,P],P) for i in range(7)]);assert np.array_equal(pred,batched)
order=[6,1,5,0,2,4,3];again=model.predict_selected(Q[order][:,P],P);assert np.array_equal(again,pred[order]);assert model.predict_selected(np.empty((0,2)),P).shape==(0,3)
L[:]=[1,0,0];X[:]=999;assert np.array_equal(pred,model.predict_full(Q,P));assert np.array_equal(model.W,savedW)
evaluated=model.evaluate_selected(Q[:,P],P)
for readout in ['raw','ball_residual','ball_global_legacy']:assert np.array_equal(evaluated['predictions'][readout],model.predict_selected(Q[:,P],P,readout=readout))
assert not model.W.flags.writeable and not model.L.flags.writeable
assert all('label' not in name.lower() and 'truth' not in name.lower() for name in inspect.signature(model.predict_selected).parameters)
passed('Selected-only/full compatibility, irrelevant features, batching, query order, zero queries, immutable fitted inputs and no query-label API')
pi=rng.permutation(model.n);W=model.weights('S',pi);assert np.array_equal(W,model.W[pi]);assert np.array_equal(np.sort(W,axis=0),np.sort(model.W,axis=0))
passed('Row-shuffled weights preserve every feature marginal and full row structure')
for Pbad in [(1,0),(0,0),(-1,), (4,),(False,True)]:invalid(lambda:model.predict_selected(np.ones((2,len(Pbad))),Pbad))
invalid(lambda:model.predict_selected(np.ones((2,4)),(0,2)));invalid(lambda:model.predict_selected(np.array([[np.nan]]),(0,)));invalid(lambda:model.weights('S',[0]*model.n));invalid(lambda:model.predict_selected(np.ones((2,1)),(0,),readout='unknown'))
invalid(lambda:NumericalPrototypeModel(np.ones((2,1)),np.array([[1,0],[0,1]]),k=5));invalid(lambda:NumericalPrototypeModel(np.ones((2,1)),np.array([[0.,0.],[1,0]]),k=1))
passed('Invalid selections, query widths, selected NaNs, permutations, readouts, k and nonprobability labels rejected')
model=NumericalPrototypeModel(np.arange(12.).reshape(6,2),np.ones((6,1)),k=2);assert np.array_equal(model.W,np.zeros((6,2)));assert np.array_equal(model.predict_selected(np.array([[100.,-4.]]),(0,1)),np.ones((1,1)))
passed('Single active label and extrapolated numerical queries')
result={'passed':True,'checks':checks,'reference_subset_cases':24,'scope':'Functional/equivalence and structural API checks only; no dataset validation or outer-test metrics.'};(R/'INTERFACE_CHECKS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
