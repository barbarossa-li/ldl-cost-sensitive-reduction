from pathlib import Path
import argparse,json,os,shutil,subprocess,sys,hashlib
B=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--e0-records',type=Path);p.add_argument('--run',action='store_true');a=p.parse_args();out=a.output.resolve();data=a.data.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Use a new empty output directory')
for path,h in json.loads((B/'records/PROTOCOL.json').read_text())['input_hashes'].items():
 if path.endswith('.npy') and hashlib.sha256((data/Path(path).name).read_bytes()).hexdigest()!=h:raise SystemExit('Input cache mismatch')
out.mkdir(parents=True);dep=out/'e0_dependency';dep.mkdir()
for name in ['model.py','run_pilot.py']:(dep/name).write_text((B/'e0_dependency'/name).read_text().replace('/workspace/work/asc_experiments/data',str(data)))
if a.e0_records:shutil.copytree(a.e0_records.resolve(),dep/'cases')
for f in (B/'recorded_source').glob('*.py'):shutil.copy2(f,out/f.name)
env=os.environ.copy();env['AI_LDL_E0']=str(dep);env['AI_LDL_CORE']=str(B/'frozen_core');env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
(out/'LOCAL_BINDINGS.json').write_text(json.dumps({'data':str(data),'e0_dependency':str(dep),'core':env['AI_LDL_CORE']},indent=2))
if not a.run:print('Prepared',out);raise SystemExit(0)
for cmd in [('check_calibration.py',),('run_e02.py','prepare'),('run_e02.py','run'),('run_e02.py','score')]:subprocess.run([sys.executable,str(out/cmd[0]),*cmd[1:]],env=env,cwd=out,check=True)
ref=json.loads((B/'records/RESULTS.json').read_text())['summary'];actual=json.loads((out/'RESULTS.json').read_text())['summary'];key=lambda x:tuple(x[k] for k in ['dataset','mask','calibration','zeta','weight','readout']);lookup={key(r):r for r in actual};assert len(ref)==len(actual);delta=max(abs(r[m]-lookup[key(r)][m]) for r in ref for m in ['brier_mean','tv_mean','kl_mean','js_mean']);assert delta<=1e-12
(out/'PORTABLE_COMPARISON.json').write_text(json.dumps({'summary_rows':len(ref),'metrics_compared':4*len(ref),'maximum_absolute_difference':delta,'e0_private_replay_available':a.e0_records is not None,'scope':'Artifact reproduction, not new independent data evidence'},indent=2));print('Portable comparison passed',delta)
