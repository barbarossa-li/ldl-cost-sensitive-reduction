from pathlib import Path
import json,argparse,itertools
import numpy as np

def pool(rows):
 out={}
 for stage,family,key in sorted({(r['stage'],r['family'],r['key']) for r in rows}):
  rr=[r for r in rows if r['stage']==stage and r['family']==family and r['key']==key];n=sum(r['n_validation'] for r in rr);out[stage,family,key]=sum(r['brier']*r['n_validation'] for r in rr)/n
 return out

def summarize(parent,e13,e14):
 null=json.loads((e13/'RESULTS_PUBLIC.json').read_text());overlay=json.loads((e14/'RESULTS_PUBLIC.json').read_text());lookup=pool(null['rows']);ol=pool(overlay['rows']);answer={}
 for stage in ['e11','e12']:
  raw=json.loads((parent/stage/'RESULTS_PUBLIC.json').read_text());families=sorted({r['family'] for r in raw['family_summary']});original={(r['family'],r['key']):r for r in raw['family_summary']};negatives=[];halves=[];nullrows=[]
  for mask in ['Full','cost40']:
   per=[]
   for f in families:
    p=lookup[stage,f,mask+'__GG50'];u=lookup[stage,f,mask+'__UU50'];lp=float(np.mean([lookup[stage,f,mask+'__LP'+str(j)] for j in range(5)]));ax=float(np.mean([lookup[stage,f,mask+'__AX'+str(j)] for j in range(5)]));item={'family':f,'mask':mask,'GG50':p,'UU50':u,'LP_mean_individual_risk':lp,'AX_mean_individual_risk':ax};per.append(item);nullrows.append(item)
   for control,col in [('label_permutation','LP_mean_individual_risk'),('axis_permutation','AX_mean_individual_risk'),('uniform','UU50')]:
    diffs={r['family']:r['GG50']-r[col] for r in per};negatives.append({'mask':mask,'control':control,'mean_brier_difference':float(np.mean(list(diffs.values()))),'negative':sum(d < -1e-12 for d in diffs.values()),'tie':sum(abs(d)<=1e-12 for d in diffs.values()),'positive':sum(d>1e-12 for d in diffs.values()),'family_differences':diffs})
   for base in ['AAKNN5','AAKNN20','SABFGS','RKNN_native','RKNN_train_gamma']:
    fs=[f for f in families if (stage,f,mask+'__'+base+'__half_prior') in ol];d={f:original[f,mask+'__GG50']['brier']-ol[stage,f,mask+'__'+base+'__half_prior'] for f in fs};halves.append({'mask':mask,'baseline':base,'complete_families':len(fs),'total_families':len(families),'GG50_mean_brier':float(np.mean([original[f,mask+'__GG50']['brier'] for f in fs])),'baseline_half_prior_mean_brier':float(np.mean([ol[stage,f,mask+'__'+base+'__half_prior'] for f in fs])),'mean_brier_difference':float(np.mean(list(d.values()))),'negative':sum(x < -1e-12 for x in d.values()),'tie':sum(abs(x)<=1e-12 for x in d.values()),'positive':sum(x>1e-12 for x in d.values()),'family_differences':d})
  answer[stage]={'scope':'Same cases and data as parent;pre-outcome secondary supplements, not new confirmation','negative_control_contrasts':negatives,'negative_control_family_risks':nullrows,'common_prior_primary_GG50_contrasts':halves,'null_seed_aggregation':'Risk averaged across five individual predictors;not their prediction ensemble'}
 return answer
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--parent',type=Path,required=True);p.add_argument('--e13',type=Path,required=True);p.add_argument('--e14',type=Path,required=True);a=p.parse_args();print(json.dumps(summarize(a.parent,a.e13,a.e14),indent=2))
