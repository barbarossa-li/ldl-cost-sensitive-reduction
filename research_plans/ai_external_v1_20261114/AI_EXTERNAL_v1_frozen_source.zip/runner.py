"""Frozen external-default probe and prospective Ren packaged-variant evaluation."""
from pathlib import Path
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
os.environ['KERAS_BACKEND']='torch';os.environ.setdefault('MPLCONFIGDIR','/tmp/ldl_matplotlib')
import sys,json,hashlib,time,argparse,warnings,gc,traceback
import numpy as np
ROOT=Path(__file__).resolve().parent
os.environ['AI_LDL_E0']=str(ROOT/'deps/e0');os.environ['AI_LDL_CORE']=str(ROOT/'deps/frozen_core');sys.path[:0]=[str(ROOT/'vendor'),str(ROOT/'deps'),str(ROOT/'deps/e02')]
from calibrated import CalibratedPrototypeModel
from prototype import PrototypePredictor
from budget import geometry,bisection_path
import torch,keras
torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
from pyldl.algorithms import AA_KNN,SA_BFGS,RKNN_LDL
from pyldl.algorithms.utils import kernel,pairwise_euclidean
from sklearn.metrics.pairwise import rbf_kernel
EXTERNAL=('AAKNN5','AAKNN20','SABFGS','RKNN_native','RKNN_train_gamma')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def verify():
 for n,h in json.loads((ROOT/'MANIFEST.json').read_text()).items():
  if sha(ROOT/n)!=h:raise ValueError('Changed source '+n)
 return json.loads((ROOT/'PROTOCOL.json').read_text())
def known_design(f,fi):
 N=f['N'];nt=min(384,7*N//10);nv=min(512,N-nt);seed=2026111300+100*(fi+1)+1;order=np.random.default_rng(seed).permutation(N);excluded=order[:nv];pool=order[nv:nv+nt][:192]
 costs=np.random.default_rng(202611130000+fi+1).integers(1,11,f['m']);orderp=np.random.default_rng(seed+100000).permutation(f['m']);P=tuple(sorted(map(int,orderp[np.cumsum(costs[orderp])<=40*int(costs.sum())//100])))
 return pool,excluded,{'Full':tuple(range(f['m'])),'cost40':P}
def blocks(n,seed):return np.array_split(np.random.default_rng(seed).permutation(n),3)
def novel_design(X):
 _,inv=np.unique(X,axis=0,return_inverse=True);order=np.argsort(inv,kind='stable');groups=np.split(order,np.flatnonzero(np.diff(inv[order]))+1);perm=np.random.default_rng(202611150012).permutation(len(groups));pos=0;cases=[];seen=set()
 for fold in range(5):
  parts=[]
  for count in [384,512]:
   selected=[];n=0
   while n<count:
    if pos>=len(perm):raise ValueError('Insufficient distinct feature groups')
    g=int(perm[pos]);pos+=1;assert g not in seen;seen.add(g);selected.append(groups[g]);n+=len(groups[g])
   parts.append(np.sort(np.concatenate(selected))[:count])
  cases.append(tuple(parts))
 for i,(fit,held) in enumerate(cases):
  for j,(otherfit,otherheld) in enumerate(cases):
   if i!=j:assert not set(inv[np.r_[fit,held]])&set(inv[np.r_[otherfit,otherheld]])
  assert not set(inv[fit])&set(inv[held])
 m=X.shape[1];costs=np.random.default_rng(202611150013).integers(1,11,m);featureorder=np.random.default_rng(202611150014).permutation(m);P=tuple(sorted(map(int,featureorder[np.cumsum(costs[featureorder])<=40*int(costs.sum())//100])))
 return cases,{'Full':tuple(range(m)),'cost40':P}
def scaled(X,Q,P):
 A=X[:,P];B=Q[:,P];lo=A.min(0);span=A.max(0)-lo
 return np.divide(A-lo,span,out=np.zeros_like(A),where=span>0),np.divide(B-lo,span,out=np.zeros_like(B),where=span>0)
def valid(v,n,q,tol=1e-5):
 v=np.asarray(v)
 if v.shape!=(n,q) or not np.isfinite(v).all() or np.any(v<0) or np.max(abs(v.sum(1)-1))>tol:raise ValueError('Invalid probability output')
 return float(np.max(abs(v.sum(1)-1)))
class LossAudit(keras.callbacks.Callback):
 def __init__(self):super().__init__();self.points=[]
 def on_epoch_end(self,epoch,logs=None):
  loss=float((logs or {})['loss'])
  if not np.isfinite(loss):raise FloatingPointError('Nonfinite upstream RKNN training loss')
  if epoch in [1,500,1000]:self.points.append({'epoch':int(epoch),'loss':loss})
def external(X,L,Q,masks,fi,fold,epochs=1000):
 values={};details={};failures={}
 for mi,(mask,P) in enumerate(masks.items()):
  A,B=scaled(X,Q,P)
  for method_index,method in enumerate(EXTERNAL[:4]):
   key=f'{mask}__{method}';seed=int((202611150000+1000*fi+100*fold+10*mi+method_index)%(2**32));t=time.perf_counter();info={'seed':seed};keys=[key]+([f'{mask}__RKNN_train_gamma'] if method=='RKNN_native' else [])
   try:
    with warnings.catch_warnings(record=True) as caught:
     warnings.simplefilter('always')
     if method.startswith('AAKNN'):
      model=AA_KNN(k=int(method[5:]),random_state=seed);model.fit(A,L);v=model.predict(B)
     elif method=='SABFGS':
      import pyldl.algorithms._specialized_algorithms as spec
      original=spec.minimize;diagnostics=[]
      def observed(*args,**kwargs):
       r=original(*args,**kwargs);diagnostics.append({'success':bool(r.success),'status':int(r.status),'iterations':int(r.nit),'message':str(r.message),'objective':float(r.fun),'gradient_max':float(abs(r.jac).max())});return r
      spec.minimize=observed
      try:model=SA_BFGS(random_state=seed);model.fit(A,L,max_iterations=500,convergence_criterion=1e-7);v=model.predict(B)
      finally:spec.minimize=original
      info['optimizer']=diagnostics
     else:
      keras.backend.clear_session();cb=LossAudit();model=RKNN_LDL(k=20,alpha=1e-3,beta=1e-6,random_state=seed);model.fit(A,L,epochs=epochs,kernel=True,sparse=True,verbose=0,callbacks=[cb]);v=model.predict(B);info['training_checkpoints']=cb.points
      training_state=model._to_numpy(model._X);gamma=float(1/(2*np.mean(pairwise_euclidean(training_state,training_state))**2));inds=model._aaknn._knn.kneighbors(B)[1];rho=np.average(model._to_numpy(model._rho)[inds],axis=1,keepdims=True);nn=np.average(model._aaknn._D[inds],axis=1);adapt=rho*nn+(1-rho)*model._to_numpy(model._call(rbf_kernel(B,training_state,gamma=gamma)));info['training_only_gamma']=gamma;info['adapter_max_mass_error']=valid(adapt,len(Q),L.shape[1]);values[f'{mask}__RKNN_train_gamma']=adapt
     info['max_mass_error']=valid(v,len(Q),L.shape[1]);values[key]=v;info['warnings']=[{'type':w.category.__name__,'message':str(w.message)} for w in caught]
   except Exception as exc:
    for k in keys:values.pop(k,None);failures[k]={'error_type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
   info['seconds']=time.perf_counter()-t;details[key]=info
   if 'model' in locals():del model
   gc.collect()
 return values,details,failures

def own(X,L,Q,masks):
 m=CalibratedPrototypeModel(X,L,zeta=.5);out={};stats={};ks={str(p):max(1,p*m.n//100) for p in [25,50,75,100]}
 for mask,P in masks.items():
  for g in ['U','G']:
   D,_=geometry(m,P,g);path=bisection_path(D,L,list(ks.values()),0.);raw=PrototypePredictor(m,P,g)
   for b,k in ks.items():
    proto=PrototypePredictor(m,P,g,path[k]);v=.5*proto.predict(Q[:,P])+.5*m.p;key=f'{mask}__{g}{g}{b}';valid(v,len(Q),L.shape[1],1e-12);out[key]=v;stats[key]={'K':k,'array_bytes':proto.array_bytes(),'array_fraction':proto.array_bytes()/raw.array_bytes()}
 out['plain_mean']=np.tile(m.p,(len(Q),1));return out,stats

def known_reference(e10,family,fold,fit,held,excluded):
 folder=e10/family/f'fold_{fold}';record=folder/'record_PRIVATE.json';fr=json.loads((e10/'ALL_PREDICTIONS_FROZEN.json').read_text());assert sha(record)==fr['records'][str(record.relative_to(e10))];rec=json.loads(record.read_text());anchor=json.loads((ROOT/'PROTOCOL.json').read_text())['stages']['e11'];assert fr['protocol_sha256']==anchor['E10_protocol_sha256'] and fr['source_manifest_sha256']==anchor['E10_manifest_sha256'];assert rec['fit_indices']==fit.tolist() and rec['validation_indices']==held.tolist() and rec['excluded_original_test_indices']==excluded.tolist();assert sha(folder/'predictions_PRIVATE.npz')==rec['predictions_sha256'];out={};stats={};st={r['key']:r for r in rec['statistics']}
 with np.load(folder/'predictions_PRIVATE.npz') as arr:
  for mask in ['Full','cost40']:
   for g in ['U','G']:
    for b in ['25','50','75','100']:
     old=f'{mask}__{g}__geometric__{b}__{g}__a0.5';key=f'{mask}__{g}{g}{b}';out[key]=arr[old];stats[key]={k:st[old][k] for k in ['K','array_bytes','array_fraction']}
  out['plain_mean']=arr['plain_mean']
 return out,stats

def one_case(X,L,f,fi,fold,fit,held,excluded,masks,out,e10=None,epochs=1000):
 assert not set(fit)&set(held) and not (set(fit)|set(held))&set(excluded)
 if e10 is None:pred,stats=own(X[fit],L[fit],X[held],masks)
 else:pred,stats=known_reference(e10,f['family'],fold,fit,held,excluded)
 ext,diagnostics,failures=external(X[fit],L[fit],X[held],masks,fi,fold,epochs=epochs);pred.update(ext);assert len(pred)+len(failures)==27
 out.mkdir(parents=True,exist_ok=True);np.savez_compressed(out/'predictions_PRIVATE.npz',**pred);save(out/'record_PRIVATE.json',{'family':f['family'],'fold':fold,'fit_indices':fit.tolist(),'validation_indices':held.tolist(),'excluded_original_test_indices':excluded.tolist(),'predictions_sha256':sha(out/'predictions_PRIVATE.npz'),'protocol_sha256':sha(ROOT/'PROTOCOL.json'),'source_manifest_sha256':sha(ROOT/'MANIFEST.json') if (ROOT/'MANIFEST.json').exists() else 'synthetic-only','prototype_statistics':stats,'model_diagnostics':diagnostics,'failures':failures})
def checked_data(folder,f):
 out=[]
 for t in ['X','L']:
  path=folder/f"{f['family']}_{t}.npy";assert sha(path)==f[t+'_sha256'];out.append(np.load(path,mmap_mode='r'))
 assert out[0].shape==(f['N'],f['m']) and out[1].shape==(f['N'],f['q']);return out

def run(args):
 p=verify();stage=args.stage;out=args.output/stage;out.mkdir(parents=True,exist_ok=True)
 if (out/'ALL_PREDICTIONS_FROZEN.json').exists():raise ValueError('Stage already frozen')
 records={};start=time.perf_counter()
 if stage=='e11':
  jobs=[]
  for fi,f in enumerate(p['stages']['e11']['families']):
   X,L=checked_data(args.known_data,f);pool,excluded,masks=known_design(f,fi);parts=blocks(len(pool),202611134000+10000*fi+1000)
   for fold in range(3):
    held=pool[parts[fold]];fit=pool[np.setdiff1d(np.arange(len(pool)),parts[fold])];case=out/f['family']/f'fold_{fold}';record=case/'record_PRIVATE.json'
    if not record.exists():one_case(X,L,f,fi,fold,fit,held,excluded,masks,case,args.e10)
    rec=json.loads(record.read_text());assert rec['protocol_sha256']==sha(ROOT/'PROTOCOL.json') and rec['source_manifest_sha256']==sha(ROOT/'MANIFEST.json') and rec['predictions_sha256']==sha(case/'predictions_PRIVATE.npz');records[str(record.relative_to(out))]=sha(record);print('FROZEN',stage,f['family'],fold,'failures',len(rec['failures']),flush=True)
 else:
  f=p['stages']['e12']['family'];X,L=checked_data(args.novel_data,f);cases,masks=novel_design(X)
  for fold,(fit,held) in enumerate(cases):
   case=out/f['family']/f'fold_{fold}';record=case/'record_PRIVATE.json'
   if not record.exists():one_case(X,L,f,16,fold,fit,held,np.array([],int),masks,case)
   rec=json.loads(record.read_text());assert rec['protocol_sha256']==sha(ROOT/'PROTOCOL.json') and rec['source_manifest_sha256']==sha(ROOT/'MANIFEST.json') and rec['predictions_sha256']==sha(case/'predictions_PRIVATE.npz');records[str(record.relative_to(out))]=sha(record);print('FROZEN',stage,f['family'],fold,'failures',len(rec['failures']),flush=True)
 assert len(records)==p['stages'][stage]['expected_cases'];save(out/'ALL_PREDICTIONS_FROZEN.json',{'records':records,'source_manifest_sha256':sha(ROOT/'MANIFEST.json'),'protocol_sha256':sha(ROOT/'PROTOCOL.json'),'wall_seconds':time.perf_counter()-start});print('STAGE FROZEN',stage,flush=True)
def metrics(y,v):
 d=abs(v-y);s=y+v;ratio=np.divide(d,s,out=np.zeros_like(d),where=s>0);active=y>0
 return {'brier':float(np.square(v-y).sum(1).mean()),'chebyshev':float(d.max(1).mean()),'clark':float(np.sqrt(np.square(ratio).sum(1)).mean()),'canberra':float(ratio.sum(1).mean()),'kl':float(np.where(active,y*np.log(np.where(active,y,1)/np.maximum(v,1e-12)),0).sum(1).mean()),'cosine':float((np.sum(y*v,1)/(np.linalg.norm(y,axis=1)*np.linalg.norm(v,axis=1))).mean()),'intersection':float(np.minimum(y,v).sum(1).mean())}
def score(args):
 p=verify()
 # Global gate: both studies frozen before either is scored.
 for stage,n in [('e11',48),('e12',5)]:
  fr=json.loads((args.output/stage/'ALL_PREDICTIONS_FROZEN.json').read_text());assert len(fr['records'])==n and fr['protocol_sha256']==sha(ROOT/'PROTOCOL.json') and fr['source_manifest_sha256']==sha(ROOT/'MANIFEST.json')
 for stage in ['e11','e12']:
  out=args.output/stage
  if (out/'RESULTS_PUBLIC.json').exists():raise ValueError('Already scored stage '+stage)
  fr=json.loads((out/'ALL_PREDICTIONS_FROZEN.json').read_text());rows=[];failures=[];diagnostics=[]
  for name,h in fr['records'].items():
   file=out/name;assert sha(file)==h;rec=json.loads(file.read_text());f=next(f for f in p['stages']['e11']['families'] if f['family']==rec['family']) if stage=='e11' else p['stages']['e12']['family'];folder=args.known_data if stage=='e11' else args.novel_data;yp=folder/f"{rec['family']}_L.npy";assert sha(yp)==f['L_sha256'];y=np.load(yp,mmap_mode='r')[rec['validation_indices']];assert sha(file.parent/'predictions_PRIVATE.npz')==rec['predictions_sha256']
   with np.load(file.parent/'predictions_PRIVATE.npz') as arr:
    for key in arr.files:
     valid(arr[key],len(y),y.shape[1]);rows.append({'family':rec['family'],'fold':rec['fold'],'key':key,'n_validation':len(y),**metrics(y,arr[key]),**rec['prototype_statistics'].get(key,{})})
   for key,v in rec['failures'].items():failures.append({'family':rec['family'],'fold':rec['fold'],'key':key,'error_type':v['error_type']})
   for key,v in rec['model_diagnostics'].items():diagnostics.append({'family':rec['family'],'fold':rec['fold'],'key':key,'max_mass_error':v.get('max_mass_error'),'warning_count':len(v.get('warnings',[])),'optimizer_success':v.get('optimizer',[{}])[0].get('success'),'optimizer_iterations':v.get('optimizer',[{}])[0].get('iterations')})
  summary=[];expected=3 if stage=='e11' else 5
  for family,key in sorted({(r['family'],r['key']) for r in rows}):
   rr=[r for r in rows if r['family']==family and r['key']==key];n=sum(r['n_validation'] for r in rr);item={'family':family,'key':key,'n_folds':len(rr),'complete':len(rr)==expected,'n_validation':n}
   for field in ['brier','chebyshev','clark','canberra','kl','cosine','intersection']+(['K','array_bytes','array_fraction'] if 'K' in rr[0] else []):item[field]=sum(r[field]*r['n_validation'] for r in rr)/n
   summary.append(item)
  save(out/'RESULTS_PUBLIC.json',{'scope':p['stages'][stage]['scope'],'rows':rows,'family_summary':summary,'failures':failures,'diagnostics':diagnostics,'original_known_outer_test_scored':False});print('SCORED',stage,len(rows),'failures',len(failures),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['run','score']);p.add_argument('--stage',choices=['e11','e12']);p.add_argument('--known-data',type=Path,required=True);p.add_argument('--novel-data',type=Path,required=True);p.add_argument('--e10',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();globals()[a.action](a)
