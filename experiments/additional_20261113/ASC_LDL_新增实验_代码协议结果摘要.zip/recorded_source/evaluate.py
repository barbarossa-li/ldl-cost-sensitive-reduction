"""Held-out scoring only after all27 selections are frozen; no reselection."""
from pathlib import Path
import os
for x in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[x]='1'
import csv,hashlib,json,platform,sqlite3,sys
import numpy as np
from experiment import ROOT,CODE,DATASETS,VARIANTS,Oracle,destination,sha,save,verify
sys.path.insert(0,str(CODE))
from baseline_revision.prediction_evaluation import predict_five_neighbors,metrics

def run():
 verify();freeze=json.loads((ROOT/'ALL_SELECTIONS_FROZEN.json').read_text())
 assert freeze['protocol_sha256']==sha(ROOT/'PROTOCOL.json')
 for path,h in freeze['selections'].items():assert sha(ROOT/path)==h
 oldselected=json.loads(Path('/workspace/work/asc_review/light/LDL_25_results/selected_subsets.json').read_text())
 oldselected={(r['dataset'],r['repeat']):r for r in oldselected if r['method']=='GBIP-O1'}
 oldresults=list(csv.DictReader(Path('/workspace/work/asc_review/light/LDL_25_results/all_results.csv').open()))
 oldresults={(r['dataset'],int(r['repeat'])):r for r in oldresults if r['method']=='GBIP-O1'}
 oldobjects=list(csv.DictReader(Path('/workspace/work/asc_review/repro/ASC_REVIEW_REPRODUCIBILITY_v2/supplementary/m1_effects/all_objects.csv').open()))
 rows=[];cross=[];replays=[]
 for d in DATASETS:
  Xall=np.load(ROOT/'data'/f'{d}_X.npy',mmap_mode='r');Lall=np.load(ROOT/'data'/f'{d}_L.npy',mmap_mode='r')
  for rep in [1,2,3]:
   split=json.loads((CODE/'expansion25/splits'/d/f'repeat_{rep}.json').read_text())
   train,test=split['train_indices'],split['test_indices'];X,L=np.asarray(Xall[train]),np.asarray(Lall[train]);query,truth=np.asarray(Xall[test]),np.asarray(Lall[test])
   records={v:json.loads((destination(d,rep,v)/'selection.json').read_text()) for v in VARIANTS}
   oracles={v:Oracle(X,L,v,record=False) for v in VARIANTS}
   references={v:np.load(destination(d,rep,v)/'endpoint_errors.npz')['reference'] for v in VARIANTS}
   for v,record in records.items():
    selected=record['result']['selected'];row={k:record[k] for k in ['dataset','repeat','variant','retained_cost_percent','fit_wall_seconds','fit_cpu_seconds','search_wall_seconds','search_cpu_seconds','training_peak_rss_bytes','selection_oracle_calls','selection_unique_subsets','reference_mean_error','final_mean_error']}
    row['status']=record['result']['status'];row['attributes']=None if selected is None else len(selected)
    row['candidate_requests']=record['result'].get('candidate_requests');row['own_violations']=record['result'].get('certificate',{}).get('violated_objects')
    if selected is not None:
     pred=predict_five_neighbors(X,L,query,selected);row.update(metrics(truth,pred));np.save(destination(d,rep,v)/'test_predictions.npy',pred)
     for evalv,oracle in oracles.items():
      e=oracle(selected);ref=references[evalv]
      cross.append({'dataset':d,'repeat':rep,'selector_geometry':v,'evaluator_geometry':evalv,'violations':int(np.sum(e>ref+1e-12)),'max_increase':float(np.max(e-ref)),'mean_error':float(e.mean())})
     if v=='full_max':
      old=oldselected[d,rep];subsets_match=sorted(selected)==sorted(old['selected'])
      target=[r for r in oldobjects if r['dataset']==d and int(r['repeat'])==rep and int(r['training_size'])==192]
      target.sort(key=lambda r:int(r['train_position']))
      ep=np.load(destination(d,rep,v)/'endpoint_errors.npz');reference_diff=final_diff=None
      if target:
       reference_diff=float(np.max(np.abs(ep['reference']-np.array([float(r['full_error']) for r in target]))))
       final_diff=float(np.max(np.abs(ep['final']-np.array([float(r['O1_error']) for r in target]))))
      brier_diff=row['brier']-float(oldresults[d,rep]['brier'])
      replays.append({'dataset':d,'repeat':rep,'selected_subset_matches':subsets_match,'brier_difference':brier_diff,'reference_vector_max_abs_diff':reference_diff,'final_vector_max_abs_diff':final_diff})
    rows.append(row)
    print('EVALUATED',d,rep,v,flush=True)
 save(ROOT/'evaluation.json',{'selection_freeze_sha256':sha(ROOT/'ALL_SELECTIONS_FROZEN.json'),'rows':rows,'cross_geometry':cross,'original_data_replay':replays})
 for filename,content in [('outcomes.csv',rows),('cross_geometry.csv',cross),('original_replay.csv',replays)]:
  keys=list(dict.fromkeys(k for r in content for k in r))
  with (ROOT/filename).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(content)
 print('EVALUATION DONE',len(rows),len(cross),flush=True)
if __name__=='__main__':run()
