# Presentation-only figure regeneration

From the extracted manuscript root, run:

```bash
python supplementary/presentation/redraw_figures.py
```

Requires NumPy and Matplotlib. Reads frozen benchmark summaries, object-error CSV, scale results and envelope assessments; performs no fitting, selection or training. The restored object-error rows were checked against all four pre-existing constraint-comparison summaries (192 rows per method/task, violation counts and maximum increases). Main cost/prediction figures, the Mean/O1 diagnostic, sample-size figure and envelope are regenerated with clarified labels. No scientific thresholds or outcomes change.
